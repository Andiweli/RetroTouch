# RetroTouch

> Current release: **1.0.0-beta.4**. The complete feature set has been validated in Breathless on
> real Android hardware. The beta label remains until RetroTouch has also been exercised in
> additional engines and game input stacks, beginning with Unreal and Unreal Tournament 99.

RetroTouch is a lightweight, engine-agnostic touch-control overlay for Android games. It layers above an existing `View`, `SurfaceView`, `GLSurfaceView`, SDL surface or JNI-driven renderer and sends abstract actions back to a tiny game-specific adapter.

It is designed for retro game ports that need one reusable FPS-friendly touch system instead of a different hard-coded overlay in every game.

## Features

- Android 4.1 / API 16 through Android 16 / API 36
- no runtime dependencies and no AndroidX requirement
- up to 16 buttons, two movement sticks, two relative-look zones and two digital D-pads
- true pointer-ID-based multitouch
- normalized coordinates that adapt to 4:3, 16:9, 20:9 and ultrawide Automotive displays
- stable string action IDs such as `fire` or `weapon_next`
- per-game default layouts and private persistent user layouts
- optional `OFF`, `GAMEPLAY` and `NAVIGATION` modes with independent layouts
- built-in overlay editor: add, remap, move, resize, opacity, delete, reset and save
- movable/resizable settings button and vertically draggable editor toolbar
- automatic one- or two-line button labels with font fitting for every host game
- host-callable input reset for respawn, level changes, loading and engine input resets
- optional automatic hiding after physical controller input
- Java callback API suited to Java, JNI and SDL host games
- MIT license

## Documentation

- [English integration and usage guide](docs/INTEGRATION_EN.md)
- [Deutsche Einbau- und Bedienungsanleitung](docs/INTEGRATION_DE.md)
- [Updating the AAR without touching game code](docs/UPDATING.md)
- [Verified Breathless reference integration](docs/BREATHLESS_INTEGRATION.md)

## Project layout

- `retrotouch/` - reusable Android library
- `sample/` - standalone visual and input test app
- `docs/` - integration notes

Open the root folder in Android Studio 2025. The default sample configuration uses AGP 8.11.1, Gradle 8.13, JDK 17 and `compileSdk 36`. The produced AAR still has `minSdk 16`.

## Add to a game

The recommended integration uses the release AAR. Copy it to `app/libs/retrotouch.aar` and add:

```groovy
dependencies {
    implementation files('libs/retrotouch.aar')
}
```

This keeps RetroTouch separate from the game. A compatible update only requires replacing that
AAR and rebuilding the APK/AAB. Keep the small game-specific callback adapter and layouts in the
game project.

Source integration remains available for RetroTouch development: copy `retrotouch/` beside the
app, include it in `settings.gradle`, and use the project dependency:

```groovy
dependencies {
    implementation project(':retrotouch')
}
```

Create a root `FrameLayout`, add the game view first and RetroTouch last:

```java
FrameLayout root = new FrameLayout(this);
root.addView(gameView, matchParent);

RetroTouchView touch = new RetroTouchView(this);
root.addView(touch, matchParent);
setContentView(root);
```

Register only the actions that the game supports:

```java
touch.registerAction("fire", "Fire");
touch.registerAction("use", "Use");
touch.registerAction("weapon_next", "Next Weapon");
```

Provide a default layout with normalized positions:

```java
List<RetroTouchControl> controls = new ArrayList<>();
controls.add(RetroTouchControl.lookZone("look", 0.72f, 0.48f, 0.56f, 0.78f));
controls.add(RetroTouchControl.moveStick("move", 0.16f, 0.76f, 0.25f));
controls.add(RetroTouchControl.button("fire", "fire", "Fire", 0.89f, 0.71f, 0.15f));
touch.setGameplayLayout(new RetroTouchLayout("my_game", controls));
```

`setDefaultLayout()` remains available as a backwards-compatible alias.

Finally map callbacks into the input path the game already uses:

```java
touch.setListener(new RetroTouchAdapter() {
    @Override public void onAction(String action, boolean pressed) {
        nativeTouchAction(action, pressed);
    }

    @Override public void onMove(float x, float y) {
        nativeTouchMove(x, y);
    }

    @Override public void onLook(float dx, float dy) {
        nativeTouchLook(dx, dy);
    }
});
```

For SDL games the same callback can push keyboard, mouse or controller events. RetroTouch deliberately does not define what `fire` means; the host game owns that one small mapping.

When the engine clears its own key or axis state, reset RetroTouch at the same point:

```java
engineResetInput();
touch.resetInputState();
```

This releases held actions, forces movement to zero, discards all active touch pointers and clears
RetroTouch's visual latches without changing the current overlay mode or saved layout.

For FPS fire buttons placed inside a look zone, a host may explicitly allow the held button finger
to keep producing relative look motion:

```java
touch.setLookWhileHoldingAction("fire", true);
```

The action remains pressed throughout the drag and is released only when that finger is lifted.
Actions are opt-in, so existing buttons and games retain their previous behavior.

## Optional navigation overlay

Games that already provide touch-friendly menus, such as many Android ports, can simply use
`OFF` and `GAMEPLAY`. Games that need menu navigation may register a second layout:

```java
touch.registerAction("menu_ok", "OK");
touch.registerAction("menu_back", "Back");

List<RetroTouchControl> navigation = new ArrayList<>();
navigation.add(RetroTouchControl.dPad("navigation", 0.18f, 0.72f, 0.30f));
navigation.add(RetroTouchControl.button("ok", "menu_ok", "OK", 0.86f, 0.68f, 0.14f));
navigation.add(RetroTouchControl.button("back", "menu_back", "Back", 0.73f, 0.82f, 0.11f));
touch.setNavigationLayout(new RetroTouchLayout("my_game_navigation", navigation));
```

Switch only when the host game's state changes:

```java
touch.setMode(RetroTouchMode.OFF);        // no drawing; taps pass through to the game
touch.setMode(RetroTouchMode.GAMEPLAY);   // movement/look/action layout
touch.setMode(RetroTouchMode.NAVIGATION); // optional D-pad and action buttons
```

The D-pad emits the stable IDs `nav_up`, `nav_down`, `nav_left` and `nav_right` from
`RetroTouchNavigation`. The other navigation buttons are ordinary buttons and may use any action
IDs and labels the host registers. Gameplay and navigation edits are saved independently.

## Layout editor

The settings icon opens the editor. A player can select and drag any control, then use:

- `ADD` - add a button, up to 16
- `ACTION` - cycle through actions registered by the current game
- `SMALL` / `LARGE` - resize the selected control
- `ALPHA` - cycle its opacity
- `DELETE` - remove it
- `RESET` - restore the game's default layout
- `SAVE` - persist and leave the editor

The settings icon itself can also be selected, moved, resized and adjusted with `ALPHA`. It is a
permanent editor entry point, so `DELETE` is visibly disabled while it is selected. Drag the
`↕ DRAG` handle to move the complete tool strip vertically when it covers a control. `SAVE`
stores both settings-icon and toolbar positions per game layout. Older saved layouts are loaded
unchanged and receive the new default editor positions automatically.

The save contains stable action strings rather than numeric enum positions, so layouts survive later changes in a game's internal action order.

## Controller coexistence

Call `notifyControllerInput()` after a physical controller event. Controls hide for three seconds and reappear automatically. Disable this behavior with `setAutoHideOnController(false)`.

Games that want touch controls only when no controller is available can query all Android gamepad
and joystick sources without vendor-specific checks:

```java
boolean controllerAvailable = RetroTouchControllers.isControllerConnected();
touch.setMode(controllerAvailable ? RetroTouchMode.OFF : wantedMode);
```

This detects built-in controls as well as connected Xbox, PlayStation, USB, Bluetooth and generic
Android controllers. Repeating the check during the host's normal state update also handles hotplug.

## Building

```bash
./gradlew :retrotouch:assembleRelease :sample:assembleDebug lint
```

Outputs:

- `retrotouch/build/outputs/aar/retrotouch-release.aar`
- `sample/build/outputs/apk/debug/sample-debug.apk`

## Origin and license

The interaction model was informed by Emile Belanger's MobileTouchControls project. RetroTouch is an independent clean-room implementation and contains no MobileTouchControls source code. This matters because MobileTouchControls is GPLv2 while RetroTouch is intentionally MIT-licensed for straightforward reuse in open and closed Android game projects.
