# Breathless reference integration

The `Breathless-Android` test package demonstrates the intended thin host adapter.

## Game-side separation

- `app/libs/retrotouch.aar` contains the complete reusable overlay implementation.
- `app/build.gradle` references only that local AAR.
- `BreathlessTouchBridge.java` owns Breathless actions, layouts and the double-tap RUN behavior.
- `MainActivity.java` layers the bridge's `RetroTouchView` above `BreathlessView` and forwards its callbacks to JNI.
- `breathless_native.cpp` maps stable action strings into the game's existing key path, applies move-stick values and converts relative look deltas to view rotation.
- JNI reports only `OFF`, `GAMEPLAY` or `NAVIGATION`; it contains no overlay implementation.
- RetroTouch remains disabled on OUYA and hides temporarily while a physical controller is producing input.
- Any available built-in, USB or Bluetooth game controller forces `OFF`; disconnecting it restores
  the appropriate touch mode automatically during the periodic state check.

For a compatible RetroTouch update, replace only `app/libs/retrotouch.aar` and rebuild. The
Breathless bridge changes only when Breathless itself needs new actions or intentionally adopts a
new RetroTouch API.

No renderer, level, AI, audio or save-game logic is replaced by RetroTouch.

## Default Breathless actions

- `fire`
- `use`
- `run`
- `weapon_next`
- `weapon_1` through `weapon_6`
- `map`
- `menu`

The default layout exposes move, look, fire, use, run, next weapon, map and menu. A player can add individual weapon buttons from the editor because all six weapon actions are registered even though they are not visible by default.

Breathless opts FIRE into `setLookWhileHoldingAction()`. If the FIRE button's center is inside the
LOOK AREA, dragging that held finger turns the view without releasing FIRE. This supports movement,
turning and continuous fire at the same time while remaining optional for other games.

The optional navigation layout exposes the standard digital D-pad actions plus Breathless-owned
`nav_ok` and `nav_back` buttons. Logo, title, loading, credits and other tap-to-continue screens use
`OFF`, so their original direct touch handling remains available.

## Device test checklist

1. Skip logo/title screens with a normal screen tap and confirm that no overlay is visible.
2. Confirm that navigable menus show the D-pad, OK and Back controls.
3. Confirm that entering gameplay replaces navigation with the gameplay layout immediately.
4. Move and look simultaneously, then add fire as a third finger.
5. Hold Fire and verify the existing autofire cadence and release behavior.
6. Hold Run while moving, then test the double-tap always-run toggle.
7. Test Use, Next Weapon, Map and Menu.
8. Edit and save both layouts independently, relaunch, and confirm persistence.
9. Use a physical controller and verify that the active overlay hides without delaying the next mode.
10. Test 4:3, 16:9, 20:9 and the Automotive safe area.
11. On OUYA, verify that RetroTouch stays disabled and controller behavior is unchanged.
