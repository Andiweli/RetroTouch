# Updating RetroTouch in a game

## Recommended boundary

Keep these pieces separate:

1. `app/libs/retrotouch.aar` - reusable RetroTouch implementation
2. a game-owned bridge - action registration, callbacks and mode selection
3. game-owned default layouts - control IDs, action IDs and normalized positions

Do not copy RetroTouch Java sources into the app module for a release integration. A compatible
update then consists of replacing the AAR and rebuilding the game.

## Compatibility policy

- Starting with `1.0.0-beta.1`, existing public classes and methods remain source-compatible across
  compatible beta and stable updates unless the changelog explicitly marks a migration.
- New capabilities are opt-in. A game using only `setDefaultLayout()` continues to receive a
  gameplay-only overlay.
- Stable string action IDs and layout game IDs must not be renamed by a library update.
- Saved layout format 1 remains readable; RetroTouch 1.0 beta writes format 2.
- Removed APIs require a future major-version migration note rather than a silent deletion.

## Runtime distribution

Android packages the AAR into the APK/AAB. End users still receive a rebuilt game package; an AAR
cannot safely replace code inside an already installed game. RetroTouch intentionally avoids a
separate draw-over-other-apps service and its associated permissions and input-injection limits.

## Host input resets

Starting with `1.0.0-beta.3`, call `resetInputState()` whenever the host engine discards its key or
axis state. This includes respawn, checkpoint restart, level loading and focus loss. The call keeps
the active RetroTouch mode and layouts but prevents stale pointers or held actions from surviving
the engine reset. The host remains responsible for clearing its own toggle variables.

## Beta.4 editor-state migration

`1.0.0-beta.4` keeps the public Java API and saved control-layout format unchanged. It stores the
movable settings button and editor toolbar in an additional private preference entry keyed by the
same game/layout ID. Existing Breathless and Unreal integrations therefore only need the new AAR
and a rebuild. Older user layouts load normally; editor-position defaults are added on the next
save.
