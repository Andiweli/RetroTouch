package com.ast.retrotouch.sample;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.ast.retrotouch.RetroTouchAdapter;
import com.ast.retrotouch.RetroTouchControl;
import com.ast.retrotouch.RetroTouchLayout;
import com.ast.retrotouch.RetroTouchMode;
import com.ast.retrotouch.RetroTouchView;

import java.util.ArrayList;
import java.util.List;

/** Standalone smoke-test app. It deliberately has no engine or third-party dependency. */
public final class MainActivity extends Activity {
    private DemoGameView gameView;
    private RetroTouchView retroTouch;
    private float moveX;
    private float moveY;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        FrameLayout root = new FrameLayout(this);
        gameView = new DemoGameView(this);
        retroTouch = new RetroTouchView(this);
        root.addView(gameView, matchParent());
        root.addView(retroTouch, matchParent());
        setContentView(root);

        configureRetroTouch();
    }

    private void configureRetroTouch() {
        retroTouch.registerAction("fire", "Fire");
        retroTouch.registerAction("primary_fire", "Primary Fire");
        retroTouch.registerAction("alternate_fire", "Alternate Fire");
        retroTouch.registerAction("use", "Use");
        retroTouch.registerAction("run", "Run");
        retroTouch.registerAction("weapon_next", "Next Weapon");
        retroTouch.registerAction("weapon_previous", "Prev Weapon");
        retroTouch.registerAction("menu", "Menu");
        retroTouch.registerAction("nav_ok", "OK");
        retroTouch.registerAction("nav_back", "Back");

        List<RetroTouchControl> controls = new ArrayList<RetroTouchControl>();
        controls.add(RetroTouchControl.lookZone("look", 0.72f, 0.48f, 0.56f, 0.78f));
        controls.add(RetroTouchControl.moveStick("move", 0.16f, 0.76f, 0.25f));
        controls.add(RetroTouchControl.button("fire", "fire", "Fire", 0.89f, 0.71f, 0.15f));
        controls.add(RetroTouchControl.button("primary_fire", "primary_fire", "Primary Fire", 0.91f, 0.49f, 0.10f));
        controls.add(RetroTouchControl.button("alternate_fire", "alternate_fire", "Alternate Fire", 0.68f, 0.44f, 0.09f));
        controls.add(RetroTouchControl.button("use", "use", "Use", 0.77f, 0.80f, 0.11f));
        controls.add(RetroTouchControl.button("run", "run", "Run", 0.28f, 0.66f, 0.10f));
        controls.add(RetroTouchControl.button("weapon", "weapon_next", "Next Weapon", 0.79f, 0.56f, 0.11f));
        controls.add(RetroTouchControl.button("menu", "menu", "Menu", 0.53f, 0.10f, 0.09f));
        retroTouch.setGameplayLayout(new RetroTouchLayout("retrotouch_demo", controls));

        List<RetroTouchControl> navigation = new ArrayList<RetroTouchControl>();
        navigation.add(RetroTouchControl.dPad("navigation", 0.18f, 0.72f, 0.30f));
        navigation.add(RetroTouchControl.button("ok", "nav_ok", "OK", 0.86f, 0.68f, 0.14f));
        navigation.add(RetroTouchControl.button("back", "nav_back", "Back", 0.73f, 0.82f, 0.11f));
        retroTouch.setNavigationLayout(new RetroTouchLayout("retrotouch_demo_navigation", navigation));
        retroTouch.setLookWhileHoldingAction("fire", true);

        retroTouch.setListener(new RetroTouchAdapter() {
            @Override public void onAction(String actionId, boolean pressed) {
                gameView.setLastEvent(actionId + (pressed ? " DOWN" : " UP"));
                if (pressed && "menu".equals(actionId)) retroTouch.setMode(RetroTouchMode.NAVIGATION);
                else if (pressed && "nav_back".equals(actionId)) retroTouch.setMode(RetroTouchMode.GAMEPLAY);
            }

            @Override public void onMove(float x, float y) {
                moveX = x;
                moveY = y;
                gameView.setMove(x, y);
            }

            @Override public void onLook(float deltaX, float deltaY) {
                gameView.addLook(deltaX, deltaY);
            }

            @Override public void onEditorStateChanged(boolean editing) {
                gameView.setLastEvent(editing ? "LAYOUT EDITOR" : "LAYOUT SAVED");
            }
        });
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (isControllerSource(event.getSource())) retroTouch.notifyControllerInput();
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if (isControllerSource(event.getSource())) retroTouch.notifyControllerInput();
        return super.dispatchGenericMotionEvent(event);
    }

    @Override
    protected void onPause() {
        if (retroTouch != null) retroTouch.resetInputState();
        moveX = moveY = 0.0f;
        super.onPause();
    }

    private static boolean isControllerSource(int source) {
        return (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK;
    }

    private static FrameLayout.LayoutParams matchParent() {
        return new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    }

    private static final class DemoGameView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String lastEvent = "Touch the controls - use the top-right editor button";
        private float playerX = 0.5f;
        private float playerY = 0.5f;
        private float lookX;
        private float lookY;

        DemoGameView(Activity activity) {
            super(activity);
            paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        }

        void setLastEvent(String event) { lastEvent = event; invalidate(); }

        void setMove(float x, float y) {
            playerX = clamp(playerX + x * 0.012f);
            playerY = clamp(playerY + y * 0.012f);
            lastEvent = String.format(java.util.Locale.US, "MOVE %.2f / %.2f", x, y);
            invalidate();
        }

        void addLook(float x, float y) {
            lookX += x;
            lookY += y;
            lastEvent = String.format(java.util.Locale.US, "LOOK %+.3f / %+.3f", x, y);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            canvas.drawColor(Color.rgb(18, 27, 38));
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(27, 47, 65));
            for (int x = 0; x < getWidth(); x += Math.max(1, getWidth() / 16)) canvas.drawRect(x, 0, x + 1, getHeight(), paint);
            for (int y = 0; y < getHeight(); y += Math.max(1, getHeight() / 9)) canvas.drawRect(0, y, getWidth(), y + 1, paint);
            paint.setColor(Color.rgb(94, 212, 255));
            canvas.drawCircle(playerX * getWidth(), playerY * getHeight(), Math.max(8, getHeight() * 0.025f), paint);
            paint.setColor(Color.WHITE);
            paint.setTextSize(Math.max(16, getHeight() * 0.045f));
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("RETROTOUCH", getWidth() * 0.5f, getHeight() * 0.28f, paint);
            paint.setTextSize(Math.max(11, getHeight() * 0.025f));
            canvas.drawText(lastEvent, getWidth() * 0.5f, getHeight() * 0.36f, paint);
            canvas.drawText(String.format(java.util.Locale.US, "LOOK TOTAL %.2f / %.2f", lookX, lookY),
                    getWidth() * 0.5f, getHeight() * 0.42f, paint);
        }

        private static float clamp(float value) { return Math.max(0.05f, Math.min(0.95f, value)); }
    }
}
