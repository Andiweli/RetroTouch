package com.ast.retrotouch;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A game-specific set of controls. Coordinates are normalized from 0 to 1. */
public final class RetroTouchLayout {
    public static final int MAX_BUTTONS = 16;
    private static final int FORMAT_VERSION = 2;

    private final String gameId;
    private final List<RetroTouchControl> controls;

    public RetroTouchLayout(String gameId, List<RetroTouchControl> controls) {
        if (!RetroTouchAction.isValidId(gameId)) throw new IllegalArgumentException("Invalid game ID: " + gameId);
        if (controls == null) throw new IllegalArgumentException("Controls must not be null");
        validate(controls);
        this.gameId = gameId;
        this.controls = copyControls(controls);
    }

    public String getGameId() { return gameId; }

    public List<RetroTouchControl> getControls() {
        return Collections.unmodifiableList(copyControls(controls));
    }

    List<RetroTouchControl> mutableCopy() {
        return copyControls(controls);
    }

    public String toJson() {
        try {
            JSONObject root = new JSONObject();
            root.put("format", FORMAT_VERSION);
            root.put("game", gameId);
            JSONArray items = new JSONArray();
            for (RetroTouchControl control : controls) items.put(control.toJson());
            root.put("controls", items);
            return root.toString(2);
        } catch (JSONException impossible) {
            throw new IllegalStateException("Unable to serialize RetroTouch layout", impossible);
        }
    }

    public static RetroTouchLayout fromJson(String jsonText) throws JSONException {
        JSONObject root = new JSONObject(jsonText);
        int format = root.getInt("format");
        if (format < 1 || format > FORMAT_VERSION) throw new JSONException("Unsupported layout format");
        JSONArray items = root.getJSONArray("controls");
        List<RetroTouchControl> controls = new ArrayList<RetroTouchControl>();
        for (int i = 0; i < items.length(); ++i) controls.add(RetroTouchControl.fromJson(items.getJSONObject(i)));
        try {
            return new RetroTouchLayout(root.getString("game"), controls);
        } catch (IllegalArgumentException invalid) {
            throw new JSONException(invalid.getMessage());
        }
    }

    private static void validate(List<RetroTouchControl> controls) {
        int buttons = 0;
        int moveSticks = 0;
        int lookZones = 0;
        int dPads = 0;
        List<String> ids = new ArrayList<String>();
        for (RetroTouchControl control : controls) {
            if (control == null) throw new IllegalArgumentException("Control must not be null");
            if (ids.contains(control.getId())) throw new IllegalArgumentException("Duplicate control ID: " + control.getId());
            ids.add(control.getId());
            if (control.getType() == RetroTouchControl.Type.BUTTON) ++buttons;
            else if (control.getType() == RetroTouchControl.Type.MOVE_STICK) ++moveSticks;
            else if (control.getType() == RetroTouchControl.Type.LOOK_ZONE) ++lookZones;
            else if (control.getType() == RetroTouchControl.Type.D_PAD) ++dPads;
        }
        if (buttons > MAX_BUTTONS) throw new IllegalArgumentException("A layout supports at most 16 buttons");
        if (moveSticks > 2 || lookZones > 2) throw new IllegalArgumentException("A layout supports at most two sticks and two look zones");
        if (dPads > 2) throw new IllegalArgumentException("A layout supports at most two navigation pads");
    }

    private static List<RetroTouchControl> copyControls(List<RetroTouchControl> source) {
        List<RetroTouchControl> result = new ArrayList<RetroTouchControl>(source.size());
        for (RetroTouchControl control : source) result.add(control.copy());
        return result;
    }
}
