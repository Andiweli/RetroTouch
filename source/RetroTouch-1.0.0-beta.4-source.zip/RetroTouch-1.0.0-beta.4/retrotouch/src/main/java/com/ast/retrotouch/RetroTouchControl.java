package com.ast.retrotouch;

import org.json.JSONException;
import org.json.JSONObject;

/** A normalized, resolution-independent control definition. */
public final class RetroTouchControl {
    public enum Type { BUTTON, MOVE_STICK, LOOK_ZONE, D_PAD }

    private final String id;
    private Type type;
    private String actionId;
    private String label;
    private float x;
    private float y;
    private float width;
    private float height;
    private float opacity;

    private RetroTouchControl(String id, Type type, String actionId, String label,
                              float x, float y, float width, float height, float opacity) {
        if (!RetroTouchAction.isValidId(id)) throw new IllegalArgumentException("Invalid control ID: " + id);
        this.id = id;
        this.type = type;
        this.actionId = actionId == null ? "" : actionId;
        this.label = label == null ? "" : label;
        this.x = clamp(x, 0.0f, 1.0f);
        this.y = clamp(y, 0.0f, 1.0f);
        this.width = clamp(width, 0.04f, 1.0f);
        this.height = clamp(height, 0.04f, 1.0f);
        this.opacity = clamp(opacity, 0.04f, 1.0f);
    }

    public static RetroTouchControl button(String id, String actionId, String label,
                                           float x, float y, float size) {
        return new RetroTouchControl(id, Type.BUTTON, actionId, label, x, y, size, size, 0.58f);
    }

    public static RetroTouchControl moveStick(String id, float x, float y, float size) {
        return new RetroTouchControl(id, Type.MOVE_STICK, "", "MOVE", x, y, size, size, 0.45f);
    }

    public static RetroTouchControl lookZone(String id, float x, float y, float width, float height) {
        return new RetroTouchControl(id, Type.LOOK_ZONE, "", "LOOK", x, y, width, height, 0.16f);
    }

    /** Creates a digital navigation pad which emits the RetroTouchNavigation action IDs. */
    public static RetroTouchControl dPad(String id, float x, float y, float size) {
        return new RetroTouchControl(id, Type.D_PAD, "", "", x, y, size, size, 0.58f);
    }

    public RetroTouchControl copy() {
        return new RetroTouchControl(id, type, actionId, label, x, y, width, height, opacity);
    }

    public String getId() { return id; }
    public Type getType() { return type; }
    public String getActionId() { return actionId; }
    public String getLabel() { return label; }
    public float getX() { return x; }
    public float getY() { return y; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    public float getOpacity() { return opacity; }

    void setAction(String actionId, String label) {
        this.actionId = actionId == null ? "" : actionId;
        this.label = label == null ? "" : label;
    }

    void setPosition(float x, float y) {
        this.x = clamp(x, width * 0.5f, 1.0f - width * 0.5f);
        this.y = clamp(y, height * 0.5f, 1.0f - height * 0.5f);
    }

    void scale(float factor) {
        float maximum = type == Type.LOOK_ZONE ? 1.0f : (type == Type.D_PAD ? 0.58f : 0.42f);
        width = clamp(width * factor, 0.06f, maximum);
        height = clamp(height * factor, 0.06f, maximum);
        setPosition(x, y);
    }

    void cycleOpacity() {
        if (opacity < 0.10f) opacity = 0.14f;
        else if (opacity < 0.20f) opacity = 0.28f;
        else if (opacity < 0.42f) opacity = 0.58f;
        else if (opacity < 0.75f) opacity = 0.90f;
        else opacity = 0.07f;
    }

    JSONObject toJson() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("id", id);
        json.put("type", type.name().toLowerCase());
        json.put("action", actionId);
        json.put("label", label);
        json.put("x", x);
        json.put("y", y);
        json.put("width", width);
        json.put("height", height);
        json.put("opacity", opacity);
        return json;
    }

    static RetroTouchControl fromJson(JSONObject json) throws JSONException {
        String typeName = json.getString("type").toUpperCase();
        Type type = Type.valueOf(typeName);
        return new RetroTouchControl(
                json.getString("id"), type, json.optString("action", ""),
                json.optString("label", ""), (float) json.getDouble("x"),
                (float) json.getDouble("y"), (float) json.getDouble("width"),
                (float) json.getDouble("height"), (float) json.optDouble("opacity", 0.58));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
