package com.ast.retrotouch;

/** Convenience adapter for hosts that do not need every callback. */
public class RetroTouchAdapter implements RetroTouchListener {
    @Override public void onAction(String actionId, boolean pressed) { }
    @Override public void onMove(float x, float y) { }
    @Override public void onLook(float deltaX, float deltaY) { }
    @Override public void onEditorStateChanged(boolean editing) { }
}
