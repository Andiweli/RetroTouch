package com.ast.retrotouch;

import android.view.InputDevice;

/** Controller-presence helpers shared by games that optionally expose RetroTouch. */
public final class RetroTouchControllers {
    private RetroTouchControllers() { }

    /**
     * Returns true for every currently available Android gamepad or joystick, including built-in,
     * USB and Bluetooth controllers. Devices are identified by Android input sources rather than
     * vendor names, so Xbox, PlayStation and generic controllers use the same path.
     */
    public static boolean isControllerConnected() {
        int[] ids = InputDevice.getDeviceIds();
        for (int id : ids) {
            InputDevice device = InputDevice.getDevice(id);
            if (device == null) continue;
            int sources = device.getSources();
            if ((sources & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                    (sources & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK)
                return true;
        }
        return false;
    }
}
