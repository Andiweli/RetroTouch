package com.ast.retrotouch;

/** An action exposed by a host game to RetroTouch. */
public final class RetroTouchAction {
    private final String id;
    private final String label;

    public RetroTouchAction(String id, String label) {
        if (!isValidId(id)) {
            throw new IllegalArgumentException("Action IDs must use lowercase letters, digits or underscores");
        }
        if (label == null || label.trim().length() == 0) {
            throw new IllegalArgumentException("Action label must not be empty");
        }
        this.id = id;
        this.label = label.trim();
    }

    public String getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    static boolean isValidId(String value) {
        if (value == null || value.length() == 0) return false;
        for (int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_')) return false;
        }
        return true;
    }
}
