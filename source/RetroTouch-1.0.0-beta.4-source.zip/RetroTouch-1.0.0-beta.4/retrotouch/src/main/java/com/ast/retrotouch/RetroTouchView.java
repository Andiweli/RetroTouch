package com.ast.retrotouch;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Resolution-independent multitouch controls that can be layered above any Android game view.
 * The host registers actions and receives abstract callbacks; RetroTouch never depends on a
 * specific game engine.
 */
public final class RetroTouchView extends View {
    private static final String TAG = "RetroTouch";
    private static final String PREFS_NAME = "retrotouch_layouts";
    private static final String POINTER_GEAR = "__gear";
    private static final String POINTER_TOOLBAR = "__toolbar";
    private static final String POINTER_TOOLBAR_DRAG = "__toolbar_drag";
    private static final long DEFAULT_CONTROLLER_HIDE_MS = 3000L;
    private static final float DEFAULT_SETTINGS_OPACITY = 0.28f;
    private static final float DEFAULT_SETTINGS_SIZE_SCALE = 0.75f;
    private static final String[] TOOL_LABELS = {
            "ADD", "ACTION", "SMALL", "LARGE", "ALPHA", "DELETE", "RESET", "SAVE"
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final SparseArray<PointerState> pointers = new SparseArray<PointerState>();
    private final LinkedHashMap<String, RetroTouchAction> actions = new LinkedHashMap<String, RetroTouchAction>();
    private final List<RetroTouchControl> controls = new ArrayList<RetroTouchControl>();
    private final Set<String> latchedActions = new HashSet<String>();
    private final Set<String> lookWhileHoldingActions = new HashSet<String>();

    private RetroTouchListener listener = new RetroTouchAdapter();
    private RetroTouchLayout gameplayLayout;
    private RetroTouchLayout navigationLayout;
    private RetroTouchLayout defaultLayout;
    private RetroTouchMode mode = RetroTouchMode.GAMEPLAY;
    private String selectedControlId;
    private boolean overlayEnabled = true;
    private boolean editing;
    private boolean editButtonVisible = true;
    private boolean autoHideOnController = true;
    private long controllerHiddenUntil;
    private float lookSensitivity = 1.0f;
    private int accentColor = Color.rgb(75, 205, 245);
    private float settingsX = Float.NaN;
    private float settingsY = Float.NaN;
    private float settingsScale = DEFAULT_SETTINGS_SIZE_SCALE;
    private float settingsOpacity = DEFAULT_SETTINGS_OPACITY;
    private float toolbarCenterY = Float.NaN;

    public RetroTouchView(Context context) {
        this(context, null);
    }

    public RetroTouchView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(true);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2.0f));
        paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        setContentDescription("RetroTouch game controls");
    }

    public void registerAction(String id, String label) {
        RetroTouchAction action = new RetroTouchAction(id, label);
        actions.put(action.getId(), action);
        refreshControlLabels();
        invalidate();
    }

    public void registerActions(List<RetroTouchAction> actionList) {
        actions.clear();
        if (actionList != null) {
            for (RetroTouchAction action : actionList) {
                if (action == null) throw new IllegalArgumentException("Action must not be null");
                actions.put(action.getId(), action);
            }
        }
        refreshControlLabels();
        invalidate();
    }

    public List<RetroTouchAction> getRegisteredActions() {
        return Collections.unmodifiableList(new ArrayList<RetroTouchAction>(actions.values()));
    }

    /** Backwards-compatible alias for setGameplayLayout(). */
    public void setDefaultLayout(RetroTouchLayout layout) {
        setGameplayLayout(layout);
    }

    public void setGameplayLayout(RetroTouchLayout layout) {
        if (layout == null) throw new IllegalArgumentException("Default layout must not be null");
        gameplayLayout = layout;
        if (mode == RetroTouchMode.GAMEPLAY) activateLayout(layout);
    }

    /** Registers the optional menu/navigation layout. Games may omit it entirely. */
    public void setNavigationLayout(RetroTouchLayout layout) {
        if (layout == null) throw new IllegalArgumentException("Navigation layout must not be null");
        navigationLayout = layout;
        if (mode == RetroTouchMode.NAVIGATION) activateLayout(layout);
    }

    public void setMode(RetroTouchMode value) {
        if (value == null) throw new IllegalArgumentException("Mode must not be null");
        if (mode == value) return;
        if (editing) setEditing(false);
        releaseAll();
        // Controller suppression belongs to the old surface and must never delay a newly
        // activated layout (for example when leaving a controller-driven menu for gameplay).
        controllerHiddenUntil = 0L;
        mode = value;
        activateLayout(layoutForMode(value));
    }

    public RetroTouchMode getMode() { return mode; }

    public RetroTouchLayout getCurrentLayout() {
        ensureLayout();
        return new RetroTouchLayout(defaultLayout.getGameId(), controls);
    }

    public void setListener(RetroTouchListener listener) {
        this.listener = listener == null ? new RetroTouchAdapter() : listener;
    }

    /** Keeps every button mapped to this action visually selected until cleared. */
    public void setActionLatched(String actionId, boolean latched) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (latched) latchedActions.add(actionId);
        else latchedActions.remove(actionId);
        invalidate();
    }

    public boolean isActionLatched(String actionId) {
        return actionId != null && latchedActions.contains(actionId);
    }

    /**
     * Re-synchronizes RetroTouch after the host engine has discarded its own input state.
     * All active pointers are forgotten, held actions are released, movement is forced to neutral
     * and RetroTouch-owned visual latches are cleared. The current mode and layouts are preserved.
     * Host-owned toggle variables must be cleared by the game at the same reset point.
     */
    public void resetInputState() {
        Set<String> releasedActions = releaseAll(true);
        for (String actionId : latchedActions) {
            if (!releasedActions.contains(actionId)) listener.onAction(actionId, false);
        }
        latchedActions.clear();
        invalidate();
    }

    /** Descriptive alias for {@link #resetInputState()}. */
    public void releaseAllInputs() {
        resetInputState();
    }

    public void setOverlayEnabled(boolean enabled) {
        if (overlayEnabled == enabled) return;
        releaseAll();
        overlayEnabled = enabled;
        if (!enabled && editing) setEditing(false);
        invalidate();
    }

    public boolean isOverlayEnabled() { return overlayEnabled; }

    public void setEditing(boolean value) {
        if (!overlayEnabled || mode == RetroTouchMode.OFF || defaultLayout == null) value = false;
        if (editing == value) return;
        if (editing && !value && defaultLayout != null) saveLayout();
        releaseAll();
        editing = value;
        selectedControlId = null;
        listener.onEditorStateChanged(editing);
        invalidate();
    }

    public boolean isEditing() { return editing; }

    public void setEditButtonVisible(boolean visible) {
        editButtonVisible = visible;
        invalidate();
    }

    public void setAutoHideOnController(boolean enabled) {
        autoHideOnController = enabled;
        if (!enabled) controllerHiddenUntil = 0L;
        invalidate();
    }

    /** Temporarily hides controls after physical controller activity. */
    public void notifyControllerInput() {
        if (!autoHideOnController || editing) return;
        releaseAll();
        controllerHiddenUntil = SystemClock.uptimeMillis() + DEFAULT_CONTROLLER_HIDE_MS;
        invalidate();
        postInvalidateDelayed(DEFAULT_CONTROLLER_HIDE_MS + 20L);
    }

    public void setLookSensitivity(float sensitivity) {
        lookSensitivity = Math.max(0.1f, Math.min(4.0f, sensitivity));
    }

    /**
     * Lets a held button continue to emit relative look motion when its center is placed inside
     * a look zone. The action remains pressed until the finger is released.
     */
    public void setLookWhileHoldingAction(String actionId, boolean enabled) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (enabled) lookWhileHoldingActions.add(actionId);
        else lookWhileHoldingActions.remove(actionId);
    }

    public void setAccentColor(int color) {
        accentColor = color;
        invalidate();
    }

    public void saveLayout() {
        ensureLayout();
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(preferenceKey(), new RetroTouchLayout(defaultLayout.getGameId(), controls).toJson())
                .putString(editorPreferenceKey(), editorStateToJson())
                .apply();
    }

    public void resetToDefault() {
        ensureLayout();
        releaseAll();
        controls.clear();
        controls.addAll(defaultLayout.mutableCopy());
        resetEditorState();
        refreshControlLabels();
        selectedControlId = null;
        saveLayout();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!overlayEnabled || mode == RetroTouchMode.OFF || defaultLayout == null) return;
        boolean suppressed = controlsSuppressed();
        if (!suppressed || editing) {
            drawControls(canvas);
        }
        if (editing) drawToolbar(canvas);
        // Keep the permanent editor entry point visible even if the movable toolbar overlaps it.
        if (!suppressed && editButtonVisible) drawGear(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!overlayEnabled || mode == RetroTouchMode.OFF || defaultLayout == null) return false;
        int action = event.getActionMasked();
        if (controlsSuppressed() && !editing) {
            if (action != MotionEvent.ACTION_DOWN) return false;
            // A real screen touch always wins over the temporary controller
            // suppression and must be usable immediately, not after its timer.
            controllerHiddenUntil = 0L;
            invalidate();
        }
        int index = event.getActionIndex();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            boolean began = beginPointer(event.getPointerId(index), event.getX(index), event.getY(index));
            return began || pointers.size() > 0;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            boolean handled = false;
            for (int i = 0; i < event.getPointerCount(); ++i) {
                handled |= movePointer(event.getPointerId(i), event.getX(i), event.getY(i));
            }
            return handled || pointers.size() > 0;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            endPointer(event.getPointerId(index), event.getX(index), event.getY(index));
            if (action == MotionEvent.ACTION_UP) performClick();
            return true;
        }
        if (action == MotionEvent.ACTION_CANCEL) {
            releaseAll();
            return true;
        }
        return pointers.size() > 0;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        releaseAll();
        super.onDetachedFromWindow();
    }

    private void loadLayout() {
        releaseAll();
        controls.clear();
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String saved = prefs.getString(preferenceKey(), null);
        if (saved != null) {
            try {
                RetroTouchLayout parsed = RetroTouchLayout.fromJson(saved);
                if (parsed.getGameId().equals(defaultLayout.getGameId())) controls.addAll(parsed.mutableCopy());
            } catch (JSONException | IllegalArgumentException invalid) {
                Log.w(TAG, "Ignoring invalid saved layout", invalid);
            }
        }
        if (controls.isEmpty()) controls.addAll(defaultLayout.mutableCopy());
        loadEditorState(prefs);
        refreshControlLabels();
        invalidate();
    }

    private RetroTouchLayout layoutForMode(RetroTouchMode value) {
        if (value == RetroTouchMode.GAMEPLAY) return gameplayLayout;
        if (value == RetroTouchMode.NAVIGATION) return navigationLayout;
        return null;
    }

    private void activateLayout(RetroTouchLayout layout) {
        defaultLayout = layout;
        if (layout == null) {
            releaseAll();
            controls.clear();
            selectedControlId = null;
            invalidate();
        } else {
            loadLayout();
        }
    }

    private String preferenceKey() {
        return "layout_" + (defaultLayout == null ? "unset" : defaultLayout.getGameId());
    }

    private String editorPreferenceKey() { return preferenceKey() + "_editor"; }

    private void resetEditorState() {
        settingsX = Float.NaN;
        settingsY = Float.NaN;
        settingsScale = DEFAULT_SETTINGS_SIZE_SCALE;
        settingsOpacity = DEFAULT_SETTINGS_OPACITY;
        toolbarCenterY = Float.NaN;
    }

    private void loadEditorState(SharedPreferences prefs) {
        resetEditorState();
        String saved = prefs.getString(editorPreferenceKey(), null);
        if (saved == null) return;
        try {
            JSONObject json = new JSONObject(saved);
            settingsX = clamp01((float) json.optDouble("settings_x", Float.NaN));
            settingsY = clamp01((float) json.optDouble("settings_y", Float.NaN));
            settingsScale = clamp((float) json.optDouble("settings_scale", DEFAULT_SETTINGS_SIZE_SCALE),
                    0.40f, 1.40f);
            settingsOpacity = clamp((float) json.optDouble("settings_opacity", DEFAULT_SETTINGS_OPACITY),
                    0.07f, 0.90f);
            toolbarCenterY = clamp01((float) json.optDouble("toolbar_y", Float.NaN));
        } catch (JSONException invalid) {
            Log.w(TAG, "Ignoring invalid saved editor layout", invalid);
            resetEditorState();
        }
    }

    private String editorStateToJson() {
        JSONObject json = new JSONObject();
        try {
            RectF gear = gearRect();
            json.put("format", 1);
            json.put("settings_x", getWidth() > 0 ? gear.centerX() / getWidth() : 1.0f);
            json.put("settings_y", getHeight() > 0 ? gear.centerY() / getHeight() : 0.0f);
            json.put("settings_scale", settingsScale);
            json.put("settings_opacity", settingsOpacity);
            json.put("toolbar_y", getHeight() > 0 ?
                    (toolbarTop() + toolbarHeight() * 0.5f) / getHeight() : 1.0f);
        } catch (JSONException impossible) {
            throw new IllegalStateException(impossible);
        }
        return json.toString();
    }

    private void ensureLayout() {
        if (defaultLayout == null) throw new IllegalStateException("Call setDefaultLayout() first");
    }

    private boolean controlsSuppressed() {
        return autoHideOnController && SystemClock.uptimeMillis() < controllerHiddenUntil;
    }

    private boolean beginPointer(int pointerId, float x, float y) {
        if (editing) {
            if (isInsideGear(x, y)) {
                selectedControlId = POINTER_GEAR;
                PointerState state = new PointerState(POINTER_GEAR, x, y);
                RectF gear = gearRect();
                state.dragOffsetX = gear.centerX() - x;
                state.dragOffsetY = gear.centerY() - y;
                pointers.put(pointerId, state);
                invalidate();
                return true;
            }
            if (isInsideToolbarHandle(x, y)) {
                PointerState state = new PointerState(POINTER_TOOLBAR_DRAG, x, y);
                state.dragOffsetY = toolbarTop() - y;
                pointers.put(pointerId, state);
                return true;
            }
            int tool = toolbarIndex(x, y);
            if (tool >= 0) {
                pointers.put(pointerId, new PointerState("__tool_" + tool, x, y));
                return true;
            }
            if (isInsideToolbar(x, y)) {
                pointers.put(pointerId, new PointerState(POINTER_TOOLBAR, x, y));
                return true;
            }
            RetroTouchControl hit = hitControl(x, y, true);
            if (hit != null) {
                selectedControlId = hit.getId();
                pointers.put(pointerId, new PointerState(hit.getId(), x, y));
                invalidate();
                return true;
            }
            selectedControlId = null;
            invalidate();
            return true;
        }

        if (editButtonVisible && isInsideGear(x, y)) {
            pointers.put(pointerId, new PointerState(POINTER_GEAR, x, y));
            return true;
        }
        RetroTouchControl hit = hitControl(x, y, false);
        if (hit == null) return false;
        PointerState state = new PointerState(hit.getId(), x, y);
        pointers.put(pointerId, state);
        if (hit.getType() == RetroTouchControl.Type.BUTTON && isKnownAction(hit.getActionId())) {
            state.actionPressed = true;
            listener.onAction(hit.getActionId(), true);
        } else if (hit.getType() == RetroTouchControl.Type.MOVE_STICK) {
            updateStick(hit, x, y);
        } else if (hit.getType() == RetroTouchControl.Type.D_PAD) {
            updateDpad(hit, state, x, y);
        }
        invalidate();
        return true;
    }

    private boolean movePointer(int pointerId, float x, float y) {
        PointerState state = pointers.get(pointerId);
        if (state == null) return false;
        if (editing && POINTER_GEAR.equals(state.controlId)) {
            moveSettingsButton(x + state.dragOffsetX, y + state.dragOffsetY);
            state.lastX = x;
            state.lastY = y;
            invalidate();
            return true;
        }
        if (editing && POINTER_TOOLBAR_DRAG.equals(state.controlId)) {
            float top = clamp(y + state.dragOffsetY, 0.0f,
                    Math.max(0.0f, getHeight() - toolbarHeight()));
            toolbarCenterY = getHeight() > 0 ?
                    (top + toolbarHeight() * 0.5f) / getHeight() : Float.NaN;
            state.lastX = x;
            state.lastY = y;
            invalidate();
            return true;
        }
        RetroTouchControl control = findControl(state.controlId);
        if (editing && control != null) {
            float nx = getWidth() > 0 ? x / getWidth() : control.getX();
            float ny = getHeight() > 0 ? y / getHeight() : control.getY();
            control.setPosition(nx, ny);
            state.lastX = x;
            state.lastY = y;
            invalidate();
            return true;
        }
        if (control == null) return true;
        if (control.getType() == RetroTouchControl.Type.MOVE_STICK) {
            updateStick(control, x, y);
        } else if (control.getType() == RetroTouchControl.Type.LOOK_ZONE) {
            updateLook(state, x, y);
        } else if (control.getType() == RetroTouchControl.Type.BUTTON && state.actionPressed &&
                lookWhileHoldingActions.contains(control.getActionId()) &&
                isControlCenterInsideLookZone(control)) {
            updateLook(state, x, y);
        } else if (control.getType() == RetroTouchControl.Type.D_PAD) {
            updateDpad(control, state, x, y);
        }
        state.lastX = x;
        state.lastY = y;
        invalidate();
        return true;
    }

    private void endPointer(int pointerId, float x, float y) {
        PointerState state = pointers.get(pointerId);
        if (state == null) return;
        pointers.remove(pointerId);
        if (POINTER_GEAR.equals(state.controlId)) {
            if (!editing && isInsideGear(x, y)) setEditing(true);
            return;
        }
        if (POINTER_TOOLBAR_DRAG.equals(state.controlId) || POINTER_TOOLBAR.equals(state.controlId)) return;
        if (state.controlId.startsWith("__tool_")) {
            int tool = Integer.parseInt(state.controlId.substring(7));
            if (tool == toolbarIndex(x, y)) applyTool(tool);
            return;
        }
        RetroTouchControl control = findControl(state.controlId);
        if (control != null && control.getType() == RetroTouchControl.Type.BUTTON && state.actionPressed) {
            listener.onAction(control.getActionId(), false);
        } else if (control != null && control.getType() == RetroTouchControl.Type.MOVE_STICK) {
            listener.onMove(0.0f, 0.0f);
        } else if (control != null && control.getType() == RetroTouchControl.Type.D_PAD && state.activeActionId != null) {
            listener.onAction(state.activeActionId, false);
        }
        invalidate();
    }

    private void releaseAll() {
        releaseAll(false);
    }

    private Set<String> releaseAll(boolean forceNeutralMove) {
        Set<String> releasedActions = new HashSet<String>();
        for (int i = 0; i < pointers.size(); ++i) {
            PointerState state = pointers.valueAt(i);
            RetroTouchControl control = findControl(state.controlId);
            if (control != null && control.getType() == RetroTouchControl.Type.BUTTON && state.actionPressed) {
                listener.onAction(control.getActionId(), false);
                releasedActions.add(control.getActionId());
            } else if (control != null && control.getType() == RetroTouchControl.Type.D_PAD && state.activeActionId != null) {
                listener.onAction(state.activeActionId, false);
                releasedActions.add(state.activeActionId);
            }
        }
        if (forceNeutralMove || pointers.size() > 0) listener.onMove(0.0f, 0.0f);
        pointers.clear();
        invalidate();
        return releasedActions;
    }

    private void updateStick(RetroTouchControl control, float x, float y) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.max(1.0f, Math.min(control.getWidth() * getWidth(),
                control.getHeight() * getHeight()) * 0.5f);
        float dx = (x - cx) / radius;
        float dy = (y - cy) / radius;
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        if (length > 1.0f) { dx /= length; dy /= length; }
        if (Math.abs(dx) < 0.08f) dx = 0.0f;
        if (Math.abs(dy) < 0.08f) dy = 0.0f;
        listener.onMove(dx, dy);
    }

    private void updateLook(PointerState state, float x, float y) {
        float base = Math.max(1.0f, Math.min(getWidth(), getHeight()));
        listener.onLook((x - state.lastX) / base * lookSensitivity,
                (y - state.lastY) / base * lookSensitivity);
    }

    private boolean isControlCenterInsideLookZone(RetroTouchControl control) {
        for (RetroTouchControl candidate : controls) {
            if (candidate.getType() != RetroTouchControl.Type.LOOK_ZONE) continue;
            float halfW = candidate.getWidth() * 0.5f;
            float halfH = candidate.getHeight() * 0.5f;
            if (control.getX() >= candidate.getX() - halfW && control.getX() <= candidate.getX() + halfW &&
                    control.getY() >= candidate.getY() - halfH && control.getY() <= candidate.getY() + halfH)
                return true;
        }
        return false;
    }

    private void updateDpad(RetroTouchControl control, PointerState state, float x, float y) {
        String next = dpadActionAt(control, x, y);
        if (next == null ? state.activeActionId == null : next.equals(state.activeActionId)) return;
        if (state.activeActionId != null) listener.onAction(state.activeActionId, false);
        state.activeActionId = next;
        if (next != null) listener.onAction(next, true);
    }

    private String dpadActionAt(RetroTouchControl control, float x, float y) {
        float halfW = Math.max(1.0f, control.getWidth() * getWidth() * 0.5f);
        float halfH = Math.max(1.0f, control.getHeight() * getHeight() * 0.5f);
        float nx = (x - control.getX() * getWidth()) / halfW;
        float ny = (y - control.getY() * getHeight()) / halfH;
        if (Math.abs(nx) < 0.20f && Math.abs(ny) < 0.20f) return null;
        if (Math.abs(nx) > Math.abs(ny)) return nx < 0.0f ? RetroTouchNavigation.LEFT : RetroTouchNavigation.RIGHT;
        return ny < 0.0f ? RetroTouchNavigation.UP : RetroTouchNavigation.DOWN;
    }

    private RetroTouchControl hitControl(float x, float y, boolean includeLookFirst) {
        if (!includeLookFirst) {
            for (int i = controls.size() - 1; i >= 0; --i) {
                RetroTouchControl control = controls.get(i);
                if (control.getType() != RetroTouchControl.Type.LOOK_ZONE && contains(control, x, y)) return control;
            }
        }
        for (int i = controls.size() - 1; i >= 0; --i) {
            RetroTouchControl control = controls.get(i);
            if ((includeLookFirst || control.getType() == RetroTouchControl.Type.LOOK_ZONE) && contains(control, x, y)) return control;
        }
        return null;
    }

    private boolean contains(RetroTouchControl control, float x, float y) {
        float halfW = control.getWidth() * getWidth() * 0.5f;
        float halfH = control.getHeight() * getHeight() * 0.5f;
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        if (control.getType() == RetroTouchControl.Type.BUTTON || control.getType() == RetroTouchControl.Type.MOVE_STICK) {
            float nx = (x - cx) / Math.max(1.0f, halfW);
            float ny = (y - cy) / Math.max(1.0f, halfH);
            return nx * nx + ny * ny <= 1.15f;
        }
        return x >= cx - halfW && x <= cx + halfW && y >= cy - halfH && y <= cy + halfH;
    }

    private void drawControls(Canvas canvas) {
        if (editing) {
            for (RetroTouchControl control : controls) {
                if (control.getType() == RetroTouchControl.Type.LOOK_ZONE) drawLookZone(canvas, control);
            }
        }
        for (RetroTouchControl control : controls) {
            if (control.getType() == RetroTouchControl.Type.MOVE_STICK) drawStick(canvas, control);
            else if (control.getType() == RetroTouchControl.Type.BUTTON) drawButton(canvas, control);
            else if (control.getType() == RetroTouchControl.Type.D_PAD) drawDpad(canvas, control);
            if (editing && control.getId().equals(selectedControlId)) drawSelection(canvas, control);
        }
    }

    private void drawButton(Canvas canvas, RetroTouchControl control) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight()) * 0.5f;
        boolean pressed = isControlPressed(control.getId());
        boolean latched = latchedActions.contains(control.getActionId());
        float displayOpacity = latched ? opacityTwoStepsHigher(control.getOpacity()) : control.getOpacity();
        int alpha = Math.round(255.0f * displayOpacity);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(pressed ? Color.rgb(190, 190, 190) : Color.rgb(105, 105, 105), alpha));
        canvas.drawCircle(cx, cy, radius, paint);
        stroke.setColor(withAlpha(Color.rgb(220, 220, 220), alpha));
        canvas.drawCircle(cx, cy, radius, stroke);
        paint.setColor(withAlpha(Color.WHITE, alpha));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.max(dp(8), Math.min(dp(16), radius * 0.34f)));
        drawButtonLabel(canvas, control.getLabel(), cx, cy, radius, paint);
    }

    private void drawStick(Canvas canvas, RetroTouchControl control) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight()) * 0.5f;
        int alpha = Math.round(255.0f * control.getOpacity());
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(Color.rgb(35, 35, 35), Math.round(alpha * 0.55f)));
        canvas.drawCircle(cx, cy, radius, paint);
        stroke.setColor(withAlpha(Color.rgb(205, 205, 205), alpha));
        canvas.drawCircle(cx, cy, radius, stroke);
        float knobX = cx;
        float knobY = cy;
        PointerState pointer = pointerForControl(control.getId());
        if (pointer != null) {
            float dx = pointer.lastX - cx;
            float dy = pointer.lastY - cy;
            float length = (float) Math.sqrt(dx * dx + dy * dy);
            float max = radius * 0.62f;
            if (length > max) { dx *= max / length; dy *= max / length; }
            knobX += dx;
            knobY += dy;
        }
        paint.setColor(withAlpha(Color.rgb(115, 115, 115), alpha));
        canvas.drawCircle(knobX, knobY, radius * 0.42f, paint);
        paint.setColor(withAlpha(Color.WHITE, alpha));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.max(dp(9), radius * 0.24f));
        drawCenteredText(canvas, "MOVE", cx, cy, paint);
    }

    private void drawDpad(Canvas canvas, RetroTouchControl control) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float size = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight());
        float cell = size / 3.0f;
        int alpha = Math.round(255.0f * control.getOpacity());
        PointerState pointer = pointerForControl(control.getId());
        String active = pointer == null ? null : pointer.activeActionId;
        drawDpadCell(canvas, cx, cy - cell, cell, RetroTouchNavigation.UP, active, alpha);
        drawDpadCell(canvas, cx, cy + cell, cell, RetroTouchNavigation.DOWN, active, alpha);
        drawDpadCell(canvas, cx - cell, cy, cell, RetroTouchNavigation.LEFT, active, alpha);
        drawDpadCell(canvas, cx + cell, cy, cell, RetroTouchNavigation.RIGHT, active, alpha);
        drawDpadCell(canvas, cx, cy, cell, null, active, alpha);
    }

    private void drawDpadCell(Canvas canvas, float cx, float cy, float size, String direction,
                              String active, int alpha) {
        float half = size * 0.48f;
        rect.set(cx - half, cy - half, cx + half, cy + half);
        boolean pressed = direction != null && direction.equals(active);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(pressed ? Color.rgb(190, 190, 190) : Color.rgb(70, 70, 70), alpha));
        canvas.drawRoundRect(rect, size * 0.13f, size * 0.13f, paint);
        stroke.setColor(withAlpha(Color.rgb(220, 220, 220), alpha));
        canvas.drawRoundRect(rect, size * 0.13f, size * 0.13f, stroke);
        if (direction == null) return;
        paint.setColor(withAlpha(Color.WHITE, alpha));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.max(dp(9), size * 0.34f));
        String arrow = RetroTouchNavigation.UP.equals(direction) ? "▲" :
                (RetroTouchNavigation.DOWN.equals(direction) ? "▼" :
                        (RetroTouchNavigation.LEFT.equals(direction) ? "◀" : "▶"));
        drawCenteredText(canvas, arrow, cx, cy, paint);
    }

    private void drawLookZone(Canvas canvas, RetroTouchControl control) {
        controlRect(control, rect);
        paint.setStyle(Paint.Style.FILL);
        int alpha = Math.round(90.0f * control.getOpacity());
        paint.setColor(withAlpha(Color.rgb(125, 125, 125), alpha));
        canvas.drawRoundRect(rect, dp(12), dp(12), paint);
        stroke.setColor(withAlpha(Color.rgb(205, 205, 205), Math.max(35, Math.round(255.0f * control.getOpacity()))));
        canvas.drawRoundRect(rect, dp(12), dp(12), stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(15));
        paint.setColor(withAlpha(Color.WHITE, Math.max(55, Math.round(255.0f * control.getOpacity()))));
        drawCenteredText(canvas, "LOOK AREA", rect.centerX(), rect.centerY(), paint);
    }

    private void drawSelection(Canvas canvas, RetroTouchControl control) {
        controlRect(control, rect);
        stroke.setColor(Color.WHITE);
        stroke.setStrokeWidth(dp(3));
        canvas.drawRoundRect(rect, dp(8), dp(8), stroke);
        stroke.setStrokeWidth(dp(2));
    }

    private void drawGear(Canvas canvas) {
        RectF gear = gearRect();
        int alpha = Math.round(255.0f * settingsOpacity);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(Color.BLACK, alpha));
        canvas.drawCircle(gear.centerX(), gear.centerY(), gear.width() * 0.5f, paint);
        stroke.setStrokeWidth(dp(1.0f));
        stroke.setColor(withAlpha(Color.WHITE, alpha));
        canvas.drawCircle(gear.centerX(), gear.centerY(), gear.width() * 0.5f, stroke);
        stroke.setStrokeWidth(dp(2.0f));
        paint.setColor(withAlpha(Color.WHITE, alpha));
        paint.setStrokeWidth(dp(1.0f));
        for (int i = -1; i <= 1; ++i) {
            float yy = gear.centerY() + i * gear.height() * 0.19f;
            float left = gear.left + gear.width() * 0.27f;
            float right = gear.right - gear.width() * 0.27f;
            canvas.drawLine(left, yy, right, yy, paint);
            float knob = i == 0 ? gear.centerX() - gear.width() * 0.10f : gear.centerX() + i * gear.width() * 0.08f;
            canvas.drawCircle(knob, yy, dp(1.1f), paint);
        }
        if (editing && POINTER_GEAR.equals(selectedControlId)) {
            stroke.setColor(Color.WHITE);
            stroke.setStrokeWidth(dp(3));
            canvas.drawCircle(gear.centerX(), gear.centerY(), gear.width() * 0.60f, stroke);
            stroke.setStrokeWidth(dp(2));
        }
    }

    private void drawToolbar(Canvas canvas) {
        float top = toolbarTop();
        float bottom = top + toolbarHeight();
        float handleBottom = top + toolbarHandleHeight();
        float itemWidth = getWidth() / (float) TOOL_LABELS.length;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(Color.BLACK, 225));
        canvas.drawRect(0, top, getWidth(), bottom, paint);
        paint.setColor(withAlpha(Color.DKGRAY, 235));
        canvas.drawRect(0, top, getWidth(), handleBottom, paint);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize(Math.max(dp(9), Math.min(dp(13), toolbarHandleHeight() * 0.48f)));
        paint.setColor(Color.WHITE);
        String selected = selectedControlId == null ? "Tap a control, then drag it" :
                (POINTER_GEAR.equals(selectedControlId) ? "Selected: SETTINGS" : "Selected: " + selectedControlId);
        drawCenteredText(canvas, "\u2195 DRAG   " + selected, dp(10), top + toolbarHandleHeight() * 0.5f, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.max(dp(8), Math.min(dp(13), itemWidth * 0.17f)));
        for (int i = 0; i < TOOL_LABELS.length; ++i) {
            float left = i * itemWidth;
            rect.set(left + dp(2), handleBottom + dp(3), left + itemWidth - dp(2), bottom - dp(4));
            boolean enabled = isToolEnabled(i);
            paint.setColor(withAlpha(i == 7 ? accentColor : Color.DKGRAY, enabled ? 235 : 80));
            canvas.drawRoundRect(rect, dp(5), dp(5), paint);
            paint.setColor(withAlpha(Color.WHITE, enabled ? 255 : 85));
            drawCenteredText(canvas, TOOL_LABELS[i], rect.centerX(), rect.centerY(), paint);
        }
    }

    private void applyTool(int tool) {
        if (!isToolEnabled(tool)) return;
        RetroTouchControl selected = findControl(selectedControlId);
        boolean settingsSelected = POINTER_GEAR.equals(selectedControlId);
        if (tool == 0) addButton();
        else if (tool == 1 && selected != null && selected.getType() == RetroTouchControl.Type.BUTTON) cycleAction(selected);
        else if (tool == 2 && settingsSelected) scaleSettingsButton(0.86f);
        else if (tool == 3 && settingsSelected) scaleSettingsButton(1.16f);
        else if (tool == 4 && settingsSelected) settingsOpacity = nextOpacity(settingsOpacity);
        else if (tool == 2 && selected != null) selected.scale(0.86f);
        else if (tool == 3 && selected != null) selected.scale(1.16f);
        else if (tool == 4 && selected != null) selected.cycleOpacity();
        else if (tool == 5 && selected != null) {
            controls.remove(selected);
            selectedControlId = null;
        } else if (tool == 6) resetToDefault();
        else if (tool == 7) {
            saveLayout();
            setEditing(false);
        }
        invalidate();
    }

    private boolean isToolEnabled(int tool) {
        RetroTouchControl selected = findControl(selectedControlId);
        boolean settingsSelected = POINTER_GEAR.equals(selectedControlId);
        if (tool == 0) return actions.size() > 0 && buttonCount() < RetroTouchLayout.MAX_BUTTONS;
        if (tool == 1) return selected != null && selected.getType() == RetroTouchControl.Type.BUTTON;
        if (tool >= 2 && tool <= 4) return selected != null || settingsSelected;
        // SETTINGS is deliberately permanent: DELETE is visibly disabled and cannot remove it.
        if (tool == 5) return selected != null;
        return tool == 6 || tool == 7;
    }

    private int buttonCount() {
        int count = 0;
        for (RetroTouchControl control : controls)
            if (control.getType() == RetroTouchControl.Type.BUTTON) ++count;
        return count;
    }

    private void addButton() {
        if (buttonCount() >= RetroTouchLayout.MAX_BUTTONS || actions.isEmpty()) return;
        int number = 1;
        while (findControl("button_" + number) != null) ++number;
        RetroTouchAction first = actions.values().iterator().next();
        RetroTouchControl added = RetroTouchControl.button("button_" + number, first.getId(), first.getLabel(),
                0.52f, 0.50f, 0.12f);
        controls.add(added);
        selectedControlId = added.getId();
    }

    private void cycleAction(RetroTouchControl control) {
        if (actions.isEmpty()) return;
        List<RetroTouchAction> list = new ArrayList<RetroTouchAction>(actions.values());
        int current = -1;
        for (int i = 0; i < list.size(); ++i) if (list.get(i).getId().equals(control.getActionId())) current = i;
        RetroTouchAction next = list.get((current + 1) % list.size());
        control.setAction(next.getId(), next.getLabel());
    }

    private void refreshControlLabels() {
        for (RetroTouchControl control : controls) {
            if (control.getType() != RetroTouchControl.Type.BUTTON) continue;
            RetroTouchAction action = actions.get(control.getActionId());
            if (action != null) control.setAction(action.getId(), action.getLabel());
        }
    }

    private boolean isKnownAction(String id) { return actions.containsKey(id); }

    private RetroTouchControl findControl(String id) {
        if (id == null) return null;
        for (RetroTouchControl control : controls) if (id.equals(control.getId())) return control;
        return null;
    }

    private PointerState pointerForControl(String id) {
        for (int i = 0; i < pointers.size(); ++i) if (id.equals(pointers.valueAt(i).controlId)) return pointers.valueAt(i);
        return null;
    }

    private boolean isControlPressed(String id) {
        if (pointerForControl(id) != null) return true;
        RetroTouchControl control = findControl(id);
        return control != null && latchedActions.contains(control.getActionId());
    }

    private RectF gearRect() {
        float originalSize = Math.max(dp(38), Math.min(dp(52), Math.min(getWidth(), getHeight()) * 0.105f));
        float size = originalSize * settingsScale;
        float margin = dp(10);
        float cx = Float.isNaN(settingsX) ? getWidth() - margin - size * 0.5f : settingsX * getWidth();
        float cy = Float.isNaN(settingsY) ? margin + size * 0.5f : settingsY * getHeight();
        cx = clamp(cx, size * 0.5f, Math.max(size * 0.5f, getWidth() - size * 0.5f));
        cy = clamp(cy, size * 0.5f, Math.max(size * 0.5f, getHeight() - size * 0.5f));
        return new RectF(cx - size * 0.5f, cy - size * 0.5f,
                cx + size * 0.5f, cy + size * 0.5f);
    }

    private void moveSettingsButton(float centerX, float centerY) {
        RectF gear = gearRect();
        float half = gear.width() * 0.5f;
        centerX = clamp(centerX, half, Math.max(half, getWidth() - half));
        centerY = clamp(centerY, half, Math.max(half, getHeight() - half));
        settingsX = getWidth() > 0 ? centerX / getWidth() : Float.NaN;
        settingsY = getHeight() > 0 ? centerY / getHeight() : Float.NaN;
    }

    private void scaleSettingsButton(float factor) {
        RectF before = gearRect();
        settingsX = getWidth() > 0 ? before.centerX() / getWidth() : settingsX;
        settingsY = getHeight() > 0 ? before.centerY() / getHeight() : settingsY;
        settingsScale = clamp(settingsScale * factor, 0.40f, 1.40f);
        moveSettingsButton(settingsX * getWidth(), settingsY * getHeight());
    }

    private float nextOpacity(float opacity) {
        if (opacity < 0.10f) return 0.14f;
        if (opacity < 0.20f) return 0.28f;
        if (opacity < 0.42f) return 0.58f;
        if (opacity < 0.75f) return 0.90f;
        return 0.07f;
    }

    private boolean isInsideGear(float x, float y) {
        RectF gear = gearRect();
        float dx = x - gear.centerX();
        float dy = y - gear.centerY();
        // Keep a comfortable invisible touch target although the icon itself is deliberately tiny.
        float radius = Math.max(dp(24), gear.width() * 0.65f);
        return dx * dx + dy * dy <= radius * radius;
    }

    private float toolbarHeight() {
        return Math.min(getHeight(), Math.max(dp(76), getHeight() * 0.17f));
    }

    private float toolbarHandleHeight() {
        return Math.min(toolbarHeight() * 0.32f, Math.max(dp(18), toolbarHeight() * 0.25f));
    }

    private float toolbarTop() {
        float height = toolbarHeight();
        float top = Float.isNaN(toolbarCenterY) ? getHeight() - height :
                toolbarCenterY * getHeight() - height * 0.5f;
        return clamp(top, 0.0f, Math.max(0.0f, getHeight() - height));
    }

    private boolean isInsideToolbar(float x, float y) {
        return editing && x >= 0.0f && x < getWidth() &&
                y >= toolbarTop() && y <= toolbarTop() + toolbarHeight();
    }

    private boolean isInsideToolbarHandle(float x, float y) {
        return isInsideToolbar(x, y) && y <= toolbarTop() + toolbarHandleHeight();
    }

    private int toolbarIndex(float x, float y) {
        float top = toolbarTop() + toolbarHandleHeight();
        if (!editing || y < top || y > toolbarTop() + toolbarHeight() || x < 0 || x >= getWidth()) return -1;
        return Math.min(TOOL_LABELS.length - 1, (int) (x / (getWidth() / (float) TOOL_LABELS.length)));
    }

    private void controlRect(RetroTouchControl control, RectF output) {
        float halfW = control.getWidth() * getWidth() * 0.5f;
        float halfH = control.getHeight() * getHeight() * 0.5f;
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        output.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH);
    }

    private void drawCenteredText(Canvas canvas, String text, float x, float y, Paint p) {
        Paint.FontMetrics fm = p.getFontMetrics();
        canvas.drawText(text, x, y - (fm.ascent + fm.descent) * 0.5f, p);
    }

    private void drawButtonLabel(Canvas canvas, String value, float x, float y,
                                 float radius, Paint p) {
        String label = normalizeLabel(value);
        float maximumWidth = radius * 1.55f;
        String[] lines = splitButtonLabel(label, maximumWidth, p);
        fitButtonLabel(lines, maximumWidth, radius * 1.40f, p);

        if (lines.length == 1) {
            drawCenteredText(canvas, lines[0], x, y, p);
            return;
        }
        Paint.FontMetrics fm = p.getFontMetrics();
        float lineHeight = (fm.descent - fm.ascent) * 0.82f;
        float centerOffset = -(fm.ascent + fm.descent) * 0.5f;
        canvas.drawText(lines[0], x, y + centerOffset - lineHeight * 0.5f, p);
        canvas.drawText(lines[1], x, y + centerOffset + lineHeight * 0.5f, p);
    }

    private String normalizeLabel(String value) {
        if (value == null) return "";
        String source = value.toUpperCase().replace("\r\n", "\n").replace('\r', '\n').trim();
        StringBuilder result = new StringBuilder(source.length());
        boolean previousSpace = false;
        for (int i = 0; i < source.length(); ++i) {
            char c = source.charAt(i);
            if (c == '\n') {
                while (result.length() > 0 && result.charAt(result.length() - 1) == ' ')
                    result.deleteCharAt(result.length() - 1);
                if (result.length() > 0 && result.charAt(result.length() - 1) != '\n')
                    result.append('\n');
                previousSpace = false;
            } else if (Character.isWhitespace(c)) {
                if (!previousSpace && result.length() > 0 && result.charAt(result.length() - 1) != '\n')
                    result.append(' ');
                previousSpace = true;
            } else {
                result.append(c);
                previousSpace = false;
            }
        }
        while (result.length() > 0 &&
                (result.charAt(result.length() - 1) == ' ' || result.charAt(result.length() - 1) == '\n'))
            result.deleteCharAt(result.length() - 1);
        return result.toString();
    }

    private String[] splitButtonLabel(String label, float maximumWidth, Paint p) {
        int explicitBreak = label.indexOf('\n');
        if (explicitBreak >= 0) {
            String first = label.substring(0, explicitBreak).trim();
            String second = label.substring(explicitBreak + 1).replace('\n', ' ').trim();
            if (first.length() == 0) return new String[] { second };
            if (second.length() == 0) return new String[] { first };
            return new String[] { first, second };
        }
        if (p.measureText(label) <= maximumWidth || label.indexOf(' ') < 0)
            return new String[] { label };

        String bestFirst = label;
        String bestSecond = "";
        float bestWidth = Float.MAX_VALUE;
        float bestBalance = Float.MAX_VALUE;
        for (int i = 1; i < label.length() - 1; ++i) {
            if (label.charAt(i) != ' ') continue;
            String first = label.substring(0, i).trim();
            String second = label.substring(i + 1).trim();
            float firstWidth = p.measureText(first);
            float secondWidth = p.measureText(second);
            float widest = Math.max(firstWidth, secondWidth);
            float balance = Math.abs(firstWidth - secondWidth);
            if (widest < bestWidth || (widest == bestWidth && balance < bestBalance)) {
                bestFirst = first;
                bestSecond = second;
                bestWidth = widest;
                bestBalance = balance;
            }
        }
        return bestSecond.length() == 0 ? new String[] { label } :
                new String[] { bestFirst, bestSecond };
    }

    private void fitButtonLabel(String[] lines, float maximumWidth, float maximumHeight, Paint p) {
        float widest = 0.0f;
        for (String line : lines) widest = Math.max(widest, p.measureText(line));
        Paint.FontMetrics fm = p.getFontMetrics();
        float fontHeight = fm.descent - fm.ascent;
        float totalHeight = lines.length == 1 ? fontHeight : fontHeight * 1.82f;
        float widthScale = widest > 0.0f ? maximumWidth / widest : 1.0f;
        float heightScale = totalHeight > 0.0f ? maximumHeight / totalHeight : 1.0f;
        float scale = Math.min(1.0f, Math.min(widthScale, heightScale));
        if (scale < 1.0f) p.setTextSize(Math.max(1.0f, p.getTextSize() * scale));
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00ffffff) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private float opacityTwoStepsHigher(float opacity) {
        if (opacity < 0.10f) return 0.28f;
        if (opacity < 0.20f) return 0.58f;
        if (opacity < 0.42f) return 0.90f;
        return 1.0f;
    }

    private float clamp01(float value) {
        return Float.isNaN(value) ? Float.NaN : clamp(value, 0.0f, 1.0f);
    }

    private float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private static final class PointerState {
        final String controlId;
        float lastX;
        float lastY;
        float dragOffsetX;
        float dragOffsetY;
        boolean actionPressed;
        String activeActionId;

        PointerState(String controlId, float x, float y) {
            this.controlId = controlId;
            this.lastX = x;
            this.lastY = y;
        }
    }
}
