package com.ast.retrotouch;

/** Stable action IDs emitted by a {@link RetroTouchControl.Type#D_PAD}. */
public final class RetroTouchNavigation {
    public static final String UP = "nav_up";
    public static final String DOWN = "nav_down";
    public static final String LEFT = "nav_left";
    public static final String RIGHT = "nav_right";

    private RetroTouchNavigation() { }
}
