package com.ast.retrotouch;

/** Host-game adapter. All callbacks run on Android's UI thread. */
public interface RetroTouchListener {
    void onAction(String actionId, boolean pressed);
    void onMove(float x, float y);
    void onLook(float deltaX, float deltaY);
    void onEditorStateChanged(boolean editing);
}
