package com.ast.retrotouch;

/** Selects which optional RetroTouch surface is active. */
public enum RetroTouchMode {
    /** RetroTouch draws nothing and lets screen touches pass through to the host game. */
    OFF,
    /** The game's normal movement, look and action layout. */
    GAMEPLAY,
    /** An optional digital D-pad plus host-defined action buttons. */
    NAVIGATION
}
