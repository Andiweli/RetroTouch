# Changelog

## 1.0.0-beta.4 - 2026-08-28

- Made the settings button selectable, movable, resizable and opacity-adjustable in the editor.
- Kept the settings button permanent: `DELETE` is visibly disabled while it is selected.
- Added a dedicated drag handle that moves the editor toolbar vertically.
- Persisted settings-button and toolbar placement independently for every game/layout ID.
- Preserved all existing saved control layouts; missing editor-position data uses compatible
  defaults and is added on the next save.
- Kept the public Java API unchanged from beta.3, allowing an AAR-only update in existing games.

## 1.0.0-beta.3 - 2026-08-28

- Added public `resetInputState()` for respawn, level transitions, savegame loading, focus loss
  and host-engine input resets.
- Added `releaseAllInputs()` as a descriptive alias.
- Reset now releases held buttons and D-pad directions, forces `onMove(0, 0)`, discards move/look
  pointers and clears RetroTouch visual latches while preserving mode and layouts.
- Documented that games must clear their own toggle variables at the same reset point.
- Updated the sample Activity to reset RetroTouch during `onPause()`.

## 1.0.0-beta.2 - 2026-08-27

- Replaced Breathless-specific weapon-label checks with universal label layout.
- Automatically wraps arbitrary button labels to a maximum of two balanced lines when required.
- Supports an explicit newline supplied by a host game.
- Automatically reduces the already compact Breathless font size until every label fits inside
  its button.
- Preserves complete labels instead of abbreviating longer action names to initials.

## 1.0.0-beta.1 - 2026-08-27

- Promoted the Breathless-tested RetroTouch 0.2.2 codebase to the first public beta.
- Added complete English and German integration, usage, update and troubleshooting guides.
- Documented the stable AAR boundary, host responsibilities and recommended Unreal/UT99 test path.
- No runtime behavior or saved-layout format changed from 0.2.2.

## 0.2.2 - 2026-08-27

- Increased the settings icon by 50 percent from its 0.2.1 size.
- Raised the settings icon from opacity level 2 to level 3.

## 0.2.1 - 2026-08-27

- Added opt-in simultaneous relative look while holding selected button actions inside a look zone.
- Breathless FIRE now remains held while the same finger turns inside the LOOK AREA.
- Reduced the settings icon to half size and opacity level 2 while preserving its touch target.
- Added vendor-independent detection for built-in, USB and Bluetooth game controllers.
- Breathless now shows RetroTouch only while no game controller is available.

## 0.2.0 - 2026-08-27

- Added optional `OFF`, `GAMEPLAY` and `NAVIGATION` modes.
- Added a configurable digital navigation-pad control with stable direction action IDs.
- Added independent, persistent gameplay and navigation layouts.
- Kept `setDefaultLayout()` as a backwards-compatible gameplay-layout alias.
- Added a standalone sample flow that switches between gameplay and navigation.
- Reworked the Breathless example around a replaceable AAR and a thin game-owned bridge.

## 0.1.3 - 2026-08-27

- Latched buttons are rendered two opacity steps brighter, capped at full opacity.

## 0.1.2 - 2026-08-27

- Added a host-controlled latched-action visual state for toggle buttons.
- Breathless double-tap on RUN now toggles running while the move stick is active.
- Weapon labels use compact two-line text and all button labels are one size smaller.
- Move sticks now reach full input at the visible ring edge on every aspect ratio.

## 0.1.1 - 2026-08-27

- A screen touch now cancels controller auto-hide immediately.
- Controller input used to leave a menu no longer delays Breathless touch controls.
- Added two nearly invisible opacity levels.
- Button and stick fills, rings and labels now share the selected opacity.
- Gameplay controls use neutral greys instead of blue.
- Look zones are visible only in layout-edit mode.

## 0.1.0 - 2026-08-26

- Initial clean-room implementation.
- API 16 through API 36 support.
- Up to 16 configurable buttons, two movement sticks and two look zones.
- Normalized layouts for phones, tablets, ultrawide and Automotive displays.
- Stable string action IDs with a small host-game callback adapter.
- Multitouch, move stick, relative FPS look area and holdable buttons.
- Built-in in-game layout editor with add, remap, move, resize, opacity, delete and reset.
- Persistent per-game layouts and optional controller-triggered auto-hide.
- Standalone demonstration app and Breathless integration example.
