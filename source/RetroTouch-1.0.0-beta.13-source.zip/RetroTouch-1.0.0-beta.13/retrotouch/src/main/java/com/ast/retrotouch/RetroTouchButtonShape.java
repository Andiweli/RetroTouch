package com.ast.retrotouch;

/**
 * Shape of an action button (1.0.0-beta.8, ROUNDED_RECT and CAPSULE since 1.0.0-beta.10, KIDNEY,
 * BUMPER and TRIGGER since 1.0.0-beta.13).
 */
public enum RetroTouchButtonShape {
    /**
     * Chosen from the label: START, SELECT and MENU are RECTANGLE; L, R and trigger labels
     * (ZL, ZR, L1, R1, L2, R2, LB, RB, LT, RT) are SHOULDER; every other button is ROUND.
     */
    AUTO,
    /** A circle, as in earlier versions. */
    ROUND,
    /** A compact rectangle, as for START, SELECT or MENU. */
    RECTANGLE,
    /** A rectangle slightly larger than RECTANGLE, as for L, R or triggers. */
    SHOULDER,
    /**
     * A rectangle with clearly rounded corners (35 % of its height). The button's size is its
     * height; the width follows the control's aspect ratio.
     */
    ROUNDED_RECT,
    /** A pill whose ends are half circles. The size is its height; the width follows the aspect ratio. */
    CAPSULE,
    /**
     * A kidney or bean, hollow on top, as the GameCube's X and Y buttons (1.0.0-beta.13). The size is
     * its height; the width follows the aspect ratio, 1.6 unless set. Turn it with a skin look's rotation.
     */
    KIDNEY,
    /**
     * A shoulder bumper (1.0.0-beta.13) for L/R, L1/R1 or LB/RB: strongly rounded on top, slightly at
     * the bottom. The size is its height; the width follows the aspect ratio, 2.2 unless set.
     */
    BUMPER,
    /**
     * A trigger (1.0.0-beta.13) for L2/R2, LT/RT or ZL/ZR: a rounded top over straight sides. The size
     * is its height; the width follows the aspect ratio, 0.8 unless set.
     */
    TRIGGER
}
