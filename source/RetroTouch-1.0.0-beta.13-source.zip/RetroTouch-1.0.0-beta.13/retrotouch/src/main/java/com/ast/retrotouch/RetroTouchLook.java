package com.ast.retrotouch;

/**
 * How one action looks in a skin (1.0.0-beta.13): label, icon, colors, shape, aspect ratio,
 * rotation and content offset. Every value is optional; unset values fall back to the action, the
 * control and the skin. Immutable: each {@code with...} method returns a copy.
 */
public final class RetroTouchLook {
    private final String label;
    private final RetroTouchIcon icon;
    private final RetroTouchColors colors;
    private final RetroTouchButtonShape shape;
    private final float aspect;
    private final float rotation;
    private final float offsetX;
    private final float offsetY;

    /** A look that sets nothing. */
    public RetroTouchLook() {
        this(null, null, null, null, Float.NaN, 0.0f, 0.0f, 0.0f);
    }

    private RetroTouchLook(String label, RetroTouchIcon icon, RetroTouchColors colors, RetroTouchButtonShape shape,
                           float aspect, float rotation, float offsetX, float offsetY) {
        this.label = label;
        this.icon = icon;
        this.colors = colors;
        this.shape = shape;
        this.aspect = aspect;
        this.rotation = rotation;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
    }

    /** The text shown instead of the action's label, for example "L2" or "LS"; null keeps the action's. */
    public RetroTouchLook withLabel(String value) {
        return new RetroTouchLook(value, icon, colors, shape, aspect, rotation, offsetX, offsetY);
    }

    /** The icon shown instead of a label; it wins over any label. Null shows the label. */
    public RetroTouchLook withIcon(RetroTouchIcon value) {
        if (value != null) value.path();
        return new RetroTouchLook(label, value, colors, shape, aspect, rotation, offsetX, offsetY);
    }

    /** Colors for this action in the skin; they win over the control's and the action's colors. */
    public RetroTouchLook withColors(RetroTouchColors value) {
        return new RetroTouchLook(label, icon, value, shape, aspect, rotation, offsetX, offsetY);
    }

    /** The button shape in this skin; null or AUTO keeps the shape the button has without the skin. */
    public RetroTouchLook withShape(RetroTouchButtonShape value) {
        RetroTouchButtonShape stored = value == RetroTouchButtonShape.AUTO ? null : value;
        return new RetroTouchLook(label, icon, colors, stored, aspect, rotation, offsetX, offsetY);
    }

    /** Width over height for shapes that use one (ROUNDED_RECT, CAPSULE, KIDNEY, BUMPER, TRIGGER), 0.25 to 6. */
    public RetroTouchLook withAspect(float value) {
        if (!(value > 0.0f) || Float.isInfinite(value)) throw new IllegalArgumentException("Aspect must be positive");
        float stored = Math.max(0.25f, Math.min(6.0f, value));
        return new RetroTouchLook(label, icon, colors, shape, stored, rotation, offsetX, offsetY);
    }

    /**
     * Turns the button's shape clockwise by this many degrees, for example a KIDNEY for X and Y. The
     * label or icon stays upright; touch follows the turned shape.
     */
    public RetroTouchLook withRotation(float degrees) {
        if (Float.isNaN(degrees) || Float.isInfinite(degrees)) throw new IllegalArgumentException("Rotation must be finite");
        return new RetroTouchLook(label, icon, colors, shape, aspect, degrees % 360.0f, offsetX, offsetY);
    }

    /**
     * Moves the label or icon by these fractions of the button's height (right and down positive),
     * -0.5 to 0.5, for a fine optical correction.
     */
    public RetroTouchLook withOffset(float dx, float dy) {
        if (Float.isNaN(dx) || Float.isNaN(dy)) throw new IllegalArgumentException("Offset must be a number");
        return new RetroTouchLook(label, icon, colors, shape, aspect, rotation,
                Math.max(-0.5f, Math.min(0.5f, dx)), Math.max(-0.5f, Math.min(0.5f, dy)));
    }

    public String getLabel() { return label; }
    public RetroTouchIcon getIcon() { return icon; }
    public RetroTouchColors getColors() { return colors; }
    /** The shape, or null when the look keeps the button's own. */
    public RetroTouchButtonShape getShape() { return shape; }
    /** The aspect ratio, or NaN when unset. */
    public float getAspect() { return aspect; }
    public float getRotation() { return rotation; }
    public float getOffsetX() { return offsetX; }
    public float getOffsetY() { return offsetY; }
}
