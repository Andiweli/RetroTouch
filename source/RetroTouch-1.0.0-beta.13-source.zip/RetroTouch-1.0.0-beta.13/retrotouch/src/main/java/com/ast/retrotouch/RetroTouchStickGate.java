package com.ast.retrotouch;

/** The outline around a stick in a skin (1.0.0-beta.13). The reported values are the same for both. */
public enum RetroTouchStickGate {
    /** A circle, as before. The default. */
    ROUND,
    /** An octagon, as the gate of a GameCube stick; the knob follows the octagon's edge. */
    OCTAGON
}
