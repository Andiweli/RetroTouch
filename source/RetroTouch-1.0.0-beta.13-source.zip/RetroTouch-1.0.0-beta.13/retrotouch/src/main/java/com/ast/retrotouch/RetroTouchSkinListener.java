package com.ast.retrotouch;

/**
 * Optional callback (1.0.0-beta.13) when the player switches the skin with the editor's style
 * button. Register it with RetroTouchView.setSkinListener, or let the main listener implement it as
 * well. Runs on Android's UI thread.
 */
public interface RetroTouchSkinListener {
    void onSkinChanged(String skinId);
}
