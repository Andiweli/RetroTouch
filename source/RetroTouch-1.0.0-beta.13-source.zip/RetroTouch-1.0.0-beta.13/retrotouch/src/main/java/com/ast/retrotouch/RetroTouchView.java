package com.ast.retrotouch;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Resolution-independent multitouch controls that can be layered above any Android game view.
 * The host registers actions and receives abstract callbacks; RetroTouch never depends on a
 * specific game engine.
 */
public final class RetroTouchView extends View {
    private static final String TAG = "RetroTouch";
    private static final String PREFS_NAME = "retrotouch_layouts";
    private static final String POINTER_GEAR = "__gear";
    private static final String POINTER_TOOLBAR = "__toolbar";
    private static final String POINTER_TOOLBAR_DRAG = "__toolbar_drag";
    private static final long DEFAULT_CONTROLLER_HIDE_MS = 3000L;
    private static final float DEFAULT_SETTINGS_OPACITY = 0.28f;
    private static final float DEFAULT_SETTINGS_SIZE_SCALE = 0.75f;
    private static final float BORDER_WIDTH_DP = 2.5f;
    private static final String[] TOOL_LABELS = {
            "ADD", "ACTION", "SMALL", "LARGE", "ALPHA", "DELETE", "RESET", "SAVE"
    };
    // Editor tools by ID; TOOL_STYLE (the button-style toggle) shows only with two or more styles.
    private static final int TOOL_ADD = 0;
    private static final int TOOL_RESET = 6;
    private static final int TOOL_SAVE = 7;
    private static final int TOOL_STYLE = 8;
    private static final int[] TOOLS = { 0, 1, 2, 3, 4, 5, 6, 7 };
    private static final int[] TOOLS_WITH_STYLE = { 0, 1, 2, 3, 4, 5, TOOL_STYLE, 6, 7 };
    // ICONS style: border 7 % of the smaller side, icon box 55 % of a circle and 61 % of a rectangle's height
    private static final float ICON_BORDER = 0.07f;
    // Built-in grey look, used whenever the host supplies no colors.
    private static final RetroTouchColors BUTTON_COLORS = new RetroTouchColors(
            Color.rgb(105, 105, 105), Color.rgb(190, 190, 190), Color.rgb(220, 220, 220), Color.WHITE);
    private static final RetroTouchColors STICK_COLORS = new RetroTouchColors(
            Color.rgb(115, 115, 115), Color.rgb(115, 115, 115), Color.rgb(205, 205, 205), Color.WHITE);
    private static final RetroTouchColors DPAD_COLORS = new RetroTouchColors(
            Color.rgb(70, 70, 70), Color.rgb(190, 190, 190), Color.rgb(220, 220, 220), Color.WHITE);
    // Labels that RetroTouchButtonShape.AUTO draws as rectangles.
    private static final Set<String> RECTANGLE_LABELS = new HashSet<String>(Arrays.asList("START", "SELECT", "MENU"));
    private static final Set<String> SHOULDER_LABELS = new HashSet<String>(Arrays.asList(
            "L", "R", "ZL", "ZR", "L1", "R1", "L2", "R2", "LB", "RB", "LT", "RT"));

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconStroke = new Paint(Paint.ANTI_ALIAS_FLAG); // ICONS style borders, rings and icons
    private final Path dpadPath = new Path();
    private final RectF iconRect = new RectF();
    private final RectF rect = new RectF();
    private final RectF touchRect = new RectF();
    private final Rect textBounds = new Rect();
    private final Rect secondTextBounds = new Rect();
    private final Path shapePath = new Path();      // skins and KIDNEY, BUMPER, TRIGGER shapes
    private final float[] shapeRadii = new float[8];
    private static final RetroTouchIcon[] CHEVRONS = {
            RetroTouchIcon.CHEVRON_UP, RetroTouchIcon.CHEVRON_DOWN, RetroTouchIcon.CHEVRON_LEFT, RetroTouchIcon.CHEVRON_RIGHT };
    private static final String[] DIRECTIONS = {
            RetroTouchNavigation.UP, RetroTouchNavigation.DOWN, RetroTouchNavigation.LEFT, RetroTouchNavigation.RIGHT };
    private final SparseArray<PointerState> pointers = new SparseArray<PointerState>();
    private final LinkedHashMap<String, RetroTouchAction> actions = new LinkedHashMap<String, RetroTouchAction>();
    private final List<RetroTouchControl> controls = new ArrayList<RetroTouchControl>();
    private final Set<String> latchedActions = new HashSet<String>();
    private final Set<String> lookWhileHoldingActions = new HashSet<String>();
    // actions that are analog sticks (registerStickAction): a control with one is a stick
    private final Set<String> stickActions = new HashSet<String>();
    private int maxSticks = 2; // sticks the editor lets a layout hold, the move stick included
    // host-chosen button shapes by action ID; actions without an entry use RetroTouchButtonShape.AUTO
    private final Map<String, RetroTouchButtonShape> buttonShapes = new HashMap<String, RetroTouchButtonShape>();
    // host-chosen aspect ratios (width / height) by action ID for ROUNDED_RECT and CAPSULE buttons
    private final Map<String, Float> buttonAspects = new HashMap<String, Float>();

    private RetroTouchListener listener = new RetroTouchAdapter();
    private RetroTouchLayout gameplayLayout;
    private RetroTouchLayout navigationLayout;
    private RetroTouchLayout defaultLayout;
    private RetroTouchMode mode = RetroTouchMode.GAMEPLAY;
    private String selectedControlId;
    private boolean overlayEnabled = true;
    private boolean editing;
    private boolean editButtonVisible = true;
    private boolean autoHideOnController = true;
    private long controllerHiddenUntil;
    private float lookSensitivity = 1.0f;
    private int accentColor = Color.rgb(75, 205, 245);
    private RetroTouchColors defaultColors;
    private final List<RetroTouchButtonStyle> availableStyles =
            new ArrayList<RetroTouchButtonStyle>(Collections.singletonList(RetroTouchButtonStyle.LABELS));
    private RetroTouchButtonStyle defaultButtonStyle = RetroTouchButtonStyle.LABELS;
    private RetroTouchButtonStyle chosenStyle; // the player's or app's choice, null until one is made
    private String styleKey;                   // preference key of the choice, per game
    private String labelsToggleName = "Labels";
    private String iconsToggleName = "Icons";
    private RetroTouchStyleListener styleListener;
    // skins (1.0.0-beta.13): named looks the editor's style button cycles through
    private final List<RetroTouchSkin> skins = new ArrayList<RetroTouchSkin>();
    private String defaultSkinId;
    private String chosenSkinId;               // the player's or app's choice, null until one is made
    private String skinKey;                    // preference key of the choice, per game
    private RetroTouchSkinListener skinListener;
    private float settingsX = Float.NaN;
    private float settingsY = Float.NaN;
    private float settingsScale = DEFAULT_SETTINGS_SIZE_SCALE;
    private float settingsOpacity = DEFAULT_SETTINGS_OPACITY;
    private float toolbarCenterY = Float.NaN;
    private int safeInsetLeft, safeInsetTop, safeInsetRight, safeInsetBottom; // editor bar and gear default only

    public RetroTouchView(Context context) {
        this(context, null);
    }

    public RetroTouchView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(true);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(BORDER_WIDTH_DP));
        paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        iconStroke.setStyle(Paint.Style.STROKE);
        iconStroke.setStrokeCap(Paint.Cap.ROUND);
        iconStroke.setStrokeJoin(Paint.Join.ROUND);
        setContentDescription("RetroTouch game controls");
        // build the D-pad's chevron paths now so that onDraw never allocates them
        RetroTouchIcon.CHEVRON_UP.path();
        RetroTouchIcon.CHEVRON_DOWN.path();
        RetroTouchIcon.CHEVRON_LEFT.path();
        RetroTouchIcon.CHEVRON_RIGHT.path();
    }

    public void registerAction(String id, String label) {
        registerAction(id, label, null);
    }

    /**
     * Registers an action whose buttons use these colors unless a button was created with its own.
     * Pass null to keep the view-wide default colors.
     */
    public void registerAction(String id, String label, RetroTouchColors colors) {
        registerAction(id, label, colors, null);
    }

    /**
     * Registers an action with an icon (1.0.0-beta.10) that its buttons show in the ICONS style.
     * Null keeps the text label in both styles. The icon follows the action, so a button remapped
     * with ACTION in the editor shows the new action's icon.
     */
    public void registerAction(String id, String label, RetroTouchColors colors, RetroTouchIcon icon) {
        RetroTouchAction action = new RetroTouchAction(id, label, colors, icon);
        if (icon != null) icon.path();
        actions.put(action.getId(), action);
        stickActions.remove(action.getId());
        refreshControlLabels();
        invalidate();
    }

    /**
     * Changes the icon of a registered action at runtime (1.0.0-beta.10), for example for alternate
     * controls. Label, colors and stick setting stay; null removes the icon.
     */
    public void setActionIcon(String actionId, RetroTouchIcon icon) {
        RetroTouchAction old = actionId == null ? null : actions.get(actionId);
        if (old == null) throw new IllegalArgumentException("Unknown action: " + actionId);
        if (icon != null) icon.path();
        actions.put(actionId, new RetroTouchAction(actionId, old.getLabel(), old.getColors(), icon));
        invalidate();
    }

    /**
     * Registers a stick action (1.0.0-beta.7): in the editor a button whose action is cycled to it
     * becomes an analog stick with this label and these colors, and reports through
     * RetroTouchStickListener.onStick (the listener implements it as well as RetroTouchListener).
     * Cycling on turns it back into a button. The move stick stays as it is.
     */
    public void registerStickAction(String id, String label, RetroTouchColors colors) {
        registerStickAction(id, label, colors, null);
    }

    /**
     * Registers a stick action with an icon (1.0.0-beta.12) that its stick shows on the knob in the
     * ICONS style. Without an icon the ICONS style shows the label on the knob.
     */
    public void registerStickAction(String id, String label, RetroTouchColors colors, RetroTouchIcon icon) {
        RetroTouchAction action = new RetroTouchAction(id, label, colors, icon);
        if (icon != null) icon.path();
        actions.put(action.getId(), action);
        stickActions.add(action.getId());
        refreshControlLabels();
        invalidate();
    }

    /** Whether the action was registered as a stick action. */
    public boolean isStickAction(String id) {
        return id != null && stickActions.contains(id);
    }

    /**
     * How many sticks, the move stick included, the editor lets a layout hold when the player turns
     * buttons into sticks with ACTION (1.0.0-beta.12). Default 2, at most RetroTouchLayout.MAX_STICKS.
     * Sticks already in a layout stay when the limit is lowered.
     */
    public void setMaxSticks(int count) {
        maxSticks = Math.max(1, Math.min(RetroTouchLayout.MAX_STICKS, count));
        refreshControlLabels();
        invalidate();
    }

    public int getMaxSticks() { return maxSticks; }

    public void registerActions(List<RetroTouchAction> actionList) {
        actions.clear();
        stickActions.clear();
        if (actionList != null) {
            for (RetroTouchAction action : actionList) {
                if (action == null) throw new IllegalArgumentException("Action must not be null");
                actions.put(action.getId(), action);
            }
        }
        refreshControlLabels();
        invalidate();
    }

    public List<RetroTouchAction> getRegisteredActions() {
        return Collections.unmodifiableList(new ArrayList<RetroTouchAction>(actions.values()));
    }

    /** Backwards-compatible alias for setGameplayLayout(). */
    public void setDefaultLayout(RetroTouchLayout layout) {
        setGameplayLayout(layout);
    }

    public void setGameplayLayout(RetroTouchLayout layout) {
        if (layout == null) throw new IllegalArgumentException("Default layout must not be null");
        gameplayLayout = layout;
        refreshStyleKey();
        if (mode == RetroTouchMode.GAMEPLAY) activateLayout(layout);
    }

    /** Registers the optional menu/navigation layout. Games may omit it entirely. */
    public void setNavigationLayout(RetroTouchLayout layout) {
        if (layout == null) throw new IllegalArgumentException("Navigation layout must not be null");
        navigationLayout = layout;
        refreshStyleKey();
        if (mode == RetroTouchMode.NAVIGATION) activateLayout(layout);
    }

    public void setMode(RetroTouchMode value) {
        if (value == null) throw new IllegalArgumentException("Mode must not be null");
        if (mode == value) return;
        if (editing) setEditing(false);
        releaseAll();
        // Controller suppression belongs to the old surface and must never delay a newly
        // activated layout (for example when leaving a controller-driven menu for gameplay).
        controllerHiddenUntil = 0L;
        mode = value;
        activateLayout(layoutForMode(value));
    }

    public RetroTouchMode getMode() { return mode; }

    public RetroTouchLayout getCurrentLayout() {
        ensureLayout();
        return new RetroTouchLayout(defaultLayout.getGameId(), controls);
    }

    public void setListener(RetroTouchListener listener) {
        this.listener = listener == null ? new RetroTouchAdapter() : listener;
    }

    /** Keeps every button mapped to this action visually selected until cleared. */
    public void setActionLatched(String actionId, boolean latched) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (latched) latchedActions.add(actionId);
        else latchedActions.remove(actionId);
        invalidate();
    }

    public boolean isActionLatched(String actionId) {
        return actionId != null && latchedActions.contains(actionId);
    }

    /**
     * Re-synchronizes RetroTouch after the host engine has discarded its own input state.
     * All active pointers are forgotten, held actions are released, movement is forced to neutral
     * and RetroTouch-owned visual latches are cleared. The current mode and layouts are preserved.
     * Host-owned toggle variables must be cleared by the game at the same reset point.
     */
    public void resetInputState() {
        Set<String> releasedActions = releaseAll(true);
        for (String actionId : latchedActions) {
            if (!releasedActions.contains(actionId)) listener.onAction(actionId, false);
        }
        latchedActions.clear();
        invalidate();
    }

    /** Descriptive alias for {@link #resetInputState()}. */
    public void releaseAllInputs() {
        resetInputState();
    }

    public void setOverlayEnabled(boolean enabled) {
        if (overlayEnabled == enabled) return;
        releaseAll();
        overlayEnabled = enabled;
        if (!enabled && editing) setEditing(false);
        invalidate();
    }

    public boolean isOverlayEnabled() { return overlayEnabled; }

    public void setEditing(boolean value) {
        if (!overlayEnabled || mode == RetroTouchMode.OFF || defaultLayout == null) value = false;
        if (editing == value) return;
        if (editing && !value && defaultLayout != null) saveLayout();
        releaseAll();
        editing = value;
        selectedControlId = null;
        listener.onEditorStateChanged(editing);
        invalidate();
    }

    public boolean isEditing() { return editing; }

    public void setEditButtonVisible(boolean visible) {
        editButtonVisible = visible;
        invalidate();
    }

    public void setAutoHideOnController(boolean enabled) {
        autoHideOnController = enabled;
        if (!enabled) controllerHiddenUntil = 0L;
        invalidate();
    }

    /** Temporarily hides controls after physical controller activity. */
    public void notifyControllerInput() {
        if (!autoHideOnController || editing) return;
        releaseAll();
        controllerHiddenUntil = SystemClock.uptimeMillis() + DEFAULT_CONTROLLER_HIDE_MS;
        invalidate();
        postInvalidateDelayed(DEFAULT_CONTROLLER_HIDE_MS + 20L);
    }

    public void setLookSensitivity(float sensitivity) {
        lookSensitivity = Math.max(0.1f, Math.min(4.0f, sensitivity));
    }

    /**
     * Lets a held button continue to emit relative look motion when its center is placed inside
     * a look zone. The action remains pressed until the finger is released.
     */
    public void setLookWhileHoldingAction(String actionId, boolean enabled) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (enabled) lookWhileHoldingActions.add(actionId);
        else lookWhileHoldingActions.remove(actionId);
    }

    /**
     * Sets the shape of every button mapped to this action (1.0.0-beta.8). AUTO or null restores the
     * automatic choice from the label.
     */
    public void setButtonShape(String actionId, RetroTouchButtonShape shape) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (shape == null || shape == RetroTouchButtonShape.AUTO) buttonShapes.remove(actionId);
        else buttonShapes.put(actionId, shape);
        invalidate();
    }

    public RetroTouchButtonShape getButtonShape(String actionId) {
        RetroTouchButtonShape shape = actionId == null ? null : buttonShapes.get(actionId);
        return shape == null ? RetroTouchButtonShape.AUTO : shape;
    }

    /**
     * Keeps the editor bar, its DRAG line and the settings button's default position inside the view
     * minus these insets in pixels (1.0.0-beta.11), for example to stay clear of a camera cutout.
     * Controls, sticks and their saved positions are not affected and keep the whole view. May be
     * called again at any time, for example after a rotation; negative values count as 0. Insets that
     * would leave less than half of the view's width or height are ignored on that axis. Default 0.
     */
    public void setSafeInsets(int left, int top, int right, int bottom) {
        left = Math.max(0, left);
        top = Math.max(0, top);
        right = Math.max(0, right);
        bottom = Math.max(0, bottom);
        if (left == safeInsetLeft && top == safeInsetTop && right == safeInsetRight && bottom == safeInsetBottom) return;
        safeInsetLeft = left;
        safeInsetTop = top;
        safeInsetRight = right;
        safeInsetBottom = bottom;
        requestLayout();
        invalidate();
    }

    /**
     * Sets the aspect ratio (width / height) of every ROUNDED_RECT or CAPSULE button mapped to this
     * action (1.0.0-beta.10), including buttons added with ADD or remapped with ACTION. A control in
     * the default layout with its own aspect and the same action keeps that one. 0 or less removes
     * the action's aspect (back to 1:1). Like shapes, it is not stored in saved layouts.
     */
    public void setButtonAspect(String actionId, float aspect) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (aspect > 0.0f && !Float.isInfinite(aspect)) buttonAspects.put(actionId, clamp(aspect, 0.25f, 6.0f));
        else buttonAspects.remove(actionId);
        invalidate();
    }

    /** The aspect ratio set for this action with setButtonAspect, or 1 when none is set. */
    public float getButtonAspect(String actionId) {
        Float aspect = actionId == null ? null : buttonAspects.get(actionId);
        return aspect == null ? 1.0f : aspect;
    }

    /**
     * The button styles the game offers (1.0.0-beta.10); the default is LABELS only. With two or more
     * styles the editor shows a toggle that lets the player switch between them.
     */
    public void setAvailableButtonStyles(RetroTouchButtonStyle... styles) {
        availableStyles.clear();
        if (styles != null) {
            for (RetroTouchButtonStyle style : styles) {
                if (style != null && !availableStyles.contains(style)) availableStyles.add(style);
            }
        }
        if (availableStyles.isEmpty()) availableStyles.add(RetroTouchButtonStyle.LABELS);
        invalidate();
    }

    public List<RetroTouchButtonStyle> getAvailableButtonStyles() {
        return Collections.unmodifiableList(new ArrayList<RetroTouchButtonStyle>(availableStyles));
    }

    /**
     * The style used while the player has not chosen one (1.0.0-beta.10); LABELS unless set. It should
     * be one of the available styles; otherwise the first available style is used.
     */
    public void setDefaultButtonStyle(RetroTouchButtonStyle style) {
        defaultButtonStyle = style == null ? RetroTouchButtonStyle.LABELS : style;
        invalidate();
    }

    public RetroTouchButtonStyle getDefaultButtonStyle() { return defaultButtonStyle; }

    /**
     * The active button style: the saved choice if it is still available, otherwise the default
     * style, otherwise the first available style.
     */
    public RetroTouchButtonStyle getButtonStyle() {
        RetroTouchSkin skin = activeSkin();
        if (skin != null) return skin.getBaseStyle();
        if (chosenStyle != null && availableStyles.contains(chosenStyle)) return chosenStyle;
        if (availableStyles.contains(defaultButtonStyle)) return defaultButtonStyle;
        return availableStyles.get(0);
    }

    /**
     * Chooses the button style and saves the choice privately per game, separate from the layouts
     * (1.0.0-beta.10). A choice that is not available is kept but not used until it is.
     */
    public void setButtonStyle(RetroTouchButtonStyle style) {
        if (style == null) throw new IllegalArgumentException("Style must not be null");
        chosenStyle = style;
        if (styleKey != null) preferences().edit().putString(styleKey, style.name()).apply();
        invalidate();
    }

    /** Names the editor's style toggle shows, translated by the game; null keeps "Labels" / "Icons". */
    public void setStyleToggleLabels(String labelsName, String iconsName) {
        labelsToggleName = labelsName == null || labelsName.trim().length() == 0 ? "Labels" : labelsName.trim();
        iconsToggleName = iconsName == null || iconsName.trim().length() == 0 ? "Icons" : iconsName.trim();
        invalidate();
    }

    /**
     * Receives a callback when the player switches the style in the editor (1.0.0-beta.10). Without
     * one, the main listener gets it if it implements RetroTouchStyleListener.
     */
    public void setStyleListener(RetroTouchStyleListener listener) {
        styleListener = listener;
    }

    /**
     * Registers a skin (1.0.0-beta.13), a named look such as "RE", "GC", "PS2" or "XBOX". The view
     * keeps a copy; registering a skin with the same ID again replaces it in place. Skins are cycled
     * in registration order. With two or more skins the editor's style button switches between
     * them instead of between LABELS and ICONS; with skins, getButtonStyle is the active skin's base.
     */
    public void registerSkin(RetroTouchSkin skin) {
        if (skin == null) throw new IllegalArgumentException("Skin must not be null");
        RetroTouchSkin copy = skin.copy();
        for (int i = 0; i < skins.size(); ++i) {
            if (skins.get(i).getId().equals(copy.getId())) {
                skins.set(i, copy);
                invalidate();
                return;
            }
        }
        skins.add(copy);
        invalidate();
    }

    /** Removes every skin; the overlay draws in the LABELS or ICONS style again. */
    public void clearSkins() {
        skins.clear();
        invalidate();
    }

    /** The IDs of the registered skins in cycling order. */
    public List<String> getSkins() {
        List<String> ids = new ArrayList<String>(skins.size());
        for (RetroTouchSkin skin : skins) ids.add(skin.getId());
        return Collections.unmodifiableList(ids);
    }

    /** The skin used while the player has not chosen one; without it the first registered skin. */
    public void setDefaultSkin(String skinId) {
        defaultSkinId = skinId;
        invalidate();
    }

    public String getDefaultSkin() { return defaultSkinId; }

    /**
     * Chooses the skin and saves the choice privately per game, separate from the layouts. A skin
     * that is not registered is kept but not used until it is.
     */
    public void setSkin(String skinId) {
        if (skinId == null) throw new IllegalArgumentException("Skin id must not be null");
        chosenSkinId = skinId;
        if (skinKey != null) preferences().edit().putString(skinKey, skinId).apply();
        invalidate();
    }

    /**
     * The active skin's ID: the saved choice if it is registered, otherwise the default skin,
     * otherwise the first registered skin; null without skins.
     */
    public String getSkin() {
        RetroTouchSkin skin = activeSkin();
        return skin == null ? null : skin.getId();
    }

    /**
     * Receives a callback when the player switches the skin in the editor (1.0.0-beta.13). Without
     * one, the main listener gets it if it implements RetroTouchSkinListener.
     */
    public void setSkinListener(RetroTouchSkinListener listener) {
        skinListener = listener;
    }

    public void setAccentColor(int color) {
        accentColor = color;
        invalidate();
    }

    /**
     * Sets the colors of every button, D-pad and move stick that has neither its own colors nor
     * colors from its action. Pass null to restore the built-in grey look.
     */
    public void setDefaultColors(RetroTouchColors colors) {
        defaultColors = colors;
        invalidate();
    }

    public RetroTouchColors getDefaultColors() { return defaultColors; }

    public void saveLayout() {
        ensureLayout();
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(preferenceKey(), new RetroTouchLayout(defaultLayout.getGameId(), controls).toJson())
                .putString(editorPreferenceKey(), editorStateToJson())
                .apply();
    }

    public void resetToDefault() {
        ensureLayout();
        releaseAll();
        controls.clear();
        controls.addAll(defaultLayout.mutableCopy());
        resetEditorState();
        refreshControlLabels();
        selectedControlId = null;
        saveLayout();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!overlayEnabled || mode == RetroTouchMode.OFF || defaultLayout == null) return;
        boolean suppressed = controlsSuppressed();
        if (!suppressed || editing) {
            drawControls(canvas);
        }
        if (editing) drawToolbar(canvas);
        // Keep the permanent editor entry point visible even if the movable toolbar overlaps it.
        if (!suppressed && editButtonVisible) drawGear(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!overlayEnabled || mode == RetroTouchMode.OFF || defaultLayout == null) return false;
        int action = event.getActionMasked();
        if (controlsSuppressed() && !editing) {
            if (action != MotionEvent.ACTION_DOWN) return false;
            // A real screen touch always wins over the temporary controller
            // suppression and must be usable immediately, not after its timer.
            controllerHiddenUntil = 0L;
            invalidate();
        }
        int index = event.getActionIndex();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            boolean began = beginPointer(event.getPointerId(index), event.getX(index), event.getY(index));
            return began || pointers.size() > 0;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            boolean handled = false;
            for (int i = 0; i < event.getPointerCount(); ++i) {
                handled |= movePointer(event.getPointerId(i), event.getX(i), event.getY(i));
            }
            return handled || pointers.size() > 0;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
            endPointer(event.getPointerId(index), event.getX(index), event.getY(index));
            if (action == MotionEvent.ACTION_UP) performClick();
            return true;
        }
        if (action == MotionEvent.ACTION_CANCEL) {
            releaseAll();
            return true;
        }
        return pointers.size() > 0;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        releaseAll();
        super.onDetachedFromWindow();
    }

    private void loadLayout() {
        releaseAll();
        controls.clear();
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String saved = prefs.getString(preferenceKey(), null);
        if (saved != null) {
            try {
                RetroTouchLayout parsed = RetroTouchLayout.fromJson(saved);
                if (parsed.getGameId().equals(defaultLayout.getGameId())) controls.addAll(parsed.mutableCopy());
            } catch (JSONException | IllegalArgumentException invalid) {
                Log.w(TAG, "Ignoring invalid saved layout", invalid);
            }
        }
        if (controls.isEmpty()) controls.addAll(defaultLayout.mutableCopy());
        loadEditorState(prefs);
        refreshControlLabels();
        refreshControlColors();
        invalidate();
    }

    private RetroTouchLayout layoutForMode(RetroTouchMode value) {
        if (value == RetroTouchMode.GAMEPLAY) return gameplayLayout;
        if (value == RetroTouchMode.NAVIGATION) return navigationLayout;
        return null;
    }

    private void activateLayout(RetroTouchLayout layout) {
        defaultLayout = layout;
        if (layout == null) {
            releaseAll();
            controls.clear();
            selectedControlId = null;
            invalidate();
        } else {
            loadLayout();
        }
    }

    private String preferenceKey() {
        return "layout_" + (defaultLayout == null ? "unset" : defaultLayout.getGameId());
    }

    private String editorPreferenceKey() { return preferenceKey() + "_editor"; }

    private SharedPreferences preferences() {
        return getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /** The style choice is saved per game, keyed by the gameplay layout's ID (else the navigation layout's). */
    private void refreshStyleKey() {
        RetroTouchLayout game = gameplayLayout != null ? gameplayLayout : navigationLayout;
        String key = game == null ? null : "button_style_" + game.getGameId();
        refreshSkinKey(game);
        if (key == null || key.equals(styleKey)) return;
        styleKey = key;
        RetroTouchButtonStyle saved = null;
        try {
            String name = preferences().getString(key, null);
            if (name != null) saved = RetroTouchButtonStyle.valueOf(name);
        } catch (IllegalArgumentException unknown) {
            Log.w(TAG, "Ignoring unknown saved button style", unknown);
        }
        if (saved != null) chosenStyle = saved;
        else if (chosenStyle != null) preferences().edit().putString(key, chosenStyle.name()).apply();
        invalidate();
    }

    private void refreshSkinKey(RetroTouchLayout game) {
        String key = game == null ? null : "button_skin_" + game.getGameId();
        if (key == null || key.equals(skinKey)) return;
        skinKey = key;
        String saved = preferences().getString(key, null);
        if (saved != null) chosenSkinId = saved;
        else if (chosenSkinId != null) preferences().edit().putString(key, chosenSkinId).apply();
        invalidate();
    }

    /** The skin in use: the chosen one if registered, else the default one, else the first; null without skins. */
    private RetroTouchSkin activeSkin() {
        if (skins.isEmpty()) return null;
        RetroTouchSkin fallback = null;
        for (RetroTouchSkin skin : skins) {
            if (skin.getId().equals(chosenSkinId)) return skin;
            if (fallback == null && skin.getId().equals(defaultSkinId)) fallback = skin;
        }
        return fallback != null ? fallback : skins.get(0);
    }

    private void cycleSkin() {
        RetroTouchSkin current = activeSkin();
        RetroTouchSkin next = skins.get((skins.indexOf(current) + 1) % skins.size());
        setSkin(next.getId());
        if (skinListener != null) skinListener.onSkinChanged(next.getId());
        else if (listener instanceof RetroTouchSkinListener) ((RetroTouchSkinListener) listener).onSkinChanged(next.getId());
    }

    /** The editor's style button: skins when two or more are registered, else LABELS / ICONS. */
    private boolean styleToggleShown() {
        return skins.isEmpty() ? availableStyles.size() > 1 : skins.size() > 1;
    }

    private void toggleButtonStyle() {
        RetroTouchButtonStyle current = getButtonStyle();
        RetroTouchButtonStyle next = availableStyles.get((availableStyles.indexOf(current) + 1) % availableStyles.size());
        setButtonStyle(next);
        if (styleListener != null) styleListener.onButtonStyleChanged(next);
        else if (listener instanceof RetroTouchStyleListener) ((RetroTouchStyleListener) listener).onButtonStyleChanged(next);
    }

    private void resetEditorState() {
        settingsX = Float.NaN;
        settingsY = Float.NaN;
        settingsScale = DEFAULT_SETTINGS_SIZE_SCALE;
        settingsOpacity = DEFAULT_SETTINGS_OPACITY;
        toolbarCenterY = Float.NaN;
    }

    private void loadEditorState(SharedPreferences prefs) {
        resetEditorState();
        String saved = prefs.getString(editorPreferenceKey(), null);
        if (saved == null) return;
        try {
            JSONObject json = new JSONObject(saved);
            settingsX = clamp01((float) json.optDouble("settings_x", Float.NaN));
            settingsY = clamp01((float) json.optDouble("settings_y", Float.NaN));
            settingsScale = clamp((float) json.optDouble("settings_scale", DEFAULT_SETTINGS_SIZE_SCALE),
                    0.40f, 1.40f);
            settingsOpacity = clamp((float) json.optDouble("settings_opacity", DEFAULT_SETTINGS_OPACITY),
                    0.07f, 0.90f);
            toolbarCenterY = clamp01((float) json.optDouble("toolbar_y", Float.NaN));
        } catch (JSONException invalid) {
            Log.w(TAG, "Ignoring invalid saved editor layout", invalid);
            resetEditorState();
        }
    }

    private String editorStateToJson() {
        JSONObject json = new JSONObject();
        try {
            RectF gear = gearRect();
            json.put("format", 1);
            json.put("settings_x", getWidth() > 0 ? gear.centerX() / getWidth() : 1.0f);
            json.put("settings_y", getHeight() > 0 ? gear.centerY() / getHeight() : 0.0f);
            json.put("settings_scale", settingsScale);
            json.put("settings_opacity", settingsOpacity);
            json.put("toolbar_y", getHeight() > 0 ?
                    (toolbarTop() + toolbarHeight() * 0.5f) / getHeight() : 1.0f);
        } catch (JSONException impossible) {
            throw new IllegalStateException(impossible);
        }
        return json.toString();
    }

    private void ensureLayout() {
        if (defaultLayout == null) throw new IllegalStateException("Call setDefaultLayout() first");
    }

    private boolean controlsSuppressed() {
        return autoHideOnController && SystemClock.uptimeMillis() < controllerHiddenUntil;
    }

    private boolean beginPointer(int pointerId, float x, float y) {
        if (editing) {
            if (isInsideGear(x, y)) {
                selectedControlId = POINTER_GEAR;
                PointerState state = new PointerState(POINTER_GEAR, x, y);
                RectF gear = gearRect();
                state.dragOffsetX = gear.centerX() - x;
                state.dragOffsetY = gear.centerY() - y;
                pointers.put(pointerId, state);
                invalidate();
                return true;
            }
            if (isInsideToolbarHandle(x, y)) {
                PointerState state = new PointerState(POINTER_TOOLBAR_DRAG, x, y);
                state.dragOffsetY = toolbarTop() - y;
                pointers.put(pointerId, state);
                return true;
            }
            int tool = toolbarIndex(x, y);
            if (tool >= 0) {
                pointers.put(pointerId, new PointerState("__tool_" + tool, x, y));
                return true;
            }
            if (isInsideToolbar(x, y)) {
                pointers.put(pointerId, new PointerState(POINTER_TOOLBAR, x, y));
                return true;
            }
            RetroTouchControl hit = hitControl(x, y, true);
            if (hit != null) {
                selectedControlId = hit.getId();
                pointers.put(pointerId, new PointerState(hit.getId(), x, y));
                invalidate();
                return true;
            }
            selectedControlId = null;
            invalidate();
            return true;
        }

        if (editButtonVisible && isInsideGear(x, y)) {
            pointers.put(pointerId, new PointerState(POINTER_GEAR, x, y));
            return true;
        }
        RetroTouchControl hit = hitControl(x, y, false);
        if (hit == null) return false;
        PointerState state = new PointerState(hit.getId(), x, y);
        pointers.put(pointerId, state);
        if (hit.getType() == RetroTouchControl.Type.BUTTON && isKnownAction(hit.getActionId()) &&
                !stickActions.contains(hit.getActionId())) {
            state.actionPressed = true;
            listener.onAction(hit.getActionId(), true);
        } else if (hit.getType() == RetroTouchControl.Type.MOVE_STICK) {
            if (listener instanceof RetroTouchStickTouchListener)
                ((RetroTouchStickTouchListener) listener).onStickDown(hit.getActionId());
            updateStick(hit, x, y);
        } else if (hit.getType() == RetroTouchControl.Type.D_PAD) {
            updateDpad(hit, state, x, y);
        }
        invalidate();
        return true;
    }

    /** A stick's position to the host: the move stick through onMove, a stick action through onStick. */
    private void reportStick(RetroTouchControl control, float x, float y) {
        String action = control.getActionId();
        if (action.length() == 0) {
            listener.onMove(x, y);
        } else if (stickActions.contains(action) && listener instanceof RetroTouchStickListener) {
            ((RetroTouchStickListener) listener).onStick(action, x, y);
        }
    }

    private boolean movePointer(int pointerId, float x, float y) {
        PointerState state = pointers.get(pointerId);
        if (state == null) return false;
        if (editing && POINTER_GEAR.equals(state.controlId)) {
            moveSettingsButton(x + state.dragOffsetX, y + state.dragOffsetY);
            state.lastX = x;
            state.lastY = y;
            invalidate();
            return true;
        }
        if (editing && POINTER_TOOLBAR_DRAG.equals(state.controlId)) {
            float top = clamp(y + state.dragOffsetY, safeTop(),
                    Math.max(safeTop(), safeBottom() - toolbarHeight()));
            toolbarCenterY = getHeight() > 0 ?
                    (top + toolbarHeight() * 0.5f) / getHeight() : Float.NaN;
            state.lastX = x;
            state.lastY = y;
            invalidate();
            return true;
        }
        RetroTouchControl control = findControl(state.controlId);
        if (editing && control != null) {
            float nx = getWidth() > 0 ? x / getWidth() : control.getX();
            float ny = getHeight() > 0 ? y / getHeight() : control.getY();
            placeControl(control, nx, ny);
            state.lastX = x;
            state.lastY = y;
            invalidate();
            return true;
        }
        if (control == null) return true;
        if (control.getType() == RetroTouchControl.Type.MOVE_STICK) {
            updateStick(control, x, y);
        } else if (control.getType() == RetroTouchControl.Type.LOOK_ZONE) {
            updateLook(state, x, y);
        } else if (control.getType() == RetroTouchControl.Type.BUTTON && state.actionPressed &&
                lookWhileHoldingActions.contains(control.getActionId()) &&
                isControlCenterInsideLookZone(control)) {
            updateLook(state, x, y);
        } else if (control.getType() == RetroTouchControl.Type.D_PAD) {
            updateDpad(control, state, x, y);
        }
        state.lastX = x;
        state.lastY = y;
        invalidate();
        return true;
    }

    private void endPointer(int pointerId, float x, float y) {
        PointerState state = pointers.get(pointerId);
        if (state == null) return;
        pointers.remove(pointerId);
        if (POINTER_GEAR.equals(state.controlId)) {
            if (!editing && isInsideGear(x, y)) setEditing(true);
            return;
        }
        if (POINTER_TOOLBAR_DRAG.equals(state.controlId) || POINTER_TOOLBAR.equals(state.controlId)) return;
        if (state.controlId.startsWith("__tool_")) {
            int tool = Integer.parseInt(state.controlId.substring(7));
            if (tool == toolbarIndex(x, y)) applyTool(tool);
            return;
        }
        RetroTouchControl control = findControl(state.controlId);
        if (control != null && control.getType() == RetroTouchControl.Type.BUTTON && state.actionPressed) {
            listener.onAction(control.getActionId(), false);
        } else if (control != null && control.getType() == RetroTouchControl.Type.MOVE_STICK) {
            reportStick(control, 0.0f, 0.0f);
            if (!editing && listener instanceof RetroTouchStickTouchListener)
                ((RetroTouchStickTouchListener) listener).onStickUp(control.getActionId());
        } else if (control != null && control.getType() == RetroTouchControl.Type.D_PAD && state.activeActionId != null) {
            listener.onAction(state.activeActionId, false);
        }
        invalidate();
    }

    private void releaseAll() {
        releaseAll(false);
    }

    private Set<String> releaseAll(boolean forceNeutralMove) {
        Set<String> releasedActions = new HashSet<String>();
        List<String> releasedSticks = new ArrayList<String>();
        for (int i = 0; i < pointers.size(); ++i) {
            PointerState state = pointers.valueAt(i);
            RetroTouchControl control = findControl(state.controlId);
            if (!editing && control != null && control.getType() == RetroTouchControl.Type.MOVE_STICK) {
                releasedSticks.add(control.getActionId());
            }
            if (control != null && control.getType() == RetroTouchControl.Type.BUTTON && state.actionPressed) {
                listener.onAction(control.getActionId(), false);
                releasedActions.add(control.getActionId());
            } else if (control != null && control.getType() == RetroTouchControl.Type.D_PAD && state.activeActionId != null) {
                listener.onAction(state.activeActionId, false);
                releasedActions.add(state.activeActionId);
            }
        }
        if (forceNeutralMove || pointers.size() > 0) {
            listener.onMove(0.0f, 0.0f);
            if (listener instanceof RetroTouchStickListener)
                for (String action : stickActions) ((RetroTouchStickListener) listener).onStick(action, 0.0f, 0.0f);
        }
        if (listener instanceof RetroTouchStickTouchListener)
            for (String action : releasedSticks) ((RetroTouchStickTouchListener) listener).onStickUp(action);
        pointers.clear();
        invalidate();
        return releasedActions;
    }

    private void updateStick(RetroTouchControl control, float x, float y) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.max(1.0f, Math.min(control.getWidth() * getWidth(),
                control.getHeight() * getHeight()) * 0.5f);
        float dx = (x - cx) / radius;
        float dy = (y - cy) / radius;
        float length = (float) Math.sqrt(dx * dx + dy * dy);
        if (length > 1.0f) { dx /= length; dy /= length; }
        if (Math.abs(dx) < 0.08f) dx = 0.0f;
        if (Math.abs(dy) < 0.08f) dy = 0.0f;
        reportStick(control, dx, dy);
    }

    private void updateLook(PointerState state, float x, float y) {
        float base = Math.max(1.0f, Math.min(getWidth(), getHeight()));
        listener.onLook((x - state.lastX) / base * lookSensitivity,
                (y - state.lastY) / base * lookSensitivity);
    }

    private boolean isControlCenterInsideLookZone(RetroTouchControl control) {
        for (RetroTouchControl candidate : controls) {
            if (candidate.getType() != RetroTouchControl.Type.LOOK_ZONE) continue;
            float halfW = candidate.getWidth() * 0.5f;
            float halfH = candidate.getHeight() * 0.5f;
            if (control.getX() >= candidate.getX() - halfW && control.getX() <= candidate.getX() + halfW &&
                    control.getY() >= candidate.getY() - halfH && control.getY() <= candidate.getY() + halfH)
                return true;
        }
        return false;
    }

    private void updateDpad(RetroTouchControl control, PointerState state, float x, float y) {
        String next = dpadActionAt(control, x, y);
        if (next == null ? state.activeActionId == null : next.equals(state.activeActionId)) return;
        if (state.activeActionId != null) listener.onAction(state.activeActionId, false);
        state.activeActionId = next;
        if (next != null) listener.onAction(next, true);
    }

    private String dpadActionAt(RetroTouchControl control, float x, float y) {
        float halfW = Math.max(1.0f, control.getWidth() * getWidth() * 0.5f);
        float halfH = Math.max(1.0f, control.getHeight() * getHeight() * 0.5f);
        float nx = (x - control.getX() * getWidth()) / halfW;
        float ny = (y - control.getY() * getHeight()) / halfH;
        if (Math.abs(nx) < 0.20f && Math.abs(ny) < 0.20f) return null;
        if (Math.abs(nx) > Math.abs(ny)) return nx < 0.0f ? RetroTouchNavigation.LEFT : RetroTouchNavigation.RIGHT;
        return ny < 0.0f ? RetroTouchNavigation.UP : RetroTouchNavigation.DOWN;
    }

    private RetroTouchControl hitControl(float x, float y, boolean includeLookFirst) {
        if (!includeLookFirst) {
            for (int i = controls.size() - 1; i >= 0; --i) {
                RetroTouchControl control = controls.get(i);
                if (control.getType() != RetroTouchControl.Type.LOOK_ZONE && contains(control, x, y)) return control;
            }
        }
        for (int i = controls.size() - 1; i >= 0; --i) {
            RetroTouchControl control = controls.get(i);
            if ((includeLookFirst || control.getType() == RetroTouchControl.Type.LOOK_ZONE) && contains(control, x, y)) return control;
        }
        return null;
    }

    private boolean contains(RetroTouchControl control, float x, float y) {
        float halfW = control.getWidth() * getWidth() * 0.5f;
        float halfH = control.getHeight() * getHeight() * 0.5f;
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        RetroTouchButtonShape shape = control.getType() == RetroTouchControl.Type.BUTTON ? effectiveShape(control) :
                RetroTouchButtonShape.ROUND;
        if (shape != RetroTouchButtonShape.ROUND) {
            // a rectangle button is touched on its rectangle plus a small margin
            buttonRect(control, shape, touchRect);
            float rotation = rotationFor(control);
            if (rotation != 0.0f) {
                // turn the touch back into the unturned shape's frame
                double angle = Math.toRadians(-rotation);
                float dx = x - touchRect.centerX();
                float dy = y - touchRect.centerY();
                x = touchRect.centerX() + (float) (dx * Math.cos(angle) - dy * Math.sin(angle));
                y = touchRect.centerY() + (float) (dx * Math.sin(angle) + dy * Math.cos(angle));
            }
            float margin = Math.min(touchRect.height(), touchRect.width()) * 0.15f;
            if (!isPathShape(shape) && rotation == 0.0f) margin = touchRect.height() * 0.15f;
            touchRect.inset(-margin, -margin);
            return touchRect.contains(x, y);
        }
        if (control.getType() == RetroTouchControl.Type.BUTTON || control.getType() == RetroTouchControl.Type.MOVE_STICK) {
            float nx = (x - cx) / Math.max(1.0f, halfW);
            float ny = (y - cy) / Math.max(1.0f, halfH);
            return nx * nx + ny * ny <= 1.15f;
        }
        return x >= cx - halfW && x <= cx + halfW && y >= cy - halfH && y <= cy + halfH;
    }

    private void drawControls(Canvas canvas) {
        if (editing) {
            for (RetroTouchControl control : controls) {
                if (control.getType() == RetroTouchControl.Type.LOOK_ZONE) drawLookZone(canvas, control);
            }
        }
        for (RetroTouchControl control : controls) {
            if (control.getType() == RetroTouchControl.Type.MOVE_STICK) drawStick(canvas, control);
            else if (control.getType() == RetroTouchControl.Type.BUTTON) drawButton(canvas, control);
            else if (control.getType() == RetroTouchControl.Type.D_PAD) drawDpad(canvas, control);
            if (editing && control.getId().equals(selectedControlId)) drawSelection(canvas, control);
        }
    }

    private void drawButton(Canvas canvas, RetroTouchControl control) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight()) * 0.5f;
        boolean pressed = isControlPressed(control.getId());
        boolean latched = latchedActions.contains(control.getActionId());
        float displayOpacity = latched ? opacityTwoStepsHigher(control.getOpacity()) : control.getOpacity();
        int alpha = Math.round(255.0f * displayOpacity);
        RetroTouchSkin skin = activeSkin();
        if (skin != null) {
            drawStyledButton(canvas, control, skin);
            return;
        }
        RetroTouchColors colors = colorsFor(control, BUTTON_COLORS);
        String label = normalizeLabel(control.getLabel());
        RetroTouchButtonShape shape = shapeFor(control, label);
        if (isPathShape(shape)) {
            drawStyledButton(canvas, control, null);
            return;
        }
        if (getButtonStyle() == RetroTouchButtonStyle.ICONS) {
            drawIconButton(canvas, control, shape, label, colors);
            return;
        }
        if (shape != RetroTouchButtonShape.ROUND) {
            drawRectangleButton(canvas, control, shape, label, pressed, alpha, colors);
            return;
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(pressed ? colors.getPressedColor() : colors.getFillColor(), alpha));
        canvas.drawCircle(cx, cy, radius, paint);
        stroke.setColor(withAlpha(colors.getBorderColor(), alpha));
        canvas.drawCircle(cx, cy, radius, stroke);
        paint.setColor(withAlpha(colors.getTextColor(), alpha));
        drawButtonText(canvas, label, true, cx, cy, radius * 2.0f, radius * 2.0f);
    }

    /** A RECTANGLE, SHOULDER, ROUNDED_RECT or CAPSULE button in the LABELS style. */
    private void drawRectangleButton(Canvas canvas, RetroTouchControl control, RetroTouchButtonShape shape,
                                     String label, boolean pressed, int alpha, RetroTouchColors colors) {
        buttonRect(control, shape, rect);
        float cx = rect.centerX();
        float cy = rect.centerY();
        float width = rect.width();
        float height = rect.height();
        float corner = height * cornerRatio(shape);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(pressed ? colors.getPressedColor() : colors.getFillColor(), alpha));
        canvas.drawRoundRect(rect, corner, corner, paint);
        stroke.setColor(withAlpha(colors.getBorderColor(), alpha));
        canvas.drawRoundRect(rect, corner, corner, stroke);
        paint.setColor(withAlpha(colors.getTextColor(), alpha));
        drawButtonText(canvas, label, false, cx, cy, width, height);
    }

    /** A button's text in the current paint color: one large glyph, or a fitted one- or two-line label. */
    private void drawButtonText(Canvas canvas, String label, boolean round, float cx, float cy,
                                float width, float height) {
        paint.setTextAlign(Paint.Align.CENTER);
        float radius = width * 0.5f;
        if (label.codePointCount(0, label.length()) == 1) {
            // Single characters such as A or B scale with the button without the 16 dp cap.
            paint.setTextSize(round ? radius * 0.68f : height * 0.62f);
            drawCenteredGlyph(canvas, label, cx, cy, paint);
            return;
        }
        if (round) {
            paint.setTextSize(Math.max(dp(8), Math.min(dp(16), radius * 0.34f)));
            drawButtonLabel(canvas, label, cx, cy, radius * 1.55f, radius * 1.40f, paint);
        } else {
            paint.setTextSize(Math.max(dp(8), Math.min(dp(16), height * 0.42f)));
            drawButtonLabel(canvas, label, cx, cy, width * 0.84f, height * 0.80f, paint);
        }
    }

    /** Corner radius as a fraction of the height. */
    private static float cornerRatio(RetroTouchButtonShape shape) {
        if (shape == RetroTouchButtonShape.CAPSULE) return 0.5f;
        if (shape == RetroTouchButtonShape.ROUNDED_RECT) return 0.35f;
        return 0.2f;
    }

    /**
     * A button in the ICONS style: shape filled, border inside the shape (so nothing grows past
     * the button), icon or, without one, the label; a latched button adds an outer ring.
     */
    private void drawIconButton(Canvas canvas, RetroTouchControl control, RetroTouchButtonShape shape,
                                String label, RetroTouchColors colors) {
        boolean held = pointerForControl(control.getId()) != null;
        boolean latched = latchedActions.contains(control.getActionId());
        int alpha = Math.round(255.0f * control.getOpacity());
        buttonRect(control, shape, rect);
        float cx = rect.centerX();
        float cy = rect.centerY();
        float width = rect.width();
        float height = rect.height();
        float smaller = Math.min(width, height);
        float corner = shape == RetroTouchButtonShape.ROUND ? smaller * 0.5f : height * cornerRatio(shape);
        float border = iconBorderWidth(colors, smaller);
        int fill = held ? colors.getPressedColor() : (latched ? colors.getLatchedFillColor() : colors.getFillColor());
        int line = held ? colors.getPressedBorderColor() : (latched ? colors.getLatchedBorderColor() : colors.getBorderColor());
        int ink = held ? colors.getPressedTextColor() : (latched ? colors.getLatchedTextColor() : colors.getTextColor());
        if (latched) {
            // outer ring: 20 % of the radius (at least 4 dp) away, half the border wide, 45 % opacity
            float gap = Math.max(smaller * 0.5f * 0.2f, dp(4));
            iconRect.set(rect);
            iconRect.inset(-gap, -gap);
            iconStroke.setStrokeWidth(border * 0.5f);
            iconStroke.setColor(withAlpha(colors.getLatchedBorderColor(), Math.round(alpha * 0.45f)));
            canvas.drawRoundRect(iconRect, corner + gap, corner + gap, iconStroke);
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(fill, alpha));
        canvas.drawRoundRect(rect, corner, corner, paint);
        if (border > 0.0f) {
            iconRect.set(rect);
            iconRect.inset(border * 0.5f, border * 0.5f);
            iconStroke.setStrokeWidth(border);
            iconStroke.setColor(withAlpha(line, alpha));
            float inner = Math.max(0.0f, corner - border * 0.5f);
            canvas.drawRoundRect(iconRect, inner, inner, iconStroke);
        }
        RetroTouchAction action = actions.get(control.getActionId());
        RetroTouchIcon icon = action == null ? null : action.getIcon();
        if (icon == null) {
            paint.setColor(withAlpha(ink, alpha));
            drawButtonText(canvas, label, shape == RetroTouchButtonShape.ROUND, cx, cy, width, height);
            return;
        }
        int iconInk = held ? colors.getPressedIconColor() : (latched ? colors.getLatchedIconColor() : colors.getIconColor());
        float box = shape == RetroTouchButtonShape.ROUND ? smaller * 0.55f : Math.min(height * 0.61f, width * 0.8f);
        drawIcon(canvas, icon, cx, cy, box * icon.getExtraScale(), iconInk, alpha);
    }

    // ---- skins and path shapes (1.0.0-beta.13) ----

    private static boolean isPathShape(RetroTouchButtonShape shape) {
        return shape == RetroTouchButtonShape.KIDNEY || shape == RetroTouchButtonShape.BUMPER ||
                shape == RetroTouchButtonShape.TRIGGER;
    }

    /** The active skin's look for this control's action (the move stick's look for the move stick), or null. */
    private RetroTouchLook lookFor(RetroTouchControl control) {
        RetroTouchSkin skin = activeSkin();
        if (skin == null) return null;
        if (control.getType() == RetroTouchControl.Type.MOVE_STICK && control.getActionId().length() == 0)
            return skin.getMoveStickLook();
        if (control.getType() != RetroTouchControl.Type.BUTTON && control.getType() != RetroTouchControl.Type.MOVE_STICK)
            return null;
        return skin.getLook(control.getActionId());
    }

    /** A button's shape: the skin look's if it sets one, else as without skins. */
    private RetroTouchButtonShape effectiveShape(RetroTouchControl control) {
        RetroTouchLook look = lookFor(control);
        if (look != null && look.getShape() != null) return look.getShape();
        return shapeFor(control);
    }

    private float rotationFor(RetroTouchControl control) {
        if (control.getType() != RetroTouchControl.Type.BUTTON) return 0.0f;
        RetroTouchLook look = lookFor(control);
        return look == null ? 0.0f : look.getRotation();
    }

    /** Colors in a skin: look, control, action, the skin's D-pad colors, the skin's default, view default, built-in. */
    private RetroTouchColors skinColorsFor(RetroTouchControl control, RetroTouchLook look, RetroTouchSkin skin,
                                           RetroTouchColors builtIn) {
        if (look != null && look.getColors() != null) return look.getColors();
        if (control.getColors() != null) return control.getColors();
        RetroTouchAction action = control.getType() == RetroTouchControl.Type.BUTTON ||
                control.getType() == RetroTouchControl.Type.MOVE_STICK ? actions.get(control.getActionId()) : null;
        if (action != null && action.getColors() != null) return action.getColors();
        if (skin != null && control.getType() == RetroTouchControl.Type.D_PAD && skin.getDpadColors() != null)
            return skin.getDpadColors();
        if (skin != null && skin.getDefaultColors() != null) return skin.getDefaultColors();
        return defaultColors != null ? defaultColors : builtIn;
    }

    /** Border width in a skin: the colors' fraction, else 7 % (ICONS base) or the LABELS style's 2.5 dp. */
    private float skinBorder(RetroTouchColors colors, float smallerSide, RetroTouchButtonStyle base) {
        float fraction = colors.getBorderWidth();
        if (!Float.isNaN(fraction)) return fraction * smallerSide;
        return base == RetroTouchButtonStyle.ICONS ? ICON_BORDER * smallerSide : dp(BORDER_WIDTH_DP);
    }

    /** Builds the outline of a shape filling {@code r} into {@code out}; allocation-free. */
    private void buildShapePath(RetroTouchButtonShape shape, RectF r, Path out) {
        out.reset();
        float w = r.width();
        float h = r.height();
        if (shape == RetroTouchButtonShape.ROUND) {
            out.addOval(r, Path.Direction.CW);
        } else if (shape == RetroTouchButtonShape.KIDNEY) {
            // a bean, hollow on top: two lobes, a dip in the middle, a full round bottom
            float cx = r.centerX();
            float cy = r.centerY();
            float hw = w * 0.5f;
            float hh = h * 0.5f;
            out.moveTo(cx - 0.60f * hw, cy - hh);
            out.cubicTo(cx - 0.30f * hw, cy - hh, cx - 0.22f * hw, cy - 0.35f * hh, cx, cy - 0.35f * hh);
            out.cubicTo(cx + 0.22f * hw, cy - 0.35f * hh, cx + 0.30f * hw, cy - hh, cx + 0.60f * hw, cy - hh);
            out.cubicTo(cx + 0.85f * hw, cy - hh, cx + hw, cy - 0.60f * hh, cx + hw, cy - 0.15f * hh);
            out.cubicTo(cx + hw, cy + 0.55f * hh, cx + 0.55f * hw, cy + hh, cx, cy + hh);
            out.cubicTo(cx - 0.55f * hw, cy + hh, cx - hw, cy + 0.55f * hh, cx - hw, cy - 0.15f * hh);
            out.cubicTo(cx - hw, cy - 0.60f * hh, cx - 0.85f * hw, cy - hh, cx - 0.60f * hw, cy - hh);
            out.close();
        } else if (shape == RetroTouchButtonShape.BUMPER) {
            float topX = Math.min(w * 0.5f, h * 0.9f);
            float topY = h * 0.6f;
            float bottom = h * 0.18f;
            setRadii(topX, topY, bottom);
            out.addRoundRect(r, shapeRadii, Path.Direction.CW);
        } else if (shape == RetroTouchButtonShape.TRIGGER) {
            float topX = w * 0.5f;
            float topY = Math.min(h * 0.45f, w * 0.6f);
            float bottom = Math.min(w, h) * 0.15f;
            setRadii(topX, topY, bottom);
            out.addRoundRect(r, shapeRadii, Path.Direction.CW);
        } else {
            float corner = h * cornerRatio(shape);
            out.addRoundRect(r, corner, corner, Path.Direction.CW);
        }
    }

    private void setRadii(float topX, float topY, float bottom) {
        shapeRadii[0] = topX;
        shapeRadii[1] = topY;
        shapeRadii[2] = topX;
        shapeRadii[3] = topY;
        shapeRadii[4] = bottom;
        shapeRadii[5] = bottom;
        shapeRadii[6] = bottom;
        shapeRadii[7] = bottom;
    }

    /**
     * A button in a skin, or in a KIDNEY, BUMPER or TRIGGER shape without one: the turned shape
     * filled with its border inside, a latched ring, and an upright icon or label centered on its ink.
     */
    private void drawStyledButton(Canvas canvas, RetroTouchControl control, RetroTouchSkin skin) {
        RetroTouchButtonStyle base = skin != null ? skin.getBaseStyle() : getButtonStyle();
        RetroTouchLook look = lookFor(control);
        RetroTouchButtonShape shape = effectiveShape(control);
        RetroTouchColors colors = skinColorsFor(control, look, skin, BUTTON_COLORS);
        boolean held = pointerForControl(control.getId()) != null;
        boolean latched = latchedActions.contains(control.getActionId());
        int alpha = Math.round(255.0f * control.getOpacity());
        buttonRect(control, shape, rect);
        float cx = rect.centerX();
        float cy = rect.centerY();
        float width = rect.width();
        float height = rect.height();
        float smaller = Math.min(width, height);
        float border = skinBorder(colors, smaller, base);
        float rotation = rotationFor(control);
        int fill = held ? colors.getPressedColor() : (latched ? colors.getLatchedFillColor() : colors.getFillColor());
        int line = held ? colors.getPressedBorderColor() : (latched ? colors.getLatchedBorderColor() : colors.getBorderColor());
        int ink = held ? colors.getPressedTextColor() : (latched ? colors.getLatchedTextColor() : colors.getTextColor());
        int iconInk = held ? colors.getPressedIconColor() : (latched ? colors.getLatchedIconColor() : colors.getIconColor());

        canvas.save();
        if (rotation != 0.0f) canvas.rotate(rotation, cx, cy);
        if (latched) {
            float gap = Math.max(smaller * 0.5f * 0.2f, dp(4));
            iconRect.set(rect);
            iconRect.inset(-gap, -gap);
            buildShapePath(shape, iconRect, shapePath);
            iconStroke.setStrokeWidth(Math.max(1.0f, border * 0.5f));
            iconStroke.setColor(withAlpha(colors.getLatchedBorderColor(), Math.round(alpha * 0.45f)));
            canvas.drawPath(shapePath, iconStroke);
        }
        buildShapePath(shape, rect, shapePath);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(fill, alpha));
        canvas.drawPath(shapePath, paint);
        if (border > 0.0f) {
            iconRect.set(rect);
            iconRect.inset(border * 0.5f, border * 0.5f);
            buildShapePath(shape, iconRect, shapePath);
            iconStroke.setStrokeWidth(border);
            iconStroke.setColor(withAlpha(line, alpha));
            canvas.drawPath(shapePath, iconStroke);
        }
        canvas.restore();

        // the content's center: the shape's visual center, turned with the shape, plus the look's offset
        float localY = shape == RetroTouchButtonShape.KIDNEY ? height * 0.5f * 0.22f :
                (shape == RetroTouchButtonShape.TRIGGER ? height * 0.5f * 0.08f : 0.0f);
        float contentX = cx;
        float contentY = cy + localY;
        if (rotation != 0.0f && localY != 0.0f) {
            double angle = Math.toRadians(rotation);
            contentX = cx - (float) (localY * Math.sin(angle));
            contentY = cy + (float) (localY * Math.cos(angle));
        }
        if (look != null) {
            contentX += look.getOffsetX() * height;
            contentY += look.getOffsetY() * height;
        }
        RetroTouchAction action = actions.get(control.getActionId());
        RetroTouchIcon icon = null;
        String label = null;
        if (look != null && look.getIcon() != null) icon = look.getIcon();
        else if (look != null && look.getLabel() != null) label = normalizeLabel(look.getLabel());
        else if (base == RetroTouchButtonStyle.ICONS && action != null && action.getIcon() != null) icon = action.getIcon();
        else label = normalizeLabel(control.getLabel());
        boolean round = shape == RetroTouchButtonShape.ROUND;
        if (icon != null) {
            float box = round ? smaller * 0.55f : (shape == RetroTouchButtonShape.KIDNEY ? height * 0.5f :
                    Math.min(height * 0.61f, width * 0.8f));
            drawIconOptical(canvas, icon, contentX, contentY, box * icon.getExtraScale(), iconInk, alpha);
        } else if (label.length() > 0) {
            paint.setColor(withAlpha(ink, alpha));
            if (shape == RetroTouchButtonShape.KIDNEY) drawOpticalText(canvas, label, false, contentX, contentY, width * 0.72f, height * 0.62f);
            else drawOpticalText(canvas, label, round, contentX, contentY, width, height);
        }
    }

    /** A stick in a skin: round or octagonal gate, knob, and the look's or action's icon or label on the knob. */
    private void drawSkinStick(Canvas canvas, RetroTouchControl control, RetroTouchSkin skin) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight()) * 0.5f;
        int alpha = Math.round(255.0f * control.getOpacity());
        RetroTouchLook look = lookFor(control);
        RetroTouchColors colors = skinColorsFor(control, look, skin, STICK_COLORS);
        RetroTouchButtonStyle base = skin.getBaseStyle();
        boolean octagon = skin.getStickGate() == RetroTouchStickGate.OCTAGON;
        float knobRadius = radius * 0.42f;
        float border = skinBorder(colors, knobRadius * 2.0f, base);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(colors.getFillColor(), Math.round(alpha * 0.55f)));
        if (octagon) {
            buildOctagon(cx, cy, radius, shapePath);
            canvas.drawPath(shapePath, paint);
        } else {
            canvas.drawCircle(cx, cy, radius, paint);
        }
        iconStroke.setStrokeWidth(border);
        iconStroke.setColor(withAlpha(colors.getBorderColor(), alpha));
        if (octagon) {
            buildOctagon(cx, cy, Math.max(0.0f, radius - border * 0.5f / OCTAGON_APOTHEM), shapePath);
            canvas.drawPath(shapePath, iconStroke);
        } else {
            canvas.drawCircle(cx, cy, Math.max(0.0f, radius - border * 0.5f), iconStroke);
        }
        float knobX = cx;
        float knobY = cy;
        PointerState pointer = pointerForControl(control.getId());
        if (pointer != null) {
            float dx = pointer.lastX - cx;
            float dy = pointer.lastY - cy;
            float length = (float) Math.sqrt(dx * dx + dy * dy);
            float max = octagon ? octagonReach(radius, (float) Math.atan2(dy, dx)) : radius;
            if (length > max) { dx *= max / length; dy *= max / length; }
            knobX += dx;
            knobY += dy;
        }
        paint.setColor(withAlpha(pointer != null ? colors.getPressedColor() : colors.getFillColor(), alpha));
        canvas.drawCircle(knobX, knobY, knobRadius, paint);
        iconStroke.setColor(withAlpha(pointer != null ? colors.getPressedBorderColor() : colors.getBorderColor(), alpha));
        canvas.drawCircle(knobX, knobY, Math.max(0.0f, knobRadius - border * 0.5f), iconStroke);

        boolean moveStick = control.getActionId().length() == 0;
        RetroTouchAction action = moveStick ? null : actions.get(control.getActionId());
        RetroTouchIcon icon = null;
        String label = null;
        if (look != null && look.getIcon() != null) icon = look.getIcon();
        else if (look != null && look.getLabel() != null) label = normalizeLabel(look.getLabel());
        else if (!moveStick && base == RetroTouchButtonStyle.ICONS && action != null && action.getIcon() != null) icon = action.getIcon();
        else if (!moveStick) label = normalizeLabel(control.getLabel());
        if (look != null) {
            knobX += look.getOffsetX() * knobRadius * 2.0f;
            knobY += look.getOffsetY() * knobRadius * 2.0f;
        }
        if (icon != null) {
            int iconInk = pointer != null ? colors.getPressedIconColor() : colors.getIconColor();
            drawIconOptical(canvas, icon, knobX, knobY, knobRadius * 2.0f * 0.55f * icon.getExtraScale(), iconInk, alpha);
        } else if (label != null && label.length() > 0) {
            paint.setColor(withAlpha(pointer != null ? colors.getPressedTextColor() : colors.getTextColor(), alpha));
            float box = label.codePointCount(0, label.length()) == 1 ? knobRadius * 2.0f / 0.68f :
                    Math.max(0.0f, knobRadius - border) * 2.0f * 0.78f;
            drawOpticalText(canvas, label, true, knobX, knobY, box, box);
        }
    }

    private static final float OCTAGON_APOTHEM = (float) Math.cos(Math.PI / 8.0);

    /** An octagon with its corners at the eight stick directions (right, down-right, ...) on {@code radius}. */
    private static void buildOctagon(float cx, float cy, float radius, Path out) {
        out.reset();
        for (int i = 0; i < 8; ++i) {
            double angle = i * Math.PI / 4.0;
            float x = cx + (float) (radius * Math.cos(angle));
            float y = cy + (float) (radius * Math.sin(angle));
            if (i == 0) out.moveTo(x, y);
            else out.lineTo(x, y);
        }
        out.close();
    }

    /** Distance from the center to the octagon's edge in this direction. */
    private static float octagonReach(float radius, float angle) {
        double step = Math.PI / 4.0;
        double within = angle % step;
        if (within < 0) within += step;
        return (float) (radius * OCTAGON_APOTHEM / Math.cos(within - step * 0.5));
    }

    /** A D-pad in a skin: the ICONS cross with the skin's icons, or four separate round buttons. */
    private void drawSkinDpad(Canvas canvas, RetroTouchControl control, RetroTouchSkin skin, float cx, float cy,
                              float size, String active, int alpha) {
        RetroTouchColors colors = skinColorsFor(control, null, skin, DPAD_COLORS);
        if (skin.getDpadStyle() == RetroTouchDpadStyle.CROSS) {
            drawIconDpad(canvas, cx, cy, size, active, alpha, colors, skinDpadIcons(skin));
            return;
        }
        float distance = size * 0.32f;
        float buttonRadius = size * 0.18f;
        float border = skinBorder(colors, buttonRadius * 2.0f, skin.getBaseStyle());
        for (int i = 0; i < 4; ++i) {
            float bx = cx + (i == 2 ? -distance : (i == 3 ? distance : 0.0f));
            float by = cy + (i == 0 ? -distance : (i == 1 ? distance : 0.0f));
            boolean pressed = DIRECTIONS[i].equals(active);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(withAlpha(pressed ? colors.getPressedColor() : colors.getFillColor(), alpha));
            canvas.drawCircle(bx, by, buttonRadius, paint);
            if (border > 0.0f) {
                iconStroke.setStrokeWidth(border);
                iconStroke.setColor(withAlpha(pressed ? colors.getPressedBorderColor() : colors.getBorderColor(), alpha));
                canvas.drawCircle(bx, by, Math.max(0.0f, buttonRadius - border * 0.5f), iconStroke);
            }
            RetroTouchIcon icon = skinDpadIcon(skin, i);
            drawIconOptical(canvas, icon, bx, by, buttonRadius * 2.0f * 0.55f * icon.getExtraScale(),
                    pressed ? colors.getPressedIconColor() : colors.getIconColor(), alpha);
        }
    }

    private final RetroTouchIcon[] dpadIconScratch = new RetroTouchIcon[4];

    private RetroTouchIcon[] skinDpadIcons(RetroTouchSkin skin) {
        for (int i = 0; i < 4; ++i) dpadIconScratch[i] = skinDpadIcon(skin, i);
        return dpadIconScratch;
    }

    private static RetroTouchIcon skinDpadIcon(RetroTouchSkin skin, int index) {
        RetroTouchIcon icon = skin.dpadIcon(index);
        return icon != null ? icon : CHEVRONS[index];
    }

    /** Like drawButtonText, but every line is centered on its ink, not on the font's ascent and descent. */
    private void drawOpticalText(Canvas canvas, String label, boolean round, float cx, float cy, float width, float height) {
        float radius = width * 0.5f;
        if (label.codePointCount(0, label.length()) == 1) {
            paint.setTextSize(round ? radius * 0.68f : height * 0.62f);
            drawCenteredGlyph(canvas, label, cx, cy, paint);
            return;
        }
        float maximumWidth;
        float maximumHeight;
        if (round) {
            paint.setTextSize(Math.max(dp(8), Math.min(dp(16), radius * 0.34f)));
            maximumWidth = radius * 1.55f;
            maximumHeight = radius * 1.40f;
        } else {
            paint.setTextSize(Math.max(dp(8), Math.min(dp(16), height * 0.42f)));
            maximumWidth = width * 0.84f;
            maximumHeight = height * 0.80f;
        }
        paint.setTextAlign(Paint.Align.CENTER);
        String[] lines = splitButtonLabel(label, maximumWidth, paint);
        fitButtonLabel(lines, maximumWidth, maximumHeight, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        if (lines.length == 1) {
            paint.getTextBounds(lines[0], 0, lines[0].length(), textBounds);
            canvas.drawText(lines[0], cx - textBounds.exactCenterX(), cy - textBounds.exactCenterY(), paint);
            return;
        }
        Paint.FontMetrics fm = paint.getFontMetrics();
        float lineHeight = (fm.descent - fm.ascent) * 0.82f;
        paint.getTextBounds(lines[0], 0, lines[0].length(), textBounds);
        paint.getTextBounds(lines[1], 0, lines[1].length(), secondTextBounds);
        float baseline = cy - (textBounds.top + lineHeight + secondTextBounds.bottom) * 0.5f;
        canvas.drawText(lines[0], cx - textBounds.exactCenterX(), baseline, paint);
        canvas.drawText(lines[1], cx - secondTextBounds.exactCenterX(), baseline + lineHeight, paint);
    }

    /** The ICONS style's border width: the colors' fraction, else 7 %, of the smaller side. */
    private float iconBorderWidth(RetroTouchColors colors, float smallerSide) {
        float fraction = colors.getBorderWidth();
        return (Float.isNaN(fraction) ? ICON_BORDER : fraction) * smallerSide;
    }

    /** Draws an icon with its view box centered on cx/cy and scaled to {@code box}; allocation-free. */
    private void drawIcon(Canvas canvas, RetroTouchIcon icon, float cx, float cy, float box, int color, int alpha) {
        float scale = box / icon.getViewBoxSize();
        canvas.save();
        canvas.translate(cx - box * 0.5f, cy - box * 0.5f);
        canvas.scale(scale, scale);
        iconStroke.setStrokeWidth(icon.getViewBoxSize() * 2.0f / 24.0f);
        iconStroke.setColor(withAlpha(color, alpha));
        if (icon.isFilled()) iconStroke.setStyle(Paint.Style.FILL_AND_STROKE);
        canvas.drawPath(icon.path(), iconStroke);
        iconStroke.setStyle(Paint.Style.STROKE);
        canvas.restore();
    }

    /** Draws an icon with the center of its drawn path (its ink), not its view box, on cx/cy. */
    private void drawIconOptical(Canvas canvas, RetroTouchIcon icon, float cx, float cy, float box, int color, int alpha) {
        RectF ink = icon.bounds();
        float scale = box / icon.getViewBoxSize();
        canvas.save();
        canvas.translate(cx - ink.centerX() * scale, cy - ink.centerY() * scale);
        canvas.scale(scale, scale);
        iconStroke.setStrokeWidth(icon.getViewBoxSize() * 2.0f / 24.0f);
        iconStroke.setColor(withAlpha(color, alpha));
        if (icon.isFilled()) iconStroke.setStyle(Paint.Style.FILL_AND_STROKE);
        canvas.drawPath(icon.path(), iconStroke);
        iconStroke.setStyle(Paint.Style.STROKE);
        canvas.restore();
    }

    /**
     * The button's shape: the control's own (1.0.0-beta.10), else the host's choice for its action,
     * otherwise chosen from the label.
     */
    private RetroTouchButtonShape shapeFor(RetroTouchControl control) {
        return shapeFor(control, normalizeLabel(control.getLabel()));
    }

    private RetroTouchButtonShape shapeFor(RetroTouchControl control, String label) {
        if (control.getShape() != RetroTouchButtonShape.AUTO) return control.getShape();
        RetroTouchButtonShape shape = buttonShapes.get(control.getActionId());
        if (shape != null) return shape;
        if (RECTANGLE_LABELS.contains(label)) return RetroTouchButtonShape.RECTANGLE;
        if (SHOULDER_LABELS.contains(label)) return RetroTouchButtonShape.SHOULDER;
        return RetroTouchButtonShape.ROUND;
    }

    /**
     * Bounds of a button, measured in the diameter a round button of the same size has: ROUND is a
     * square of it, RECTANGLE 1.2 x 0.6, SHOULDER 1.5 x 0.75, and ROUNDED_RECT and CAPSULE are as
     * high as it and aspect times as wide.
     */
    private void buttonRect(RetroTouchControl control, RetroTouchButtonShape shape, RectF output) {
        float diameter = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight());
        float halfWidth;
        float halfHeight;
        if (shape == RetroTouchButtonShape.ROUNDED_RECT || shape == RetroTouchButtonShape.CAPSULE || isPathShape(shape)) {
            halfHeight = diameter * 0.5f;
            halfWidth = halfHeight * aspectFor(control, shape);
        } else if (shape == RetroTouchButtonShape.ROUND) {
            halfWidth = halfHeight = diameter * 0.5f;
        } else {
            halfWidth = diameter * (shape == RetroTouchButtonShape.SHOULDER ? 0.75f : 0.60f);
            halfHeight = halfWidth * 0.5f;
        }
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        output.set(cx - halfWidth, cy - halfHeight, cx + halfWidth, cy + halfHeight);
    }

    /**
     * Aspect ratio of a button: the one its control has in the default layout when that control has
     * the same action there, else the action's (setButtonAspect), else 1:1.
     */
    private float aspectFor(RetroTouchControl control, RetroTouchButtonShape shape) {
        RetroTouchLook look = lookFor(control);
        if (look != null && !Float.isNaN(look.getAspect())) return look.getAspect();
        RetroTouchControl source = defaultLayout == null ? null : defaultLayout.find(control.getId());
        if (source != null && source.hasAspect() && source.getActionId().equals(control.getActionId()))
            return source.getAspect();
        Float aspect = buttonAspects.get(control.getActionId());
        if (aspect != null) return aspect;
        if (shape == RetroTouchButtonShape.KIDNEY) return 1.6f;
        if (shape == RetroTouchButtonShape.BUMPER) return 2.2f;
        if (shape == RetroTouchButtonShape.TRIGGER) return 0.8f;
        return 1.0f;
    }

    private void drawStick(Canvas canvas, RetroTouchControl control) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float radius = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight()) * 0.5f;
        int alpha = Math.round(255.0f * control.getOpacity());
        RetroTouchSkin skin = activeSkin();
        if (skin != null) {
            drawSkinStick(canvas, control, skin);
            return;
        }
        RetroTouchColors colors = colorsFor(control, STICK_COLORS);
        if (getButtonStyle() == RetroTouchButtonStyle.ICONS) {
            drawIconStick(canvas, control, cx, cy, radius, alpha, colors);
            return;
        }
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(colors.baseColor(), Math.round(alpha * 0.55f)));
        canvas.drawCircle(cx, cy, radius, paint);
        stroke.setColor(withAlpha(colors.getBorderColor(), alpha));
        canvas.drawCircle(cx, cy, radius, stroke);
        float knobX = cx;
        float knobY = cy;
        PointerState pointer = pointerForControl(control.getId());
        if (pointer != null) {
            float dx = pointer.lastX - cx;
            float dy = pointer.lastY - cy;
            float length = (float) Math.sqrt(dx * dx + dy * dy);
            float max = radius; // the knob's center runs along the ring
            if (length > max) { dx *= max / length; dy *= max / length; }
            knobX += dx;
            knobY += dy;
        }
        paint.setColor(withAlpha(pointer != null ? colors.getPressedColor() : colors.getFillColor(), alpha));
        canvas.drawCircle(knobX, knobY, radius * 0.42f, paint);
        paint.setColor(withAlpha(colors.getTextColor(), alpha));
        paint.setTextAlign(Paint.Align.CENTER);
        String label = control.getActionId().length() == 0 ? "MOVE" : normalizeLabel(control.getLabel());
        if (label.codePointCount(0, label.length()) == 1) {
            // a stick action's single letter (C) as large as on a button's knob
            paint.setTextSize(radius * 0.42f);
            drawCenteredGlyph(canvas, label, knobX, knobY, paint);
            return;
        }
        paint.setTextSize(Math.max(dp(9), radius * 0.24f));
        drawCenteredText(canvas, label, cx, cy, paint);
    }

    /**
     * A stick in the ICONS style: same colors and border width as the buttons. A stick action shows
     * its icon on the knob, else its label (1.0.0-beta.12); the move stick shows neither.
     */
    private void drawIconStick(Canvas canvas, RetroTouchControl control, float cx, float cy, float radius,
                               int alpha, RetroTouchColors colors) {
        float knobRadius = radius * 0.42f;
        float border = iconBorderWidth(colors, knobRadius * 2.0f);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(colors.getFillColor(), Math.round(alpha * 0.55f)));
        canvas.drawCircle(cx, cy, radius, paint);
        iconStroke.setStrokeWidth(border);
        iconStroke.setColor(withAlpha(colors.getBorderColor(), alpha));
        canvas.drawCircle(cx, cy, Math.max(0.0f, radius - border * 0.5f), iconStroke);
        float knobX = cx;
        float knobY = cy;
        PointerState pointer = pointerForControl(control.getId());
        if (pointer != null) {
            float dx = pointer.lastX - cx;
            float dy = pointer.lastY - cy;
            float length = (float) Math.sqrt(dx * dx + dy * dy);
            if (length > radius) { dx *= radius / length; dy *= radius / length; }
            knobX += dx;
            knobY += dy;
        }
        paint.setColor(withAlpha(pointer != null ? colors.getPressedColor() : colors.getFillColor(), alpha));
        canvas.drawCircle(knobX, knobY, knobRadius, paint);
        iconStroke.setColor(withAlpha(pointer != null ? colors.getPressedBorderColor() : colors.getBorderColor(), alpha));
        canvas.drawCircle(knobX, knobY, Math.max(0.0f, knobRadius - border * 0.5f), iconStroke);
        if (control.getActionId().length() == 0) return;
        int ink = pointer != null ? colors.getPressedTextColor() : colors.getTextColor();
        RetroTouchAction action = actions.get(control.getActionId());
        RetroTouchIcon icon = action == null ? null : action.getIcon();
        if (icon != null) {
            int iconInk = pointer != null ? colors.getPressedIconColor() : colors.getIconColor();
            drawIcon(canvas, icon, knobX, knobY, knobRadius * 2.0f * 0.55f * icon.getExtraScale(), iconInk, alpha);
            return;
        }
        String label = normalizeLabel(control.getLabel());
        if (label.length() == 0) return;
        paint.setColor(withAlpha(ink, alpha));
        // a single letter as large as in the LABELS style (text size = knob radius); longer labels
        // such as KNIFE keep clear of the knob's ring
        float box = label.codePointCount(0, label.length()) == 1 ? knobRadius * 2.0f / 0.68f :
                Math.max(0.0f, knobRadius - border) * 2.0f * 0.78f;
        drawButtonText(canvas, label, true, knobX, knobY, box, box);
    }

    /** A D-pad in the ICONS style: one cross outline with a chevron icon in each arm. */
    private void drawIconDpad(Canvas canvas, float cx, float cy, float size, String active, int alpha,
                              RetroTouchColors colors, RetroTouchIcon[] icons) {
        float fraction = colors.getBorderWidth();
        float border = (Float.isNaN(fraction) ? ICON_BORDER : fraction) * size * (5.0f / 7.0f);
        float arm = size * 0.225f;                     // half the arm width
        float reach = size * 0.5f - border * 0.5f;     // the outline stays inside the control
        dpadPath.reset();
        dpadPath.moveTo(cx - arm, cy - reach);
        dpadPath.lineTo(cx + arm, cy - reach);
        dpadPath.lineTo(cx + arm, cy - arm);
        dpadPath.lineTo(cx + reach, cy - arm);
        dpadPath.lineTo(cx + reach, cy + arm);
        dpadPath.lineTo(cx + arm, cy + arm);
        dpadPath.lineTo(cx + arm, cy + reach);
        dpadPath.lineTo(cx - arm, cy + reach);
        dpadPath.lineTo(cx - arm, cy + arm);
        dpadPath.lineTo(cx - reach, cy + arm);
        dpadPath.lineTo(cx - reach, cy - arm);
        dpadPath.lineTo(cx - arm, cy - arm);
        dpadPath.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(colors.getFillColor(), alpha));
        canvas.drawPath(dpadPath, paint);
        if (active != null) {
            paint.setColor(withAlpha(colors.getPressedColor(), alpha));
            if (RetroTouchNavigation.UP.equals(active)) canvas.drawRect(cx - arm, cy - reach, cx + arm, cy - arm, paint);
            else if (RetroTouchNavigation.DOWN.equals(active)) canvas.drawRect(cx - arm, cy + arm, cx + arm, cy + reach, paint);
            else if (RetroTouchNavigation.LEFT.equals(active)) canvas.drawRect(cx - reach, cy - arm, cx - arm, cy + arm, paint);
            else canvas.drawRect(cx + arm, cy - arm, cx + reach, cy + arm, paint);
        }
        if (border > 0.0f) {
            iconStroke.setStrokeWidth(border);
            iconStroke.setColor(withAlpha(colors.getBorderColor(), alpha));
            canvas.drawPath(dpadPath, iconStroke);
        }
        float middle = (arm + reach) * 0.5f;
        float box = size * 0.25f;
        drawChevron(canvas, icons[0], RetroTouchNavigation.UP, cx, cy - middle, box, active, alpha, colors);
        drawChevron(canvas, icons[1], RetroTouchNavigation.DOWN, cx, cy + middle, box, active, alpha, colors);
        drawChevron(canvas, icons[2], RetroTouchNavigation.LEFT, cx - middle, cy, box, active, alpha, colors);
        drawChevron(canvas, icons[3], RetroTouchNavigation.RIGHT, cx + middle, cy, box, active, alpha, colors);
    }

    private void drawChevron(Canvas canvas, RetroTouchIcon icon, String direction, float cx, float cy, float box,
                             String active, int alpha, RetroTouchColors colors) {
        int color = direction.equals(active) ? colors.getPressedIconColor() : colors.getIconColor();
        drawIcon(canvas, icon, cx, cy, box * icon.getExtraScale(), color, alpha);
    }

    private void drawDpad(Canvas canvas, RetroTouchControl control) {
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        float size = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight());
        float cell = size / 3.0f;
        int alpha = Math.round(255.0f * control.getOpacity());
        PointerState pointer = pointerForControl(control.getId());
        String active = pointer == null ? null : pointer.activeActionId;
        RetroTouchSkin skin = activeSkin();
        if (skin != null) {
            drawSkinDpad(canvas, control, skin, cx, cy, size, active, alpha);
            return;
        }
        RetroTouchColors colors = colorsFor(control, DPAD_COLORS);
        if (getButtonStyle() == RetroTouchButtonStyle.ICONS) {
            drawIconDpad(canvas, cx, cy, size, active, alpha, colors, CHEVRONS);
            return;
        }
        drawDpadCell(canvas, cx, cy - cell, cell, RetroTouchNavigation.UP, active, alpha, colors);
        drawDpadCell(canvas, cx, cy + cell, cell, RetroTouchNavigation.DOWN, active, alpha, colors);
        drawDpadCell(canvas, cx - cell, cy, cell, RetroTouchNavigation.LEFT, active, alpha, colors);
        drawDpadCell(canvas, cx + cell, cy, cell, RetroTouchNavigation.RIGHT, active, alpha, colors);
        drawDpadCell(canvas, cx, cy, cell, null, active, alpha, colors);
    }

    private void drawDpadCell(Canvas canvas, float cx, float cy, float size, String direction,
                              String active, int alpha, RetroTouchColors colors) {
        float half = size * 0.48f;
        rect.set(cx - half, cy - half, cx + half, cy + half);
        boolean pressed = direction != null && direction.equals(active);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(pressed ? colors.getPressedColor() : colors.getFillColor(), alpha));
        canvas.drawRoundRect(rect, size * 0.13f, size * 0.13f, paint);
        stroke.setColor(withAlpha(colors.getBorderColor(), alpha));
        canvas.drawRoundRect(rect, size * 0.13f, size * 0.13f, stroke);
        if (direction == null) return;
        paint.setColor(withAlpha(colors.getTextColor(), alpha));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.max(dp(9), size * 0.34f));
        String arrow = RetroTouchNavigation.UP.equals(direction) ? "▲" :
                (RetroTouchNavigation.DOWN.equals(direction) ? "▼" :
                        (RetroTouchNavigation.LEFT.equals(direction) ? "◀" : "▶"));
        drawCenteredText(canvas, arrow, cx, cy, paint);
    }

    private void drawLookZone(Canvas canvas, RetroTouchControl control) {
        controlRect(control, rect);
        paint.setStyle(Paint.Style.FILL);
        int alpha = Math.round(90.0f * control.getOpacity());
        paint.setColor(withAlpha(Color.rgb(125, 125, 125), alpha));
        canvas.drawRoundRect(rect, dp(12), dp(12), paint);
        stroke.setColor(withAlpha(Color.rgb(205, 205, 205), Math.max(35, Math.round(255.0f * control.getOpacity()))));
        canvas.drawRoundRect(rect, dp(12), dp(12), stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(15));
        paint.setColor(withAlpha(Color.WHITE, Math.max(55, Math.round(255.0f * control.getOpacity()))));
        drawCenteredText(canvas, "LOOK AREA", rect.centerX(), rect.centerY(), paint);
    }

    private void drawSelection(Canvas canvas, RetroTouchControl control) {
        visibleRect(control, rect);
        rect.inset(-dp(4), -dp(4));
        stroke.setColor(Color.WHITE);
        stroke.setStrokeWidth(dp(3));
        canvas.drawRoundRect(rect, dp(8), dp(8), stroke);
        stroke.setStrokeWidth(dp(BORDER_WIDTH_DP));
    }

    private void drawGear(Canvas canvas) {
        RectF gear = gearRect();
        int alpha = Math.round(255.0f * settingsOpacity);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(Color.BLACK, alpha));
        canvas.drawCircle(gear.centerX(), gear.centerY(), gear.width() * 0.5f, paint);
        stroke.setStrokeWidth(dp(1.0f));
        stroke.setColor(withAlpha(Color.WHITE, alpha));
        canvas.drawCircle(gear.centerX(), gear.centerY(), gear.width() * 0.5f, stroke);
        stroke.setStrokeWidth(dp(BORDER_WIDTH_DP));
        paint.setColor(withAlpha(Color.WHITE, alpha));
        paint.setStrokeWidth(dp(1.0f));
        for (int i = -1; i <= 1; ++i) {
            float yy = gear.centerY() + i * gear.height() * 0.19f;
            float left = gear.left + gear.width() * 0.27f;
            float right = gear.right - gear.width() * 0.27f;
            canvas.drawLine(left, yy, right, yy, paint);
            float knob = i == 0 ? gear.centerX() - gear.width() * 0.10f : gear.centerX() + i * gear.width() * 0.08f;
            canvas.drawCircle(knob, yy, dp(1.1f), paint);
        }
        if (editing && POINTER_GEAR.equals(selectedControlId)) {
            stroke.setColor(Color.WHITE);
            stroke.setStrokeWidth(dp(3));
            canvas.drawCircle(gear.centerX(), gear.centerY(), gear.width() * 0.60f, stroke);
            stroke.setStrokeWidth(dp(BORDER_WIDTH_DP));
        }
    }

    private void drawToolbar(Canvas canvas) {
        float top = toolbarTop();
        float bottom = top + toolbarHeight();
        float handleBottom = top + toolbarHandleHeight();
        int[] tools = tools();
        float barLeft = safeLeft();
        float barRight = safeRight();
        float itemWidth = (barRight - barLeft) / (float) tools.length;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(Color.BLACK, 225));
        canvas.drawRect(barLeft, top, barRight, bottom, paint);
        paint.setColor(withAlpha(Color.DKGRAY, 235));
        canvas.drawRect(barLeft, top, barRight, handleBottom, paint);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize(Math.max(dp(9), Math.min(dp(13), toolbarHandleHeight() * 0.48f)));
        paint.setColor(Color.WHITE);
        String selected = selectedControlId == null ? "Tap a control, then drag it" :
                (POINTER_GEAR.equals(selectedControlId) ? "Selected: SETTINGS" : "Selected: " + selectedControlId);
        drawCenteredText(canvas, "\u2195 DRAG   " + selected, barLeft + dp(10), top + toolbarHandleHeight() * 0.5f, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(Math.max(dp(8), Math.min(dp(13), itemWidth * 0.17f)));
        for (int i = 0; i < tools.length; ++i) {
            int tool = tools[i];
            float left = barLeft + i * itemWidth;
            rect.set(left + dp(2), handleBottom + dp(3), left + itemWidth - dp(2), bottom - dp(4));
            boolean enabled = isToolEnabled(tool);
            paint.setColor(withAlpha(tool == TOOL_SAVE ? accentColor : Color.DKGRAY, enabled ? 235 : 80));
            canvas.drawRoundRect(rect, dp(5), dp(5), paint);
            paint.setColor(withAlpha(Color.WHITE, enabled ? 255 : 85));
            RetroTouchSkin skin = tool == TOOL_STYLE ? activeSkin() : null;
            String name = tool != TOOL_STYLE ? TOOL_LABELS[tool] : (skin != null ? skin.getName() :
                    (getButtonStyle() == RetroTouchButtonStyle.ICONS ? iconsToggleName : labelsToggleName));
            drawCenteredText(canvas, name, rect.centerX(), rect.centerY(), paint);
        }
    }

    private void applyTool(int tool) {
        if (!isToolEnabled(tool)) return;
        RetroTouchControl selected = findControl(selectedControlId);
        boolean settingsSelected = POINTER_GEAR.equals(selectedControlId);
        if (tool == TOOL_ADD) addButton();
        else if (tool == TOOL_STYLE && !skins.isEmpty()) cycleSkin();
        else if (tool == TOOL_STYLE) toggleButtonStyle();
        else if (tool == 1 && selected != null) cycleAction(selected);
        else if (tool == 2 && settingsSelected) scaleSettingsButton(0.86f);
        else if (tool == 3 && settingsSelected) scaleSettingsButton(1.16f);
        else if (tool == 4 && settingsSelected) settingsOpacity = nextOpacity(settingsOpacity);
        else if (tool == 2 && selected != null) {
            selected.scale(0.86f);
            placeControl(selected, selected.getX(), selected.getY());
        } else if (tool == 3 && selected != null) {
            selected.scale(1.16f);
            placeControl(selected, selected.getX(), selected.getY());
        }
        else if (tool == 4 && selected != null) selected.cycleOpacity();
        else if (tool == 5 && selected != null) {
            controls.remove(selected);
            selectedControlId = null;
        } else if (tool == TOOL_RESET) resetToDefault(); // positions and sizes only, never the style
        else if (tool == TOOL_SAVE) {
            saveLayout();
            setEditing(false);
        }
        invalidate();
    }

    private boolean isToolEnabled(int tool) {
        RetroTouchControl selected = findControl(selectedControlId);
        boolean settingsSelected = POINTER_GEAR.equals(selectedControlId);
        if (tool == TOOL_ADD) return firstButtonAction() != null && buttonCount() < RetroTouchLayout.MAX_BUTTONS;
        if (tool == TOOL_STYLE) return styleToggleShown();
        if (tool == 1) return selected != null && (selected.getType() == RetroTouchControl.Type.BUTTON ||
                (selected.getType() == RetroTouchControl.Type.MOVE_STICK && selected.getActionId().length() > 0));
        if (tool >= 2 && tool <= 4) return selected != null || settingsSelected;
        // SETTINGS is deliberately permanent: DELETE is visibly disabled and cannot remove it.
        if (tool == 5) return selected != null;
        return tool == TOOL_RESET || tool == TOOL_SAVE;
    }

    /** The editor tools in toolbar order; the style toggle sits before RESET when it is shown. */
    private int[] tools() {
        return styleToggleShown() ? TOOLS_WITH_STYLE : TOOLS;
    }

    private int buttonCount() {
        int count = 0;
        for (RetroTouchControl control : controls)
            if (control.getType() == RetroTouchControl.Type.BUTTON) ++count;
        return count;
    }

    private void addButton() {
        RetroTouchAction first = firstButtonAction();
        if (buttonCount() >= RetroTouchLayout.MAX_BUTTONS || first == null) return;
        int number = 1;
        while (findControl("button_" + number) != null) ++number;
        RetroTouchControl added = RetroTouchControl.button("button_" + number, first.getId(), first.getLabel(),
                0.52f, 0.50f, 0.12f);
        applyPresentation(added);
        controls.add(added);
        selectedControlId = added.getId();
    }

    private void cycleAction(RetroTouchControl control) {
        if (actions.isEmpty()) return;
        List<RetroTouchAction> list = new ArrayList<RetroTouchAction>(actions.values());
        int current = -1;
        for (int i = 0; i < list.size(); ++i) if (list.get(i).getId().equals(control.getActionId())) current = i;
        // the next action this control can take: a layout holds at most maxSticks sticks and MAX_BUTTONS buttons
        int sticks = 0;
        for (RetroTouchControl other : controls)
            if (other != control && other.getType() == RetroTouchControl.Type.MOVE_STICK) ++sticks;
        int buttons = buttonCount() - (control.getType() == RetroTouchControl.Type.BUTTON ? 1 : 0);
        for (int step = 1; step <= list.size(); ++step) {
            RetroTouchAction next = list.get((current + step) % list.size());
            boolean stick = stickActions.contains(next.getId());
            if (stick ? sticks >= maxSticks : buttons >= RetroTouchLayout.MAX_BUTTONS) continue;
            control.setAction(next.getId(), next.getLabel());
            control.setType(stick ? RetroTouchControl.Type.MOVE_STICK : RetroTouchControl.Type.BUTTON);
            return;
        }
    }

    private void refreshControlLabels() {
        // a control changes kind only within the layout limits (maxSticks sticks, MAX_BUTTONS buttons)
        int sticks = 0;
        for (RetroTouchControl control : controls)
            if (control.getType() == RetroTouchControl.Type.MOVE_STICK) ++sticks;
        int buttons = buttonCount();
        for (RetroTouchControl control : controls) {
            boolean stick = control.getType() == RetroTouchControl.Type.MOVE_STICK && control.getActionId().length() > 0;
            if (control.getType() != RetroTouchControl.Type.BUTTON && !stick) continue;
            RetroTouchAction action = actions.get(control.getActionId());
            if (action == null) continue;
            boolean toStick = stickActions.contains(action.getId());
            if (toStick && !stick && sticks < maxSticks) {
                control.setType(RetroTouchControl.Type.MOVE_STICK);
                ++sticks;
                --buttons;
            } else if (!toStick && stick && buttons < RetroTouchLayout.MAX_BUTTONS) {
                control.setType(RetroTouchControl.Type.BUTTON);
                ++buttons;
                --sticks;
            }
            control.setAction(action.getId(), action.getLabel());
        }
    }

    /** The first registered action that is not a stick action; ADD gives it to a new button. */
    private RetroTouchAction firstButtonAction() {
        for (RetroTouchAction action : actions.values())
            if (!stickActions.contains(action.getId())) return action;
        return null;
    }

    /**
     * Saved layouts contain no colors, shapes or aspect ratios, so every load takes them from the
     * game's current default layout by control ID. They stay owned by the game, like action labels.
     */
    private void refreshControlColors() {
        for (RetroTouchControl control : controls) applyPresentation(control);
    }

    private void applyPresentation(RetroTouchControl control) {
        RetroTouchControl source = defaultLayout.find(control.getId());
        if (source == null) control.setPresentation(null, RetroTouchButtonShape.AUTO, 1.0f);
        else control.setPresentation(source.getColors(), source.getShape(), source.hasAspect() ? source.getAspect() : Float.NaN);
    }

    /** Resolves colors in this order: control, action, view-wide default, built-in grey. */
    private RetroTouchColors colorsFor(RetroTouchControl control, RetroTouchColors builtIn) {
        if (control.getColors() != null) return control.getColors();
        RetroTouchAction action = control.getType() == RetroTouchControl.Type.BUTTON ||
                control.getType() == RetroTouchControl.Type.MOVE_STICK ? actions.get(control.getActionId()) : null;
        if (action != null && action.getColors() != null) return action.getColors();
        return defaultColors != null ? defaultColors : builtIn;
    }

    private boolean isKnownAction(String id) { return actions.containsKey(id); }

    private RetroTouchControl findControl(String id) {
        if (id == null) return null;
        for (RetroTouchControl control : controls) if (id.equals(control.getId())) return control;
        return null;
    }

    private PointerState pointerForControl(String id) {
        for (int i = 0; i < pointers.size(); ++i) if (id.equals(pointers.valueAt(i).controlId)) return pointers.valueAt(i);
        return null;
    }

    private boolean isControlPressed(String id) {
        if (pointerForControl(id) != null) return true;
        RetroTouchControl control = findControl(id);
        return control != null && latchedActions.contains(control.getActionId());
    }

    private RectF gearRect() {
        float originalSize = Math.max(dp(38), Math.min(dp(52), Math.min(getWidth(), getHeight()) * 0.105f));
        float size = originalSize * settingsScale;
        float margin = dp(10);
        float cx = Float.isNaN(settingsX) ? safeRight() - margin - size * 0.5f : settingsX * getWidth();
        float cy = Float.isNaN(settingsY) ? safeTop() + margin + size * 0.5f : settingsY * getHeight();
        cx = clamp(cx, size * 0.5f, Math.max(size * 0.5f, getWidth() - size * 0.5f));
        cy = clamp(cy, size * 0.5f, Math.max(size * 0.5f, getHeight() - size * 0.5f));
        return new RectF(cx - size * 0.5f, cy - size * 0.5f,
                cx + size * 0.5f, cy + size * 0.5f);
    }

    private void moveSettingsButton(float centerX, float centerY) {
        RectF gear = gearRect();
        float half = gear.width() * 0.5f;
        centerX = clamp(centerX, half, Math.max(half, getWidth() - half));
        centerY = clamp(centerY, half, Math.max(half, getHeight() - half));
        settingsX = getWidth() > 0 ? centerX / getWidth() : Float.NaN;
        settingsY = getHeight() > 0 ? centerY / getHeight() : Float.NaN;
    }

    private void scaleSettingsButton(float factor) {
        RectF before = gearRect();
        settingsX = getWidth() > 0 ? before.centerX() / getWidth() : settingsX;
        settingsY = getHeight() > 0 ? before.centerY() / getHeight() : settingsY;
        settingsScale = clamp(settingsScale * factor, 0.40f, 1.40f);
        moveSettingsButton(settingsX * getWidth(), settingsY * getHeight());
    }

    private float nextOpacity(float opacity) {
        if (opacity < 0.10f) return 0.14f;
        if (opacity < 0.20f) return 0.28f;
        if (opacity < 0.42f) return 0.58f;
        if (opacity < 0.75f) return 0.90f;
        return 0.07f;
    }

    private boolean isInsideGear(float x, float y) {
        RectF gear = gearRect();
        float dx = x - gear.centerX();
        float dy = y - gear.centerY();
        // Keep a comfortable invisible touch target although the icon itself is deliberately tiny.
        float radius = Math.max(dp(24), gear.width() * 0.65f);
        return dx * dx + dy * dy <= radius * radius;
    }

    private float toolbarHeight() {
        return Math.min(safeBottom() - safeTop(), Math.max(dp(76), getHeight() * 0.17f));
    }

    /** The area of the editor bar and the settings button's default position: the view minus the safe insets. */
    private float safeLeft() {
        return horizontalInsetsFit() ? safeInsetLeft : 0.0f;
    }

    private float safeRight() {
        return horizontalInsetsFit() ? getWidth() - safeInsetRight : getWidth();
    }

    private float safeTop() {
        return verticalInsetsFit() ? safeInsetTop : 0.0f;
    }

    private float safeBottom() {
        return verticalInsetsFit() ? getHeight() - safeInsetBottom : getHeight();
    }

    private boolean horizontalInsetsFit() {
        return (safeInsetLeft + (long) safeInsetRight) * 2L <= getWidth();
    }

    private boolean verticalInsetsFit() {
        return (safeInsetTop + (long) safeInsetBottom) * 2L <= getHeight();
    }

    private float toolbarHandleHeight() {
        return Math.min(toolbarHeight() * 0.32f, Math.max(dp(18), toolbarHeight() * 0.25f));
    }

    private float toolbarTop() {
        float height = toolbarHeight();
        float top = Float.isNaN(toolbarCenterY) ? safeBottom() - height :
                toolbarCenterY * getHeight() - height * 0.5f;
        return clamp(top, safeTop(), Math.max(safeTop(), safeBottom() - height));
    }

    private boolean isInsideToolbar(float x, float y) {
        return editing && x >= safeLeft() && x < safeRight() &&
                y >= toolbarTop() && y <= toolbarTop() + toolbarHeight();
    }

    private boolean isInsideToolbarHandle(float x, float y) {
        return isInsideToolbar(x, y) && y <= toolbarTop() + toolbarHandleHeight();
    }

    private int toolbarIndex(float x, float y) {
        float top = toolbarTop() + toolbarHandleHeight();
        if (!editing || y < top || y > toolbarTop() + toolbarHeight() || x < safeLeft() || x >= safeRight()) return -1;
        int[] tools = tools();
        float itemWidth = (safeRight() - safeLeft()) / (float) tools.length;
        return tools[Math.min(tools.length - 1, (int) ((x - safeLeft()) / itemWidth))];
    }

    /**
     * What the player sees of a control: a square around a round button, stick or D-pad, the
     * rectangle of a rectangle button, or the whole look zone.
     */
    private void visibleRect(RetroTouchControl control, RectF output) {
        if (control.getType() == RetroTouchControl.Type.LOOK_ZONE) {
            controlRect(control, output);
            return;
        }
        RetroTouchButtonShape shape = control.getType() == RetroTouchControl.Type.BUTTON ? effectiveShape(control) :
                RetroTouchButtonShape.ROUND;
        if (shape != RetroTouchButtonShape.ROUND) {
            buttonRect(control, shape, output);
            float rotation = rotationFor(control);
            if (rotation != 0.0f) {
                // the bounds of the turned shape's box
                double angle = Math.toRadians(rotation);
                float cos = (float) Math.abs(Math.cos(angle));
                float sin = (float) Math.abs(Math.sin(angle));
                float halfW = output.width() * 0.5f;
                float halfH = output.height() * 0.5f;
                float rotatedHalfW = halfW * cos + halfH * sin;
                float rotatedHalfH = halfW * sin + halfH * cos;
                float cx = output.centerX();
                float cy = output.centerY();
                output.set(cx - rotatedHalfW, cy - rotatedHalfH, cx + rotatedHalfW, cy + rotatedHalfH);
            }
            return;
        }
        float half = Math.min(control.getWidth() * getWidth(), control.getHeight() * getHeight()) * 0.5f;
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        output.set(cx - half, cy - half, cx + half, cy + half);
    }

    /** Moves a control so that what the player sees, border included, can reach every screen edge. */
    private void placeControl(RetroTouchControl control, float x, float y) {
        visibleRect(control, touchRect);
        float border = dp(BORDER_WIDTH_DP) * 0.5f;
        float halfWidth = getWidth() > 0 ? (touchRect.width() * 0.5f + border) / getWidth() : control.getWidth() * 0.5f;
        float halfHeight = getHeight() > 0 ? (touchRect.height() * 0.5f + border) / getHeight() : control.getHeight() * 0.5f;
        control.setPosition(x, y, halfWidth, halfHeight);
    }

    private void controlRect(RetroTouchControl control, RectF output) {
        float halfW = control.getWidth() * getWidth() * 0.5f;
        float halfH = control.getHeight() * getHeight() * 0.5f;
        float cx = control.getX() * getWidth();
        float cy = control.getY() * getHeight();
        output.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH);
    }

    private void drawCenteredText(Canvas canvas, String text, float x, float y, Paint p) {
        Paint.FontMetrics fm = p.getFontMetrics();
        canvas.drawText(text, x, y - (fm.ascent + fm.descent) * 0.5f, p);
    }

    /** Centers the glyph's actual ink bounds on x/y instead of its advance width and baseline. */
    private void drawCenteredGlyph(Canvas canvas, String glyph, float x, float y, Paint p) {
        p.getTextBounds(glyph, 0, glyph.length(), textBounds);
        p.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(glyph, x - textBounds.exactCenterX(), y - textBounds.exactCenterY(), p);
    }

    private void drawButtonLabel(Canvas canvas, String label, float x, float y,
                                 float maximumWidth, float maximumHeight, Paint p) {
        String[] lines = splitButtonLabel(label, maximumWidth, p);
        fitButtonLabel(lines, maximumWidth, maximumHeight, p);

        if (lines.length == 1) {
            drawCenteredText(canvas, lines[0], x, y, p);
            return;
        }
        Paint.FontMetrics fm = p.getFontMetrics();
        float lineHeight = (fm.descent - fm.ascent) * 0.82f;
        float centerOffset = -(fm.ascent + fm.descent) * 0.5f;
        canvas.drawText(lines[0], x, y + centerOffset - lineHeight * 0.5f, p);
        canvas.drawText(lines[1], x, y + centerOffset + lineHeight * 0.5f, p);
    }

    private String normalizeLabel(String value) {
        if (value == null) return "";
        String source = value.toUpperCase().replace("\r\n", "\n").replace('\r', '\n').trim();
        StringBuilder result = new StringBuilder(source.length());
        boolean previousSpace = false;
        for (int i = 0; i < source.length(); ++i) {
            char c = source.charAt(i);
            if (c == '\n') {
                while (result.length() > 0 && result.charAt(result.length() - 1) == ' ')
                    result.deleteCharAt(result.length() - 1);
                if (result.length() > 0 && result.charAt(result.length() - 1) != '\n')
                    result.append('\n');
                previousSpace = false;
            } else if (Character.isWhitespace(c)) {
                if (!previousSpace && result.length() > 0 && result.charAt(result.length() - 1) != '\n')
                    result.append(' ');
                previousSpace = true;
            } else {
                result.append(c);
                previousSpace = false;
            }
        }
        while (result.length() > 0 &&
                (result.charAt(result.length() - 1) == ' ' || result.charAt(result.length() - 1) == '\n'))
            result.deleteCharAt(result.length() - 1);
        return result.toString();
    }

    private String[] splitButtonLabel(String label, float maximumWidth, Paint p) {
        int explicitBreak = label.indexOf('\n');
        if (explicitBreak >= 0) {
            String first = label.substring(0, explicitBreak).trim();
            String second = label.substring(explicitBreak + 1).replace('\n', ' ').trim();
            if (first.length() == 0) return new String[] { second };
            if (second.length() == 0) return new String[] { first };
            return new String[] { first, second };
        }
        if (p.measureText(label) <= maximumWidth || label.indexOf(' ') < 0)
            return new String[] { label };

        String bestFirst = label;
        String bestSecond = "";
        float bestWidth = Float.MAX_VALUE;
        float bestBalance = Float.MAX_VALUE;
        for (int i = 1; i < label.length() - 1; ++i) {
            if (label.charAt(i) != ' ') continue;
            String first = label.substring(0, i).trim();
            String second = label.substring(i + 1).trim();
            float firstWidth = p.measureText(first);
            float secondWidth = p.measureText(second);
            float widest = Math.max(firstWidth, secondWidth);
            float balance = Math.abs(firstWidth - secondWidth);
            if (widest < bestWidth || (widest == bestWidth && balance < bestBalance)) {
                bestFirst = first;
                bestSecond = second;
                bestWidth = widest;
                bestBalance = balance;
            }
        }
        return bestSecond.length() == 0 ? new String[] { label } :
                new String[] { bestFirst, bestSecond };
    }

    private void fitButtonLabel(String[] lines, float maximumWidth, float maximumHeight, Paint p) {
        float widest = 0.0f;
        for (String line : lines) widest = Math.max(widest, p.measureText(line));
        Paint.FontMetrics fm = p.getFontMetrics();
        float fontHeight = fm.descent - fm.ascent;
        float totalHeight = lines.length == 1 ? fontHeight : fontHeight * 1.82f;
        float widthScale = widest > 0.0f ? maximumWidth / widest : 1.0f;
        float heightScale = totalHeight > 0.0f ? maximumHeight / totalHeight : 1.0f;
        float scale = Math.min(1.0f, Math.min(widthScale, heightScale));
        if (scale < 1.0f) p.setTextSize(Math.max(1.0f, p.getTextSize() * scale));
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00ffffff) | (Math.max(0, Math.min(255, alpha)) << 24);
    }

    private float opacityTwoStepsHigher(float opacity) {
        if (opacity < 0.10f) return 0.28f;
        if (opacity < 0.20f) return 0.58f;
        if (opacity < 0.42f) return 0.90f;
        return 1.0f;
    }

    private float clamp01(float value) {
        return Float.isNaN(value) ? Float.NaN : clamp(value, 0.0f, 1.0f);
    }

    private float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private static final class PointerState {
        final String controlId;
        float lastX;
        float lastY;
        float dragOffsetX;
        float dragOffsetY;
        boolean actionPressed;
        String activeActionId;

        PointerState(String controlId, float x, float y) {
            this.controlId = controlId;
            this.lastX = x;
            this.lastY = y;
        }
    }
}
