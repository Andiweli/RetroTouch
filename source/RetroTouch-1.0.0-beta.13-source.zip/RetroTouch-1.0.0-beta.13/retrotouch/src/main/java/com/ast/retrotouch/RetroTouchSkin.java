package com.ast.retrotouch;

import java.util.HashMap;
import java.util.Map;

/**
 * A named look of the whole overlay (1.0.0-beta.13), for example "RE", "GC", "PS2" or "XBOX".
 * A game registers any number of skins with RetroTouchView.registerSkin; with two or more the
 * editor's style button cycles through them and the player's choice is saved per game.
 *
 * <p>The base style decides what a button shows when its look sets neither label nor icon: ICONS
 * shows the action's icon (else its label), LABELS the action's label. Skins draw labels and icons
 * centered on their ink, not on font metrics. Configure a skin before registering it: the view keeps
 * a copy.
 */
public final class RetroTouchSkin {
    private final String id;
    private final String name;
    private final RetroTouchButtonStyle baseStyle;
    private final Map<String, RetroTouchLook> looks = new HashMap<String, RetroTouchLook>();
    private RetroTouchColors defaultColors;
    private RetroTouchLook moveStickLook;
    private RetroTouchDpadStyle dpadStyle = RetroTouchDpadStyle.CROSS;
    private RetroTouchIcon[] dpadIcons;
    private RetroTouchColors dpadColors;
    private RetroTouchStickGate stickGate = RetroTouchStickGate.ROUND;

    /**
     * @param id stable ID, saved as the player's choice; never shown
     * @param name what the editor's style button shows, for example "GC"
     * @param baseStyle LABELS or ICONS, see the class description
     */
    public RetroTouchSkin(String id, String name, RetroTouchButtonStyle baseStyle) {
        if (id == null || id.trim().length() == 0) throw new IllegalArgumentException("Skin id must not be empty");
        this.id = id.trim();
        this.name = name == null || name.trim().length() == 0 ? this.id : name.trim();
        this.baseStyle = baseStyle == null ? RetroTouchButtonStyle.ICONS : baseStyle;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public RetroTouchButtonStyle getBaseStyle() { return baseStyle; }

    /** Colors of every control that has no colors from its look, control or action. */
    public RetroTouchSkin setDefaultColors(RetroTouchColors colors) {
        defaultColors = colors;
        return this;
    }

    public RetroTouchColors getDefaultColors() { return defaultColors; }

    /** The look of every button or stick mapped to this action; null removes it. */
    public RetroTouchSkin setLook(String actionId, RetroTouchLook look) {
        if (actionId == null) throw new IllegalArgumentException("Action id must not be null");
        if (look == null) looks.remove(actionId);
        else looks.put(actionId, look);
        return this;
    }

    public RetroTouchLook getLook(String actionId) { return actionId == null ? null : looks.get(actionId); }

    /** Label, icon and colors of the move stick's knob, for example the label "L" or "LS"; null shows nothing. */
    public RetroTouchSkin setMoveStickLook(RetroTouchLook look) {
        moveStickLook = look;
        return this;
    }

    public RetroTouchLook getMoveStickLook() { return moveStickLook; }

    public RetroTouchSkin setDpadStyle(RetroTouchDpadStyle style) {
        dpadStyle = style == null ? RetroTouchDpadStyle.CROSS : style;
        return this;
    }

    public RetroTouchDpadStyle getDpadStyle() { return dpadStyle; }

    /**
     * Icons of the D-pad's four directions, for example the filled ARROW_UP ... ARROW_RIGHT. Null or
     * a null entry keeps the chevrons.
     */
    public RetroTouchSkin setDpadIcons(RetroTouchIcon up, RetroTouchIcon down, RetroTouchIcon left, RetroTouchIcon right) {
        dpadIcons = new RetroTouchIcon[] {
                up == null ? RetroTouchIcon.CHEVRON_UP : up,
                down == null ? RetroTouchIcon.CHEVRON_DOWN : down,
                left == null ? RetroTouchIcon.CHEVRON_LEFT : left,
                right == null ? RetroTouchIcon.CHEVRON_RIGHT : right };
        for (RetroTouchIcon icon : dpadIcons) icon.path();
        return this;
    }

    /** The D-pad's icons in the order up, down, left, right. */
    public RetroTouchIcon[] getDpadIcons() {
        return dpadIcons == null ? new RetroTouchIcon[] { RetroTouchIcon.CHEVRON_UP, RetroTouchIcon.CHEVRON_DOWN,
                RetroTouchIcon.CHEVRON_LEFT, RetroTouchIcon.CHEVRON_RIGHT } : dpadIcons.clone();
    }

    /** Colors of D-pads that have no colors of their own; null uses the skin's default colors. */
    /** One D-pad icon (0 up, 1 down, 2 left, 3 right) without copying, or null for the chevron. */
    RetroTouchIcon dpadIcon(int index) {
        return dpadIcons == null ? null : dpadIcons[index];
    }

    public RetroTouchSkin setDpadColors(RetroTouchColors colors) {
        dpadColors = colors;
        return this;
    }

    public RetroTouchColors getDpadColors() { return dpadColors; }

    public RetroTouchSkin setStickGate(RetroTouchStickGate gate) {
        stickGate = gate == null ? RetroTouchStickGate.ROUND : gate;
        return this;
    }

    public RetroTouchStickGate getStickGate() { return stickGate; }

    RetroTouchSkin copy() {
        RetroTouchSkin copy = new RetroTouchSkin(id, name, baseStyle);
        copy.looks.putAll(looks);
        copy.defaultColors = defaultColors;
        copy.moveStickLook = moveStickLook;
        copy.dpadStyle = dpadStyle;
        copy.dpadIcons = dpadIcons == null ? null : dpadIcons.clone();
        copy.dpadColors = dpadColors;
        copy.stickGate = stickGate;
        return copy;
    }
}
