package com.ast.retrotouch;

/** How a skin draws a D-pad (1.0.0-beta.13). Input is the same for both looks. */
public enum RetroTouchDpadStyle {
    /** One cross with an icon in each arm, as in the ICONS style. The default. */
    CROSS,
    /** Four separate round buttons, one per direction, as on a PlayStation controller. */
    FOUR_BUTTONS
}
