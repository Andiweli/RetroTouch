package com.ast.retrotouch;

import android.graphics.Path;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * An immutable stroke icon made of SVG path data (1.0.0-beta.10). RetroTouch draws it with a round
 * stroke of 2/24 of the icon box and no fill, centered in the button, in the button's text color.
 *
 * <p>The built-in icons use a 24 x 24 view box. Except for KNIFE_HORIZONTAL, CARTRIDGE_HORIZONTAL,
 * the SYMBOL_ and the ARROW_ icons, which are RetroTouch's own drawings, they come from Lucide (ISC
 * license, see THIRD_PARTY_NOTICES.md).
 *
 * <p>Since 1.0.0-beta.13 an icon can be filled ({@link #asFilled}): its shapes are filled and
 * outlined in the icon color instead of only outlined. The ARROW_ icons are filled.
 */
public final class RetroTouchIcon {
    public static final RetroTouchIcon HAND = builtIn(1.0f,
            "M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2",
            "M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2",
            "M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8",
            "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15");
    public static final RetroTouchIcon FOOTPRINTS = builtIn(1.0f,
            "M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z",
            "M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z",
            "M16 17h4",
            "M4 13h4");
    public static final RetroTouchIcon USER = builtIn(1.0f,
            "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
            "M8 7a4 4 0 1 0 8 0a4 4 0 1 0-8 0Z");
    public static final RetroTouchIcon BRIEFCASE = builtIn(1.0f,
            "M4 7h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z",
            "M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2",
            "M2 13h20");
    public static final RetroTouchIcon MAP = builtIn(1.0f,
            "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894"
                    + "l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381"
                    + "V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
            "M15 5.764v15",
            "M9 3.236v15");
    /** RetroTouch's own drawing (MIT), drawn 1.2 times larger. */
    public static final RetroTouchIcon KNIFE_HORIZONTAL = builtIn(1.2f,
            "M3 10h5v4H3a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1Z",
            "M9 7.5v9",
            "M9 9h13c-1 3.5-3.5 6-7 6H9Z");
    public static final RetroTouchIcon CROSSHAIR = builtIn(1.0f,
            "M2 12a10 10 0 1 0 20 0a10 10 0 1 0-20 0Z",
            "M22 12h-4",
            "M6 12H2",
            "M12 6V2",
            "M12 22v-4");
    /** RetroTouch's own drawing (MIT), drawn 1.2 times larger. */
    public static final RetroTouchIcon CARTRIDGE_HORIZONTAL = builtIn(1.2f,
            "M4 8.5h9v7H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1Z",
            "M6 8.5v7",
            "M13 8.5h2.5c2.5 0 4.7 1.5 6.5 3.5-1.8 2-4 3.5-6.5 3.5H13");
    public static final RetroTouchIcon CIRCLE_PAUSE = builtIn(1.0f,
            "M2 12a10 10 0 1 0 20 0a10 10 0 1 0-20 0Z",
            "M10 15V9",
            "M14 15V9");
    public static final RetroTouchIcon MENU = builtIn(1.0f,
            "M4 6h16",
            "M4 12h16",
            "M4 18h16");
    public static final RetroTouchIcon CHEVRON_UP = builtIn(1.0f, "m18 15-6-6-6 6");
    public static final RetroTouchIcon CHEVRON_DOWN = builtIn(1.0f, "m6 9 6 6 6-6");
    public static final RetroTouchIcon CHEVRON_LEFT = builtIn(1.0f, "m15 18-6-6 6-6");
    public static final RetroTouchIcon CHEVRON_RIGHT = builtIn(1.0f, "m9 18 6-6-6-6");
    /** RetroTouch's own drawing (MIT, 1.0.0-beta.13): a cross, as on a PlayStation-style button. */
    public static final RetroTouchIcon SYMBOL_CROSS = builtIn(1.0f, "M6 6L18 18", "M18 6L6 18");
    /** RetroTouch's own drawing (MIT, 1.0.0-beta.13): a circle. */
    public static final RetroTouchIcon SYMBOL_CIRCLE = builtIn(1.0f, "M5 12a7 7 0 1 0 14 0a7 7 0 1 0-14 0Z");
    /** RetroTouch's own drawing (MIT, 1.0.0-beta.13): a square. */
    public static final RetroTouchIcon SYMBOL_SQUARE = builtIn(1.0f, "M5.5 5.5H18.5V18.5H5.5Z");
    /** RetroTouch's own drawing (MIT, 1.0.0-beta.13): a triangle pointing up. */
    public static final RetroTouchIcon SYMBOL_TRIANGLE = builtIn(1.0f, "M12 5L20.08 19H3.92Z");
    /** RetroTouch's own drawing (MIT, 1.0.0-beta.13): a filled arrow, for example for a D-pad. */
    public static final RetroTouchIcon ARROW_UP = builtIn(1.0f, "M12 6L19 18H5Z").asFilled();
    public static final RetroTouchIcon ARROW_DOWN = builtIn(1.0f, "M12 18L5 6H19Z").asFilled();
    public static final RetroTouchIcon ARROW_LEFT = builtIn(1.0f, "M6 12L18 5V19Z").asFilled();
    public static final RetroTouchIcon ARROW_RIGHT = builtIn(1.0f, "M18 12L6 19V5Z").asFilled();

    private final float viewBoxSize;
    private final float extraScale;
    private final boolean filled;
    private final List<RetroTouchSvgPath> paths;
    private final Path[] builtPath; // shared by scaled and filled copies, built on first use
    private final RectF[] bounds;   // the path's bounds in view-box coordinates, built with the path

    private RetroTouchIcon(float viewBoxSize, float extraScale, boolean filled, List<RetroTouchSvgPath> paths,
                           Path[] builtPath, RectF[] bounds) {
        this.viewBoxSize = viewBoxSize;
        this.extraScale = extraScale;
        this.filled = filled;
        this.paths = paths;
        this.builtPath = builtPath;
        this.bounds = bounds;
    }

    /**
     * Creates an icon from SVG path data, for example the {@code d} attributes of an SVG file.
     * The view box is square, {@code viewBoxSize} wide, starting at 0, 0; the data is parsed now.
     */
    public static RetroTouchIcon fromPaths(float viewBoxSize, String... svgPathData) {
        if (!(viewBoxSize > 0.0f)) throw new IllegalArgumentException("View box size must be positive");
        if (svgPathData == null || svgPathData.length == 0) throw new IllegalArgumentException("Path data must not be empty");
        List<RetroTouchSvgPath> parsed = new ArrayList<RetroTouchSvgPath>(svgPathData.length);
        for (String data : svgPathData) parsed.add(RetroTouchSvgPath.parse(data));
        return new RetroTouchIcon(viewBoxSize, 1.0f, false, Collections.unmodifiableList(parsed), new Path[1], new RectF[1]);
    }

    private static RetroTouchIcon builtIn(float extraScale, String... svgPathData) {
        return fromPaths(24.0f, svgPathData).withScale(extraScale);
    }

    /** Returns a copy drawn {@code extraScale} times larger (multiplies an existing extra scale). */
    public RetroTouchIcon withScale(float extraScale) {
        if (!(extraScale > 0.0f)) throw new IllegalArgumentException("Scale must be positive");
        return new RetroTouchIcon(viewBoxSize, this.extraScale * extraScale, filled, paths, builtPath, bounds);
    }

    /**
     * Returns a filled copy (1.0.0-beta.13): every closed shape is filled and outlined in the icon
     * color, for example a solid triangle. Open lines stay lines.
     */
    public RetroTouchIcon asFilled() {
        return filled ? this : new RetroTouchIcon(viewBoxSize, extraScale, true, paths, builtPath, bounds);
    }

    public float getViewBoxSize() { return viewBoxSize; }
    public float getExtraScale() { return extraScale; }
    public boolean isFilled() { return filled; }

    /** The drawn path's bounds in view-box coordinates; for centering an icon on its ink. */
    RectF bounds() {
        path();
        return bounds[0];
    }

    List<RetroTouchSvgPath> paths() { return paths; }

    /** The icon as one Android path in view-box coordinates; built once, never in onDraw after warm-up. */
    Path path() {
        synchronized (builtPath) {
            if (builtPath[0] == null) {
                Path path = new Path();
                for (RetroTouchSvgPath svg : paths) {
                    for (float[] c : svg.commands()) {
                        int op = (int) c[0];
                        if (op == RetroTouchSvgPath.MOVE) path.moveTo(c[1], c[2]);
                        else if (op == RetroTouchSvgPath.LINE) path.lineTo(c[1], c[2]);
                        else if (op == RetroTouchSvgPath.CUBIC) path.cubicTo(c[1], c[2], c[3], c[4], c[5], c[6]);
                        else path.close();
                    }
                }
                RectF box = new RectF();
                path.computeBounds(box, true);
                bounds[0] = box;
                builtPath[0] = path;
            }
            return builtPath[0];
        }
    }
}
