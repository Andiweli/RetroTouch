package com.ast.retrotouch;

/**
 * Optional interface of a listener (1.0.0-beta.12): a finger landed on a stick or left it, also when
 * it rests in the stick's center where onStick and onMove report 0, 0. The move stick reports an
 * empty action ID. A release by resetInput, a mode or layout change or the editor also sends
 * onStickUp. Two sticks with the same action each report. Runs on Android's UI thread.
 */
public interface RetroTouchStickTouchListener {
    void onStickDown(String actionId);
    void onStickUp(String actionId);
}
