package com.ast.retrotouch;

import java.util.Locale;

/**
 * Optional host-defined colors for buttons, D-pads and move sticks.
 *
 * <p>Colors are packed RGB integers such as {@code Color.rgb(0, 160, 80)} or {@code 0x00A050}.
 * Their alpha channel is ignored: transparency always follows the control's opacity, which the
 * player can still change with {@code ALPHA} in the editor.
 *
 * <p>On a move stick, the fill color is the knob, the pressed color is the knob while it is held,
 * the border color is the ring and RetroTouch darkens the fill color for the stick's base.
 */
public final class RetroTouchColors {
    private static final int WHITE = 0xffffffff;
    private static final int BLACK = 0xff000000;
    private static final int DARK_TEXT = 0xff141414;
    private static final float LIGHT_LUMINANCE = 0.55f;

    private final int fillColor;
    private final int pressedColor;
    private final int borderColor;
    private final int textColor;

    /** Uses all four colors exactly as given. */
    public RetroTouchColors(int fillColor, int pressedColor, int borderColor, int textColor) {
        this.fillColor = opaque(fillColor);
        this.pressedColor = opaque(pressedColor);
        this.borderColor = opaque(borderColor);
        this.textColor = opaque(textColor);
    }

    /**
     * Derives every other color from one fill color: a lighter pressed color (darker for very
     * light fills), a light border and white or dark text, whichever stays readable.
     */
    public static RetroTouchColors of(int fillColor) {
        boolean light = luminance(fillColor) > LIGHT_LUMINANCE;
        int pressed = light ? mix(fillColor, BLACK, 0.25f) : mix(fillColor, WHITE, 0.55f);
        return of(fillColor, pressed, light ? DARK_TEXT : WHITE);
    }

    /** Uses the given fill, pressed and text colors and derives a matching light border. */
    public static RetroTouchColors of(int fillColor, int pressedColor, int textColor) {
        return new RetroTouchColors(fillColor, pressedColor, mix(fillColor, WHITE, 0.75f), textColor);
    }

    /** Returns a copy with another border (ring) color; the other colors stay as they are. */
    public RetroTouchColors withBorderColor(int borderColor) {
        return new RetroTouchColors(fillColor, pressedColor, borderColor, textColor);
    }

    public int getFillColor() { return fillColor; }
    public int getPressedColor() { return pressedColor; }
    public int getBorderColor() { return borderColor; }
    public int getTextColor() { return textColor; }

    /** Dark tint of the fill color, drawn behind a move stick's knob. */
    int baseColor() {
        return mix(fillColor, BLACK, 0.70f);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof RetroTouchColors)) return false;
        RetroTouchColors colors = (RetroTouchColors) other;
        return fillColor == colors.fillColor && pressedColor == colors.pressedColor &&
                borderColor == colors.borderColor && textColor == colors.textColor;
    }

    @Override
    public int hashCode() {
        return ((fillColor * 31 + pressedColor) * 31 + borderColor) * 31 + textColor;
    }

    @Override
    public String toString() {
        return String.format(Locale.US, "RetroTouchColors{fill=#%06X, pressed=#%06X, border=#%06X, text=#%06X}",
                fillColor & 0xffffff, pressedColor & 0xffffff, borderColor & 0xffffff, textColor & 0xffffff);
    }

    private static int opaque(int color) {
        return color | BLACK;
    }

    private static int mix(int color, int target, float amount) {
        int red = mixChannel(color >> 16, target >> 16, amount);
        int green = mixChannel(color >> 8, target >> 8, amount);
        int blue = mixChannel(color, target, amount);
        return BLACK | (red << 16) | (green << 8) | blue;
    }

    private static int mixChannel(int from, int to, float amount) {
        from &= 0xff;
        to &= 0xff;
        return Math.round(from + (to - from) * amount);
    }

    /** Relative sRGB luminance from 0 (black) to 1 (white). */
    private static float luminance(int color) {
        return 0.2126f * linear(color >> 16) + 0.7152f * linear(color >> 8) + 0.0722f * linear(color);
    }

    private static float linear(int channel) {
        float value = (channel & 0xff) / 255.0f;
        return value <= 0.03928f ? value / 12.92f : (float) Math.pow((value + 0.055f) / 1.055f, 2.4f);
    }
}
