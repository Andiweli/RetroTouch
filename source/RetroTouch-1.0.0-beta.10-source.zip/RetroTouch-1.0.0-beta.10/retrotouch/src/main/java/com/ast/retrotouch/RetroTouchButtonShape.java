package com.ast.retrotouch;

/** Shape of an action button (1.0.0-beta.8, ROUNDED_RECT and CAPSULE since 1.0.0-beta.10). */
public enum RetroTouchButtonShape {
    /**
     * Chosen from the label: START, SELECT and MENU are RECTANGLE; L, R and trigger labels
     * (ZL, ZR, L1, R1, L2, R2, LB, RB, LT, RT) are SHOULDER; every other button is ROUND.
     */
    AUTO,
    /** A circle, as in earlier versions. */
    ROUND,
    /** A compact rectangle, as for START, SELECT or MENU. */
    RECTANGLE,
    /** A rectangle slightly larger than RECTANGLE, as for L, R or triggers. */
    SHOULDER,
    /**
     * A rectangle with clearly rounded corners (35 % of its height). The button's size is its
     * height; the width follows the control's aspect ratio.
     */
    ROUNDED_RECT,
    /** A pill whose ends are half circles. The size is its height; the width follows the aspect ratio. */
    CAPSULE
}
