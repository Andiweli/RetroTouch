package com.ast.retrotouch;

/** An action exposed by a host game to RetroTouch. */
public final class RetroTouchAction {
    private final String id;
    private final String label;
    private final RetroTouchColors colors;
    private final RetroTouchIcon icon;

    public RetroTouchAction(String id, String label) {
        this(id, label, null);
    }

    /**
     * Creates an action whose buttons use these colors unless a button defines its own.
     * Pass null to keep the view-wide default colors.
     */
    public RetroTouchAction(String id, String label, RetroTouchColors colors) {
        this(id, label, colors, null);
    }

    /**
     * Creates an action with an icon (1.0.0-beta.10) that its buttons show in the ICONS style.
     * Pass null for no icon: the buttons then keep their text label in both styles.
     */
    public RetroTouchAction(String id, String label, RetroTouchColors colors, RetroTouchIcon icon) {
        if (!isValidId(id)) {
            throw new IllegalArgumentException("Action IDs must use lowercase letters, digits or underscores");
        }
        if (label == null || label.trim().length() == 0) {
            throw new IllegalArgumentException("Action label must not be empty");
        }
        this.id = id;
        this.label = label.trim();
        this.colors = colors;
        this.icon = icon;
    }

    public String getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    /** Returns this action's button colors, or null when the action has none. */
    public RetroTouchColors getColors() {
        return colors;
    }

    /** Returns this action's icon, or null when it has none. */
    public RetroTouchIcon getIcon() {
        return icon;
    }

    static boolean isValidId(String value) {
        if (value == null || value.length() == 0) return false;
        for (int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_')) return false;
        }
        return true;
    }
}
