package com.ast.retrotouch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Parses SVG path data into absolute MOVE, LINE, CUBIC and CLOSE commands (1.0.0-beta.10).
 * Pure Java without Android classes, so it can be unit tested. Quadratic curves become cubics
 * and elliptical arcs become one cubic per quarter turn.
 *
 * <p>Supported: M m L l H h V v C c S s Q q T t A a Z z, implicit command repetition, compact
 * numbers such as {@code -.86} or {@code 5.99-2.34}, exponents and arc flags without separators.
 */
final class RetroTouchSvgPath {
    static final int MOVE = 0;
    static final int LINE = 1;
    static final int CUBIC = 2;
    static final int CLOSE = 3;

    /** Each entry is {op, coordinates...}: MOVE/LINE x y, CUBIC x1 y1 x2 y2 x y, CLOSE. */
    private final List<float[]> commands;

    private RetroTouchSvgPath(List<float[]> commands) {
        this.commands = Collections.unmodifiableList(commands);
    }

    List<float[]> commands() { return commands; }

    static RetroTouchSvgPath parse(String data) {
        if (data == null) throw new IllegalArgumentException("Path data must not be null");
        return new Parser(data).parse();
    }

    private static final class Parser {
        private final String data;
        private final List<float[]> out = new ArrayList<float[]>();
        private int index;
        private float x, y;              // current point
        private float startX, startY;    // start of the current subpath
        private float controlX, controlY; // last control point, for S and T
        private char previous;           // previous command letter, upper case

        Parser(String data) { this.data = data; }

        RetroTouchSvgPath parse() {
            char command = 0;
            while (true) {
                skipSeparators();
                if (index >= data.length()) break;
                char c = data.charAt(index);
                if (isCommandLetter(c)) {
                    command = c;
                    ++index;
                } else if (command == 0) {
                    throw error("Path data must start with a command");
                } else if (command == 'M') {
                    command = 'L'; // implicit lineto after a moveto pair
                } else if (command == 'm') {
                    command = 'l';
                } else if (command == 'Z' || command == 'z') {
                    throw error("Unexpected number after Z");
                }
                execute(command);
            }
            if (out.isEmpty()) throw error("Path data is empty");
            return new RetroTouchSvgPath(new ArrayList<float[]>(out));
        }

        private void execute(char command) {
            boolean relative = Character.isLowerCase(command);
            char upper = Character.toUpperCase(command);
            float ox = relative ? x : 0.0f;
            float oy = relative ? y : 0.0f;
            switch (upper) {
                case 'M': {
                    x = ox + number();
                    y = oy + number();
                    startX = x;
                    startY = y;
                    add(MOVE, x, y);
                    break;
                }
                case 'L': {
                    x = ox + number();
                    y = oy + number();
                    add(LINE, x, y);
                    break;
                }
                case 'H': {
                    x = ox + number();
                    add(LINE, x, y);
                    break;
                }
                case 'V': {
                    y = (relative ? y : 0.0f) + number();
                    add(LINE, x, y);
                    break;
                }
                case 'C': {
                    float x1 = ox + number(), y1 = oy + number();
                    float x2 = ox + number(), y2 = oy + number();
                    float ex = ox + number(), ey = oy + number();
                    cubic(x1, y1, x2, y2, ex, ey);
                    break;
                }
                case 'S': {
                    float x1 = previous == 'C' || previous == 'S' ? 2 * x - controlX : x;
                    float y1 = previous == 'C' || previous == 'S' ? 2 * y - controlY : y;
                    float x2 = ox + number(), y2 = oy + number();
                    float ex = ox + number(), ey = oy + number();
                    cubic(x1, y1, x2, y2, ex, ey);
                    break;
                }
                case 'Q': {
                    float qx = ox + number(), qy = oy + number();
                    float ex = ox + number(), ey = oy + number();
                    quadratic(qx, qy, ex, ey);
                    break;
                }
                case 'T': {
                    float qx = previous == 'Q' || previous == 'T' ? 2 * x - controlX : x;
                    float qy = previous == 'Q' || previous == 'T' ? 2 * y - controlY : y;
                    float ex = ox + number(), ey = oy + number();
                    quadratic(qx, qy, ex, ey);
                    break;
                }
                case 'A': {
                    float rx = Math.abs(number()), ry = Math.abs(number());
                    float rotation = number();
                    boolean large = flag();
                    boolean sweep = flag();
                    float ex = ox + number(), ey = oy + number();
                    arc(rx, ry, rotation, large, sweep, ex, ey);
                    break;
                }
                case 'Z': {
                    out.add(new float[] { CLOSE });
                    x = startX;
                    y = startY;
                    break;
                }
                default:
                    throw error("Unsupported command " + command);
            }
            previous = upper;
        }

        private void add(int op, float px, float py) {
            out.add(new float[] { op, px, py });
        }

        private void cubic(float x1, float y1, float x2, float y2, float ex, float ey) {
            out.add(new float[] { CUBIC, x1, y1, x2, y2, ex, ey });
            controlX = x2;
            controlY = y2;
            x = ex;
            y = ey;
        }

        private void quadratic(float qx, float qy, float ex, float ey) {
            out.add(new float[] { CUBIC,
                    x + 2.0f / 3.0f * (qx - x), y + 2.0f / 3.0f * (qy - y),
                    ex + 2.0f / 3.0f * (qx - ex), ey + 2.0f / 3.0f * (qy - ey), ex, ey });
            controlX = qx;
            controlY = qy;
            x = ex;
            y = ey;
        }

        /** Endpoint-to-center conversion (SVG 1.1 appendix F.6.5), then one cubic per quarter turn at most. */
        private void arc(float rx, float ry, float rotationDegrees, boolean large, boolean sweep, float ex, float ey) {
            float x0 = x, y0 = y;
            x = ex;
            y = ey;
            if (x0 == ex && y0 == ey) return;
            if (rx == 0.0f || ry == 0.0f) {
                add(LINE, ex, ey);
                return;
            }
            double phi = Math.toRadians(rotationDegrees);
            double cos = Math.cos(phi), sin = Math.sin(phi);
            double dx = (x0 - ex) / 2.0, dy = (y0 - ey) / 2.0;
            double x1p = cos * dx + sin * dy;
            double y1p = -sin * dx + cos * dy;
            double rxs = rx, rys = ry;
            double lambda = (x1p * x1p) / (rxs * rxs) + (y1p * y1p) / (rys * rys);
            if (lambda > 1.0) {
                double scale = Math.sqrt(lambda);
                rxs *= scale;
                rys *= scale;
            }
            double numerator = rxs * rxs * rys * rys - rxs * rxs * y1p * y1p - rys * rys * x1p * x1p;
            double denominator = rxs * rxs * y1p * y1p + rys * rys * x1p * x1p;
            double coefficient = denominator == 0.0 ? 0.0 : Math.sqrt(Math.max(0.0, numerator / denominator));
            if (large == sweep) coefficient = -coefficient;
            double cxp = coefficient * rxs * y1p / rys;
            double cyp = -coefficient * rys * x1p / rxs;
            double cx = cos * cxp - sin * cyp + (x0 + ex) / 2.0;
            double cy = sin * cxp + cos * cyp + (y0 + ey) / 2.0;
            double theta1 = angle(1.0, 0.0, (x1p - cxp) / rxs, (y1p - cyp) / rys);
            double delta = angle((x1p - cxp) / rxs, (y1p - cyp) / rys, (-x1p - cxp) / rxs, (-y1p - cyp) / rys);
            if (!sweep && delta > 0) delta -= 2.0 * Math.PI;
            else if (sweep && delta < 0) delta += 2.0 * Math.PI;

            int segments = Math.max(1, (int) Math.ceil(Math.abs(delta) / (Math.PI / 2.0) - 1e-9));
            double step = delta / segments;
            double t = 4.0 / 3.0 * Math.tan(step / 4.0);
            double theta = theta1;
            for (int i = 0; i < segments; ++i) {
                double c1 = Math.cos(theta), s1 = Math.sin(theta);
                double c2 = Math.cos(theta + step), s2 = Math.sin(theta + step);
                double p1x = c1 - t * s1, p1y = s1 + t * c1;
                double p2x = c2 + t * s2, p2y = s2 - t * c2;
                boolean last = i == segments - 1;
                out.add(new float[] { CUBIC,
                        (float) (cx + rxs * (cos * p1x) - rys * (sin * p1y)),
                        (float) (cy + rxs * (sin * p1x) + rys * (cos * p1y)),
                        (float) (cx + rxs * (cos * p2x) - rys * (sin * p2y)),
                        (float) (cy + rxs * (sin * p2x) + rys * (cos * p2y)),
                        last ? ex : (float) (cx + rxs * cos * c2 - rys * sin * s2),
                        last ? ey : (float) (cy + rxs * sin * c2 + rys * cos * s2) });
                theta += step;
            }
        }

        private double angle(double ux, double uy, double vx, double vy) {
            double dot = ux * vx + uy * vy;
            double length = Math.sqrt(ux * ux + uy * uy) * Math.sqrt(vx * vx + vy * vy);
            double value = Math.acos(Math.max(-1.0, Math.min(1.0, dot / length)));
            return ux * vy - uy * vx < 0 ? -value : value;
        }

        private float number() {
            skipSeparators();
            int start = index;
            if (index < data.length() && (data.charAt(index) == '+' || data.charAt(index) == '-')) ++index;
            boolean digits = false;
            while (index < data.length() && Character.isDigit(data.charAt(index))) { ++index; digits = true; }
            if (index < data.length() && data.charAt(index) == '.') {
                ++index;
                while (index < data.length() && Character.isDigit(data.charAt(index))) { ++index; digits = true; }
            }
            if (!digits) throw error("Number expected");
            if (index < data.length() && (data.charAt(index) == 'e' || data.charAt(index) == 'E')) {
                int mark = index++;
                if (index < data.length() && (data.charAt(index) == '+' || data.charAt(index) == '-')) ++index;
                int exponentStart = index;
                while (index < data.length() && Character.isDigit(data.charAt(index))) ++index;
                if (index == exponentStart) index = mark; // an 'e' without digits is not part of the number
            }
            return Float.parseFloat(data.substring(start, index));
        }

        private boolean flag() {
            skipSeparators();
            if (index >= data.length()) throw error("Arc flag expected");
            char c = data.charAt(index++);
            if (c == '0') return false;
            if (c == '1') return true;
            throw error("Arc flag must be 0 or 1");
        }

        private void skipSeparators() {
            while (index < data.length()) {
                char c = data.charAt(index);
                if (c == ',' || Character.isWhitespace(c)) ++index;
                else break;
            }
        }

        private boolean isCommandLetter(char c) {
            return "MmLlHhVvCcSsQqTtAaZz".indexOf(c) >= 0;
        }

        private IllegalArgumentException error(String message) {
            return new IllegalArgumentException(message + " at index " + index + " in \"" + data + "\"");
        }
    }
}
