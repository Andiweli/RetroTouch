package com.ast.retrotouch;

/**
 * Optional callback (1.0.0-beta.10) when the player switches the button style with the editor's
 * style toggle. Register it with RetroTouchView.setStyleListener, or let the main listener
 * implement it as well. Runs on Android's UI thread.
 */
public interface RetroTouchStyleListener {
    void onButtonStyleChanged(RetroTouchButtonStyle style);
}
