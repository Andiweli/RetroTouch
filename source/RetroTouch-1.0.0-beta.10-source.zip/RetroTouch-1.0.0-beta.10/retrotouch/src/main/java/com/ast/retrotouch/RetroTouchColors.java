package com.ast.retrotouch;

import java.util.Locale;

/**
 * Optional host-defined colors for buttons, D-pads and move sticks.
 *
 * <p>Colors are packed RGB integers such as {@code Color.rgb(0, 160, 80)} or {@code 0x00A050}.
 * Their alpha channel is ignored: transparency always follows the control's opacity, which the
 * player can still change with {@code ALPHA} in the editor.
 *
 * <p>On a move stick, the fill color is the knob, the pressed color is the knob while it is held,
 * the border color is the ring and RetroTouch darkens the fill color for the stick's base.
 *
 * <p>Since 1.0.0-beta.10 the ICONS button style also uses a pressed border and text color, the
 * colors of a latched button and a border width. Unless set with {@link #withPressedColors},
 * {@link #withLatchedColors} or {@link #withBorderWidth} they are derived; the LABELS style
 * ignores them.
 */
public final class RetroTouchColors {
    private static final int WHITE = 0xffffffff;
    private static final int BLACK = 0xff000000;
    private static final int DARK_TEXT = 0xff141414;
    private static final float LIGHT_LUMINANCE = 0.55f;
    private static final int GOLD = 0xffe8c07a;
    private static final int UNSET = 0; // never a stored color: stored colors are opaque

    private final int fillColor;
    private final int pressedColor;
    private final int borderColor;
    private final int textColor;
    private final int pressedBorderColor;
    private final int pressedTextColor;
    private final int latchedFillColor;
    private final int latchedBorderColor;
    private final int latchedTextColor;
    private final float borderWidth;

    /** Uses all four colors exactly as given. */
    public RetroTouchColors(int fillColor, int pressedColor, int borderColor, int textColor) {
        this(opaque(fillColor), opaque(pressedColor), opaque(borderColor), opaque(textColor),
                UNSET, UNSET, UNSET, UNSET, UNSET, Float.NaN);
    }

    private RetroTouchColors(int fillColor, int pressedColor, int borderColor, int textColor,
                             int pressedBorderColor, int pressedTextColor, int latchedFillColor,
                             int latchedBorderColor, int latchedTextColor, float borderWidth) {
        this.fillColor = fillColor;
        this.pressedColor = pressedColor;
        this.borderColor = borderColor;
        this.textColor = textColor;
        this.pressedBorderColor = pressedBorderColor;
        this.pressedTextColor = pressedTextColor;
        this.latchedFillColor = latchedFillColor;
        this.latchedBorderColor = latchedBorderColor;
        this.latchedTextColor = latchedTextColor;
        this.borderWidth = borderWidth;
    }

    /**
     * Derives every other color from one fill color: a lighter pressed color (darker for very
     * light fills), a light border and white or dark text, whichever stays readable.
     */
    public static RetroTouchColors of(int fillColor) {
        boolean light = luminance(fillColor) > LIGHT_LUMINANCE;
        int pressed = light ? mix(fillColor, BLACK, 0.25f) : mix(fillColor, WHITE, 0.55f);
        return of(fillColor, pressed, light ? DARK_TEXT : WHITE);
    }

    /** Uses the given fill, pressed and text colors and derives a matching light border. */
    public static RetroTouchColors of(int fillColor, int pressedColor, int textColor) {
        return new RetroTouchColors(fillColor, pressedColor, mix(fillColor, WHITE, 0.75f), textColor);
    }

    /** Returns a copy with another border (ring) color; the other colors stay as they are. */
    public RetroTouchColors withBorderColor(int borderColor) {
        return new RetroTouchColors(fillColor, pressedColor, opaque(borderColor), textColor, pressedBorderColor,
                pressedTextColor, latchedFillColor, latchedBorderColor, latchedTextColor, borderWidth);
    }

    /**
     * Returns a copy with explicit colors for a pressed button (1.0.0-beta.10): fill, border and
     * text or icon. The LABELS style uses only the fill.
     */
    public RetroTouchColors withPressedColors(int pressedFill, int pressedBorder, int pressedText) {
        return new RetroTouchColors(fillColor, opaque(pressedFill), borderColor, textColor, opaque(pressedBorder),
                opaque(pressedText), latchedFillColor, latchedBorderColor, latchedTextColor, borderWidth);
    }

    /**
     * Returns a copy with explicit colors for a latched button in the ICONS style (1.0.0-beta.10).
     * Without them RetroTouch uses a golden border, a slightly golden fill and the pressed text color.
     */
    public RetroTouchColors withLatchedColors(int latchedFill, int latchedBorder, int latchedText) {
        return new RetroTouchColors(fillColor, pressedColor, borderColor, textColor, pressedBorderColor,
                pressedTextColor, opaque(latchedFill), opaque(latchedBorder), opaque(latchedText), borderWidth);
    }

    /**
     * Returns a copy with the ICONS style's border width as a fraction of the button's smaller side
     * (1.0.0-beta.10), from 0 to 0.25. Without it the ICONS style uses 0.07.
     */
    public RetroTouchColors withBorderWidth(float fraction) {
        if (!(fraction >= 0.0f && fraction <= 0.25f)) throw new IllegalArgumentException("Border width must be 0 to 0.25");
        return new RetroTouchColors(fillColor, pressedColor, borderColor, textColor, pressedBorderColor,
                pressedTextColor, latchedFillColor, latchedBorderColor, latchedTextColor, fraction);
    }

    public int getFillColor() { return fillColor; }
    public int getPressedColor() { return pressedColor; }
    public int getBorderColor() { return borderColor; }
    public int getTextColor() { return textColor; }

    /** Border of a pressed button in the ICONS style: as set, or the border lightened. */
    public int getPressedBorderColor() {
        return pressedBorderColor != UNSET ? pressedBorderColor : mix(borderColor, WHITE, 0.35f);
    }

    /** Text or icon of a pressed button in the ICONS style: as set, or the text color lightened. */
    public int getPressedTextColor() {
        return pressedTextColor != UNSET ? pressedTextColor : mix(textColor, WHITE, 0.5f);
    }

    /** Fill of a latched button in the ICONS style: as set, or the fill with a hint of the latched border. */
    public int getLatchedFillColor() {
        return latchedFillColor != UNSET ? latchedFillColor : mix(fillColor, getLatchedBorderColor(), 0.08f);
    }

    /** Border and outer ring of a latched button in the ICONS style: as set, or gold. */
    public int getLatchedBorderColor() {
        return latchedBorderColor != UNSET ? latchedBorderColor : GOLD;
    }

    /** Text or icon of a latched button in the ICONS style: as set, or the pressed text color. */
    public int getLatchedTextColor() {
        return latchedTextColor != UNSET ? latchedTextColor : getPressedTextColor();
    }

    /** The ICONS style's border width as a fraction of the smaller side, or NaN for the default 0.07. */
    public float getBorderWidth() { return borderWidth; }

    /** Dark tint of the fill color, drawn behind a move stick's knob. */
    int baseColor() {
        return mix(fillColor, BLACK, 0.70f);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (!(other instanceof RetroTouchColors)) return false;
        RetroTouchColors colors = (RetroTouchColors) other;
        return fillColor == colors.fillColor && pressedColor == colors.pressedColor &&
                borderColor == colors.borderColor && textColor == colors.textColor &&
                pressedBorderColor == colors.pressedBorderColor && pressedTextColor == colors.pressedTextColor &&
                latchedFillColor == colors.latchedFillColor && latchedBorderColor == colors.latchedBorderColor &&
                latchedTextColor == colors.latchedTextColor &&
                Float.floatToIntBits(borderWidth) == Float.floatToIntBits(colors.borderWidth);
    }

    @Override
    public int hashCode() {
        int hash = ((fillColor * 31 + pressedColor) * 31 + borderColor) * 31 + textColor;
        if (pressedBorderColor == UNSET && pressedTextColor == UNSET && latchedFillColor == UNSET &&
                latchedBorderColor == UNSET && latchedTextColor == UNSET && Float.isNaN(borderWidth)) return hash;
        hash = ((hash * 31 + pressedBorderColor) * 31 + pressedTextColor) * 31 + latchedFillColor;
        hash = (hash * 31 + latchedBorderColor) * 31 + latchedTextColor;
        return hash * 31 + Float.floatToIntBits(borderWidth);
    }

    @Override
    public String toString() {
        StringBuilder text = new StringBuilder(String.format(Locale.US,
                "RetroTouchColors{fill=#%06X, pressed=#%06X, border=#%06X, text=#%06X",
                fillColor & 0xffffff, pressedColor & 0xffffff, borderColor & 0xffffff, textColor & 0xffffff));
        if (pressedBorderColor != UNSET || pressedTextColor != UNSET) {
            text.append(String.format(Locale.US, ", pressedBorder=#%06X, pressedText=#%06X",
                    getPressedBorderColor() & 0xffffff, getPressedTextColor() & 0xffffff));
        }
        if (latchedFillColor != UNSET) {
            text.append(String.format(Locale.US, ", latchedFill=#%06X, latchedBorder=#%06X, latchedText=#%06X",
                    latchedFillColor & 0xffffff, latchedBorderColor & 0xffffff, latchedTextColor & 0xffffff));
        }
        if (!Float.isNaN(borderWidth)) text.append(String.format(Locale.US, ", borderWidth=%.3f", borderWidth));
        return text.append('}').toString();
    }

    private static int opaque(int color) {
        return color | BLACK;
    }

    private static int mix(int color, int target, float amount) {
        int red = mixChannel(color >> 16, target >> 16, amount);
        int green = mixChannel(color >> 8, target >> 8, amount);
        int blue = mixChannel(color, target, amount);
        return BLACK | (red << 16) | (green << 8) | blue;
    }

    private static int mixChannel(int from, int to, float amount) {
        from &= 0xff;
        to &= 0xff;
        return Math.round(from + (to - from) * amount);
    }

    /** Relative sRGB luminance from 0 (black) to 1 (white). */
    private static float luminance(int color) {
        return 0.2126f * linear(color >> 16) + 0.7152f * linear(color >> 8) + 0.0722f * linear(color);
    }

    private static float linear(int channel) {
        float value = (channel & 0xff) / 255.0f;
        return value <= 0.03928f ? value / 12.92f : (float) Math.pow((value + 0.055f) / 1.055f, 2.4f);
    }
}
