package com.ast.retrotouch;

/** How buttons are drawn (1.0.0-beta.10). */
public enum RetroTouchButtonStyle {
    /** Text labels, as in earlier versions. The default. */
    LABELS,
    /** Icons with a thicker border; actions without an icon keep their text label. */
    ICONS
}
