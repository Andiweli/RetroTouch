package com.ast.retrotouch;

import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/** Plain JUnit (no Android): the SVG path parser behind RetroTouchIcon. */
public class SvgPathTest {
    private static final int M = RetroTouchSvgPath.MOVE, L = RetroTouchSvgPath.LINE,
            C = RetroTouchSvgPath.CUBIC, Z = RetroTouchSvgPath.CLOSE;

    static Map<String, RetroTouchIcon> icons() {
        Map<String, RetroTouchIcon> icons = new LinkedHashMap<String, RetroTouchIcon>();
        icons.put("HAND", RetroTouchIcon.HAND);
        icons.put("FOOTPRINTS", RetroTouchIcon.FOOTPRINTS);
        icons.put("USER", RetroTouchIcon.USER);
        icons.put("BRIEFCASE", RetroTouchIcon.BRIEFCASE);
        icons.put("MAP", RetroTouchIcon.MAP);
        icons.put("KNIFE_HORIZONTAL", RetroTouchIcon.KNIFE_HORIZONTAL);
        icons.put("CROSSHAIR", RetroTouchIcon.CROSSHAIR);
        icons.put("CARTRIDGE_HORIZONTAL", RetroTouchIcon.CARTRIDGE_HORIZONTAL);
        icons.put("CIRCLE_PAUSE", RetroTouchIcon.CIRCLE_PAUSE);
        icons.put("MENU", RetroTouchIcon.MENU);
        icons.put("CHEVRON_UP", RetroTouchIcon.CHEVRON_UP);
        icons.put("CHEVRON_DOWN", RetroTouchIcon.CHEVRON_DOWN);
        icons.put("CHEVRON_LEFT", RetroTouchIcon.CHEVRON_LEFT);
        icons.put("CHEVRON_RIGHT", RetroTouchIcon.CHEVRON_RIGHT);
        return icons;
    }

    private static int[] ops(String data) {
        List<float[]> commands = RetroTouchSvgPath.parse(data).commands();
        int[] ops = new int[commands.size()];
        for (int i = 0; i < ops.length; ++i) ops[i] = (int) commands.get(i)[0];
        return ops;
    }

    private static float[] last(String data) {
        List<float[]> commands = RetroTouchSvgPath.parse(data).commands();
        float[] c = commands.get(commands.size() - 1);
        return new float[] { c[c.length - 2], c[c.length - 1] };
    }

    @Test
    public void allFourteenIconsParseInsideTheViewBox() {
        assertEquals(14, icons().size());
        for (Map.Entry<String, RetroTouchIcon> entry : icons().entrySet()) {
            RetroTouchIcon icon = entry.getValue();
            assertEquals(24.0f, icon.getViewBoxSize(), 0.0f);
            int points = 0;
            for (RetroTouchSvgPath path : icon.paths()) {
                for (float[] c : path.commands()) {
                    for (int i = 1; i < c.length; ++i) {
                        assertTrue(entry.getKey() + " coordinate " + c[i], c[i] >= -0.6f && c[i] <= 24.6f);
                        ++points;
                    }
                }
            }
            assertTrue(entry.getKey(), points > 0);
        }
        assertEquals(1.2f, RetroTouchIcon.KNIFE_HORIZONTAL.getExtraScale(), 0.0f);
        assertEquals(1.2f, RetroTouchIcon.CARTRIDGE_HORIZONTAL.getExtraScale(), 0.0f);
        assertEquals(1.0f, RetroTouchIcon.HAND.getExtraScale(), 0.0f);
    }

    @Test
    public void knownPathsGiveTheExpectedCommands() {
        assertArrayEquals(new int[] { M, L }, ops("M4 6h16"));
        assertArrayEquals(new int[] { M, L }, ops("M9 3.236v15"));
        // implicit lineto after a relative moveto
        assertArrayEquals(new int[] { M, L, L }, ops("m18 15-6-6-6 6"));
        // two half circles are two cubics each
        assertArrayEquals(new int[] { M, C, C, C, C, Z }, ops("M2 12a10 10 0 1 0 20 0a10 10 0 1 0-20 0Z"));
        // briefcase body: 4 lines, 4 quarter-circle corners, close
        assertArrayEquals(new int[] { M, L, C, L, C, L, C, L, C, Z },
                ops("M4 7h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z"));
        assertEquals(3, RetroTouchIcon.MENU.paths().size());
        assertEquals(4, RetroTouchIcon.HAND.paths().size());
    }

    @Test
    public void relativeCommandsAndCompactNumbers() {
        assertArrayEquals(new float[] { 4, 20 }, last("M4 6h16v14H4"), 1e-5f);   // ends at 4,20
        assertArrayEquals(new float[] { 20, 6 }, last("M4 6h16"), 1e-5f);
        // "5.99-2.34" and "-.86" without separators
        assertArrayEquals(new float[] { 10.0f, 1.0f }, last("M10 4c-2.8 0-4.5-.86-5.99-2.34l5.99-.66"), 1e-4f); // 10 - 5.99 + 5.99
        assertArrayEquals(new float[] { 0.5f, 0.5f }, last("M0 0L.25.25.5.5"), 1e-6f);
        assertArrayEquals(new float[] { 10, 0 }, last("M0 0L1e1 0"), 1e-6f);
    }

    @Test
    public void arcFlagsWithoutSeparators() {
        // rx ry rotation large-arc sweep x y written as "0 105 5" (flags 1 and 0 run together)
        float[] compact = last("M0 0a5 5 0 105 5");
        float[] spaced = last("M0 0a5 5 0 1 0 5 5");
        assertArrayEquals(spaced, compact, 1e-6f);
        assertArrayEquals(new float[] { 5, 5 }, compact, 1e-5f);
    }

    @Test
    public void arcsFollowTheCircle() {
        RetroTouchSvgPath circle = RetroTouchSvgPath.parse("M2 12a10 10 0 1 0 20 0a10 10 0 1 0-20 0Z");
        for (float[] c : circle.commands()) {
            if ((int) c[0] != C) continue;
            float ex = c[5] - 12, ey = c[6] - 12;
            assertEquals("cubic end on the circle", 10.0, Math.sqrt(ex * ex + ey * ey), 1e-3);
            // midpoint of the cubic, t = 0.5, is on the circle within the usual approximation error
            float[] start = previousEnd(circle.commands(), c);
            double mx = 0.125 * start[0] + 0.375 * c[1] + 0.375 * c[3] + 0.125 * c[5] - 12;
            double my = 0.125 * start[1] + 0.375 * c[2] + 0.375 * c[4] + 0.125 * c[6] - 12;
            assertEquals("cubic midpoint on the circle", 10.0, Math.sqrt(mx * mx + my * my), 0.01);
        }
    }

    private static float[] previousEnd(List<float[]> commands, float[] current) {
        float[] previous = null;
        for (float[] c : commands) {
            if (c == current) break;
            previous = c;
        }
        return new float[] { previous[previous.length - 2], previous[previous.length - 1] };
    }

    @Test
    public void smoothAndQuadraticCurves() {
        assertArrayEquals(new int[] { M, C, C }, ops("M0 0C0 5 5 5 5 0S10-5 10 0"));
        float[] s = RetroTouchSvgPath.parse("M0 0C0 5 5 5 5 0S10-5 10 0").commands().get(2);
        assertArrayEquals("S reflects the previous control point", new float[] { 5, -5 }, new float[] { s[1], s[2] }, 1e-6f);
        assertArrayEquals(new int[] { M, C, C }, ops("M0 0Q5 10 10 0T20 0"));
        float[] q = RetroTouchSvgPath.parse("M0 0Q6 0 6 6").commands().get(1);
        assertArrayEquals(new float[] { C, 4, 0, 6, 2, 6, 6 }, q, 1e-5f);
        assertArrayEquals(new float[] { 20, 0 }, last("M0 0Q5 10 10 0T20 0"), 1e-5f);
    }

    @Test
    public void closeReturnsToTheSubpathStart() {
        assertArrayEquals(new float[] { 4, 4 }, last("M1 1z m2 3 l1 0"), 1e-6f); // after z at 1,1: m to 3,4, l to 4,4
        float[] after = RetroTouchSvgPath.parse("M1 1h5z m2 3").commands().get(3);
        assertArrayEquals(new float[] { M, 3, 4 }, after, 1e-6f);
    }

    @Test
    public void invalidDataIsRejected() {
        for (String bad : Arrays.asList("", "6 6", "M0", "M0 0 X1 1", "M0 0a5 5 0 2 0 5 5", "M0 0z 5 5")) {
            try {
                RetroTouchSvgPath.parse(bad);
                fail("accepted: " + bad);
            } catch (IllegalArgumentException expected) {
                // expected
            }
        }
        try {
            RetroTouchIcon.fromPaths(0, "M0 0h1");
            fail("accepted view box 0");
        } catch (IllegalArgumentException expected) {
            // expected
        }
    }

    @Test
    public void scaledCopiesShareTheParsedPaths() {
        RetroTouchIcon icon = RetroTouchIcon.fromPaths(48, "M0 0h48");
        RetroTouchIcon bigger = icon.withScale(1.5f).withScale(2.0f);
        assertEquals(3.0f, bigger.getExtraScale(), 1e-6f);
        assertEquals(48.0f, bigger.getViewBoxSize(), 0.0f);
        assertTrue(icon.paths() == bigger.paths());
    }
}
