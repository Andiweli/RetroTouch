# Updating RetroTouch in a game

## Recommended boundary

Keep these pieces separate:

1. `app/libs/retrotouch.aar` - reusable RetroTouch implementation
2. a game-owned bridge - action registration, callbacks and mode selection
3. game-owned default layouts - control IDs, action IDs and normalized positions

Do not copy RetroTouch Java sources into the app module for a release integration. A compatible
update then consists of replacing the AAR and rebuilding the game.

## Compatibility policy

- Starting with `1.0.0-beta.1`, existing public classes and methods remain source-compatible across
  compatible beta and stable updates unless the changelog explicitly marks a migration.
- New capabilities are opt-in. A game using only `setDefaultLayout()` continues to receive a
  gameplay-only overlay.
- Stable string action IDs and layout game IDs must not be renamed by a library update.
- Saved layout format 1 remains readable; RetroTouch 1.0 beta writes format 2.
- Removed APIs require a future major-version migration note rather than a silent deletion.

## Runtime distribution

Android packages the AAR into the APK/AAB. End users still receive a rebuilt game package; an AAR
cannot safely replace code inside an already installed game. RetroTouch intentionally avoids a
separate draw-over-other-apps service and its associated permissions and input-injection limits.

## Host input resets

Starting with `1.0.0-beta.3`, call `resetInputState()` whenever the host engine discards its key or
axis state. This includes respawn, checkpoint restart, level loading and focus loss. The call keeps
the active RetroTouch mode and layouts but prevents stale pointers or held actions from surviving
the engine reset. The host remains responsible for clearing its own toggle variables.

## Beta.4 editor-state migration

`1.0.0-beta.4` keeps the public Java API and saved control-layout format unchanged. It stores the
movable settings button and editor toolbar in an additional private preference entry keyed by the
same game/layout ID. Existing Breathless and Unreal integrations therefore only need the new AAR
and a rebuild. Older user layouts load normally; editor-position defaults are added on the next
save.

## Beta.5 optional colors

`1.0.0-beta.5` adds `RetroTouchColors` and new overloads that accept colors. Every beta.4 class and
method remains, and a game that sets no colors draws exactly as before, so the AAR can be replaced
without touching game code.

Colors are never written to saved layouts; the saved control-layout format stays at format 2.
RetroTouch re-applies the colors supplied by the game on every load, so existing user layouts get
the game's colors immediately, and layouts saved by beta.5 remain readable by beta.4.

## Beta.6 one-character labels

`1.0.0-beta.6` changes drawing only: button labels with exactly one character are drawn larger,
scale with the button and are centered on the glyph. The public Java API and saved layouts are
unchanged, so replacing the AAR is enough. Longer labels look exactly as in beta.5.

## Beta.7 second analog stick

`1.0.0-beta.7` adds stick actions (`registerStickAction`) and the optional
`RetroTouchStickListener`. Games that do not register stick actions behave and draw exactly as in
beta.6, so replacing the AAR is enough. Sticks created from stick actions are saved in the existing
format 2 as `move_stick` controls with an action ID; an older RetroTouch would treat them as an
ordinary move stick.

## Beta.8 rectangle buttons

`1.0.0-beta.8` draws buttons labeled `START`, `SELECT` or `MENU` and shoulder or trigger buttons
(`L`, `R`, `ZL`, `ZR`, `L1`, `R1`, `L2`, `R2`, `LB`, `RB`, `LT`, `RT`) as rectangles automatically,
and fits the editor's selection frame to the visible control. The public Java API only grows
(`RetroTouchButtonShape`, `setButtonShape`, `RetroTouchColors.withBorderColor`) and saved layouts
are unchanged, so replacing the AAR is enough.

## Beta.9 edges, borders and sticks

`1.0.0-beta.9` changes behavior and drawing only: controls can be dragged to every screen edge,
borders are 2.5 dp, and stick knobs run along the ring. The public Java API and saved layouts are
unchanged, so replacing the AAR is enough. Saved positions are kept; a control only moves closer
to an edge when the player drags it there.

## Beta.10 icon style

`1.0.0-beta.10` adds the optional ICONS button style, icons, two shapes and state colors. Every
beta.9 class and method remains and nothing changes unless a game calls the new API, so replacing
the AAR is enough. The player's style choice is saved under its own key per game; saved layouts
keep format 2 and contain no icons, shapes or colors.
