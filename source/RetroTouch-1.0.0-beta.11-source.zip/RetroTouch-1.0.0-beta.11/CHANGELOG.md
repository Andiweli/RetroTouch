# Changelog

## 1.0.0-beta.11 - 2026-11-14

- New `RetroTouchView.setSafeInsets(left, top, right, bottom)` in pixels, for example for a camera
  cutout. The editor bar, its `↕ DRAG` line, their touch areas and the default position of the
  settings button stay inside the view minus these insets. The bar can only be dragged within
  this area. Controls, sticks and their saved positions keep the whole view.
- Can be called again at any time, for example after a 180° rotation; the view lays out and
  redraws. Negative values count as 0; insets that would leave less than half of the view's width
  or height are ignored on that axis.
- Default: all insets 0. An app that never calls the method draws pixel-identically to beta.10.
  All beta.10 classes and methods remain and the saved-layout format is unchanged (format 2),
  allowing an AAR-only update.

## 1.0.0-beta.10 - 2026-11-09

- Optional ICONS button style next to the LABELS style: stroke icons in the button's text color,
  a border of 7 % of the smaller side, and for latched buttons a golden border with an outer ring.
  New `RetroTouchButtonStyle`, `setAvailableButtonStyles`, `setDefaultButtonStyle`,
  `getButtonStyle`, `setButtonStyle`, `setStyleToggleLabels`, `setStyleListener` and
  `RetroTouchStyleListener`.
- With two or more styles offered, the editor shows a style toggle. The player's choice is saved
  per game, separate from the layouts; `RESET` keeps it.
- New `RetroTouchIcon` with 14 built-in icons (Lucide, ISC, plus two own drawings) and
  `fromPaths` for own SVG path data, parsed by a small built-in SVG path parser.
- `registerAction(id, label, colors, icon)`, `new RetroTouchAction(id, label, colors, icon)` and
  `setActionIcon(actionId, icon)`.
- New shapes `ROUNDED_RECT` and `CAPSULE` and
  `RetroTouchControl.button(..., colors, shape, aspect)`; size is the height, aspect is width over
  height. Shapes apply in both styles and are touched on their shape.
- `setButtonAspect(actionId, aspect)` / `getButtonAspect(actionId)`: the aspect ratio per action,
  also for buttons added with ADD or remapped with ACTION. A default-layout control with its own
  aspect and the same action keeps its own; otherwise the action's applies, else 1:1. Not stored
  in saved layouts.
- `RetroTouchColors.withPressedColors`, `withLatchedColors` and `withBorderWidth` for the ICONS
  style; unset values are derived.
- ICONS D-pad: a cross with chevrons. Sticks and the look zone show no labels in ICONS.
- Games that set none of this draw pixel-identically to beta.9. All beta.9 classes and methods
  remain and the saved-layout format is unchanged (format 2), allowing an AAR-only update.
- `THIRD_PARTY_NOTICES.md` contains the Lucide license.

## 1.0.0-beta.9 - 2026-11-03

- Every control can be dragged right up to each screen edge. The limit now follows what the
  player sees, border included, instead of the control's invisible layout box, which kept round
  and rectangle buttons away from the edges. `SMALL` / `LARGE` keep a control at the edge.
- Borders of buttons, sticks and D-pads are slightly thicker: 2.5 dp instead of 2 dp.
- The knob of every stick now runs with its center along the ring instead of stopping inside it.
  Full deflection is still reached at the ring.
- Public API and saved-layout format are unchanged, allowing an AAR-only update.

## 1.0.0-beta.8 - 2026-11-03

- Rectangle buttons with slightly rounded corners. Buttons labeled `START`, `SELECT` or `MENU` are
  compact rectangles; `L`, `R` and trigger labels (`ZL`, `ZR`, `L1`, `R1`, `L2`, `R2`, `LB`, `RB`,
  `LT`, `RT`) are slightly larger rectangles. All other buttons stay round. This happens
  automatically, so existing games only need the new AAR.
- New `RetroTouchButtonShape` (`AUTO`, `ROUND`, `RECTANGLE`, `SHOULDER`) and
  `setButtonShape(actionId, shape)` / `getButtonShape(actionId)` let a game choose the shape per
  action, for example a rectangular `Z`.
- Rectangle buttons are touched on their rectangle plus a small margin.
- The editor's selection frame now fits what the player sees: a square around round buttons,
  sticks and D-pads, the rectangle around rectangle buttons.
- New `RetroTouchColors.withBorderColor(color)` changes only the border (ring) color, for example
  `RetroTouchColors.of(green).withBorderColor(red)`.
- All beta.7 classes and methods remain and the saved-layout format is unchanged (format 2),
  allowing an AAR-only update. Round buttons look exactly as before.

## 1.0.0-beta.7 - 2026-10-26

- Stick actions: `registerStickAction(id, label, colors)` registers an action that is an analog
  stick. In the editor a button whose action is cycled (`ACTION`) to a stick action becomes a stick
  with that label and color; cycling on turns it back into a button. A layout keeps at most two
  sticks and 16 buttons; `ACTION` skips what would break that.
- Such sticks report through the new optional `RetroTouchStickListener.onStick(actionId, x, y)`
  (-1..1, y down, 0/0 when released) that the listener implements next to `RetroTouchListener`;
  the move stick keeps reporting through `onMove`. `isStickAction(id)` tells the kind.
- A stick shows its label (one letter on the knob); the move stick still shows `MOVE`.
- A game places such a stick in its default layout as a `button(...)` with the stick action; it is
  turned into a stick automatically. Per-control colors stay with it.
- Stick actions never arrive through `onAction`. `ADD` gives new buttons the first non-stick action,
  `registerAction(id, ...)` turns a stick action back into a button action, and a control that would
  exceed the two-stick or 16-button limit keeps its kind, so saving never fails.
- All beta.6 classes and methods remain and the saved-layout format is unchanged (format 2),
  allowing an AAR-only update.

## 1.0.0-beta.6 - 2026-10-19

- Button labels with exactly one character, such as `A`, `B`, `X`, `Y`, `Z`, `L` or `R`, are drawn
  at `radius * 0.68`, twice the previous size, without the previous 16 dp limit. They scale with
  the button, including in the editor and after `SMALL` / `LARGE`.
- One-character labels are centered on the glyph's actual ink bounds, so the letter sits exactly
  in the middle of the circle instead of being aligned by its baseline.
- Longer labels such as `START` or `MENU` keep the beta.5 size, wrapping and font fitting.
- The public Java API and the saved-layout format are unchanged, allowing an AAR-only update.

## 1.0.0-beta.5 - 2026-10-19

- Added optional host-defined colors with the new `RetroTouchColors` class: fill, pressed, border
  and text color. `RetroTouchColors.of(fill)` derives the other colors, including readable text.
- Colors can be set per action (`registerAction(id, label, colors)` and
  `new RetroTouchAction(id, label, colors)`), per button, move stick or D-pad (new optional last
  parameter of `button()`, `moveStick()` and `dPad()`) and for the whole view
  (`setDefaultColors()`). Precedence: control, action, view default, built-in grey.
- Colors are not written to saved layouts. RetroTouch re-applies the game's colors on every load,
  matching control colors by control ID, so saved layouts stay valid and follow color changes in
  game updates. The saved-layout format is unchanged (format 2).
- Opacity stays player-controlled through `ALPHA`; the alpha channel of supplied colors is ignored.
- Games that set no colors draw pixel-identically to beta.4. All beta.4 classes and methods remain,
  allowing an AAR-only update.
- The sample app shows action colors (Fire, OK, Back) and a control color (Use).

## 1.0.0-beta.4 - 2026-08-28

- Made the settings button selectable, movable, resizable and opacity-adjustable in the editor.
- Kept the settings button permanent: `DELETE` is visibly disabled while it is selected.
- Added a dedicated drag handle that moves the editor toolbar vertically.
- Persisted settings-button and toolbar placement independently for every game/layout ID.
- Preserved all existing saved control layouts; missing editor-position data uses compatible
  defaults and is added on the next save.
- Kept the public Java API unchanged from beta.3, allowing an AAR-only update in existing games.

## 1.0.0-beta.3 - 2026-08-28

- Added public `resetInputState()` for respawn, level transitions, savegame loading, focus loss
  and host-engine input resets.
- Added `releaseAllInputs()` as a descriptive alias.
- Reset now releases held buttons and D-pad directions, forces `onMove(0, 0)`, discards move/look
  pointers and clears RetroTouch visual latches while preserving mode and layouts.
- Documented that games must clear their own toggle variables at the same reset point.
- Updated the sample Activity to reset RetroTouch during `onPause()`.

## 1.0.0-beta.2 - 2026-08-27

- Replaced Breathless-specific weapon-label checks with universal label layout.
- Automatically wraps arbitrary button labels to a maximum of two balanced lines when required.
- Supports an explicit newline supplied by a host game.
- Automatically reduces the already compact Breathless font size until every label fits inside
  its button.
- Preserves complete labels instead of abbreviating longer action names to initials.

## 1.0.0-beta.1 - 2026-08-27

- Promoted the Breathless-tested RetroTouch 0.2.2 codebase to the first public beta.
- Added complete English and German integration, usage, update and troubleshooting guides.
- Documented the stable AAR boundary, host responsibilities and recommended Unreal/UT99 test path.
- No runtime behavior or saved-layout format changed from 0.2.2.

## 0.2.2 - 2026-08-27

- Increased the settings icon by 50 percent from its 0.2.1 size.
- Raised the settings icon from opacity level 2 to level 3.

## 0.2.1 - 2026-08-27

- Added opt-in simultaneous relative look while holding selected button actions inside a look zone.
- Breathless FIRE now remains held while the same finger turns inside the LOOK AREA.
- Reduced the settings icon to half size and opacity level 2 while preserving its touch target.
- Added vendor-independent detection for built-in, USB and Bluetooth game controllers.
- Breathless now shows RetroTouch only while no game controller is available.

## 0.2.0 - 2026-08-27

- Added optional `OFF`, `GAMEPLAY` and `NAVIGATION` modes.
- Added a configurable digital navigation-pad control with stable direction action IDs.
- Added independent, persistent gameplay and navigation layouts.
- Kept `setDefaultLayout()` as a backwards-compatible gameplay-layout alias.
- Added a standalone sample flow that switches between gameplay and navigation.
- Reworked the Breathless example around a replaceable AAR and a thin game-owned bridge.

## 0.1.3 - 2026-08-27

- Latched buttons are rendered two opacity steps brighter, capped at full opacity.

## 0.1.2 - 2026-08-27

- Added a host-controlled latched-action visual state for toggle buttons.
- Breathless double-tap on RUN now toggles running while the move stick is active.
- Weapon labels use compact two-line text and all button labels are one size smaller.
- Move sticks now reach full input at the visible ring edge on every aspect ratio.

## 0.1.1 - 2026-08-27

- A screen touch now cancels controller auto-hide immediately.
- Controller input used to leave a menu no longer delays Breathless touch controls.
- Added two nearly invisible opacity levels.
- Button and stick fills, rings and labels now share the selected opacity.
- Gameplay controls use neutral greys instead of blue.
- Look zones are visible only in layout-edit mode.

## 0.1.0 - 2026-08-26

- Initial clean-room implementation.
- API 16 through API 36 support.
- Up to 16 configurable buttons, two movement sticks and two look zones.
- Normalized layouts for phones, tablets, ultrawide and Automotive displays.
- Stable string action IDs with a small host-game callback adapter.
- Multitouch, move stick, relative FPS look area and holdable buttons.
- Built-in in-game layout editor with add, remap, move, resize, opacity, delete and reset.
- Persistent per-game layouts and optional controller-triggered auto-hide.
- Standalone demonstration app and Breathless integration example.
