package com.ast.retrotouch;

/**
 * Optional second interface of a listener (1.0.0-beta.7): the analog sticks the player made from
 * stick actions (registerStickAction) report here, by their action ID, -1..1 with y down, and 0, 0
 * when the finger lifts. Listeners without it get nothing from such sticks; the move stick keeps
 * reporting through onMove. Runs on Android's UI thread.
 */
public interface RetroTouchStickListener {
    void onStick(String actionId, float x, float y);
}
