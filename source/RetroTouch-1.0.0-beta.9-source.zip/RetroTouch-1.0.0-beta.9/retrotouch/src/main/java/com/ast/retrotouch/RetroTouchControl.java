package com.ast.retrotouch;

import org.json.JSONException;
import org.json.JSONObject;

/** A normalized, resolution-independent control definition. */
public final class RetroTouchControl {
    public enum Type { BUTTON, MOVE_STICK, LOOK_ZONE, D_PAD }

    private final String id;
    private Type type;
    private String actionId;
    private String label;
    private float x;
    private float y;
    private float width;
    private float height;
    private float opacity;
    private RetroTouchColors colors;

    private RetroTouchControl(String id, Type type, String actionId, String label,
                              float x, float y, float width, float height, float opacity,
                              RetroTouchColors colors) {
        if (!RetroTouchAction.isValidId(id)) throw new IllegalArgumentException("Invalid control ID: " + id);
        this.id = id;
        this.type = type;
        this.actionId = actionId == null ? "" : actionId;
        this.label = label == null ? "" : label;
        this.x = clamp(x, 0.0f, 1.0f);
        this.y = clamp(y, 0.0f, 1.0f);
        this.width = clamp(width, 0.04f, 1.0f);
        this.height = clamp(height, 0.04f, 1.0f);
        this.opacity = clamp(opacity, 0.04f, 1.0f);
        this.colors = colors;
    }

    public static RetroTouchControl button(String id, String actionId, String label,
                                           float x, float y, float size) {
        return button(id, actionId, label, x, y, size, null);
    }

    /**
     * Creates a button with its own colors. They take precedence over the action's colors and
     * the view-wide default; null keeps those.
     */
    public static RetroTouchControl button(String id, String actionId, String label,
                                           float x, float y, float size, RetroTouchColors colors) {
        return new RetroTouchControl(id, Type.BUTTON, actionId, label, x, y, size, size, 0.58f, colors);
    }

    public static RetroTouchControl moveStick(String id, float x, float y, float size) {
        return moveStick(id, x, y, size, null);
    }

    /** Creates a move stick with its own colors; null keeps the view-wide default. */
    public static RetroTouchControl moveStick(String id, float x, float y, float size,
                                              RetroTouchColors colors) {
        return new RetroTouchControl(id, Type.MOVE_STICK, "", "MOVE", x, y, size, size, 0.45f, colors);
    }

    public static RetroTouchControl lookZone(String id, float x, float y, float width, float height) {
        return new RetroTouchControl(id, Type.LOOK_ZONE, "", "LOOK", x, y, width, height, 0.16f, null);
    }

    /** Creates a digital navigation pad which emits the RetroTouchNavigation action IDs. */
    public static RetroTouchControl dPad(String id, float x, float y, float size) {
        return dPad(id, x, y, size, null);
    }

    /** Creates a navigation pad with its own colors; null keeps the view-wide default. */
    public static RetroTouchControl dPad(String id, float x, float y, float size, RetroTouchColors colors) {
        return new RetroTouchControl(id, Type.D_PAD, "", "", x, y, size, size, 0.58f, colors);
    }

    public RetroTouchControl copy() {
        return new RetroTouchControl(id, type, actionId, label, x, y, width, height, opacity, colors);
    }

    public String getId() { return id; }
    public Type getType() { return type; }
    public String getActionId() { return actionId; }
    public String getLabel() { return label; }
    public float getX() { return x; }
    public float getY() { return y; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    public float getOpacity() { return opacity; }

    /** Returns the colors given when this control was created, or null. */
    public RetroTouchColors getColors() { return colors; }

    void setAction(String actionId, String label) {
        this.actionId = actionId == null ? "" : actionId;
        this.label = label == null ? "" : label;
    }

    /** The editor turns a button into a stick and back when its action is a stick action. */
    void setType(Type type) {
        this.type = type;
    }

    void setColors(RetroTouchColors colors) {
        this.colors = colors;
    }

    /** Moves the center; halfWidth/halfHeight are the visible half size, normalized like x and y. */
    void setPosition(float x, float y, float halfWidth, float halfHeight) {
        this.x = clamp(x, Math.min(0.5f, halfWidth), Math.max(0.5f, 1.0f - halfWidth));
        this.y = clamp(y, Math.min(0.5f, halfHeight), Math.max(0.5f, 1.0f - halfHeight));
    }

    /** Resizes around the center; the view keeps the control on screen afterwards. */
    void scale(float factor) {
        float maximum = type == Type.LOOK_ZONE ? 1.0f : (type == Type.D_PAD ? 0.58f : 0.42f);
        width = clamp(width * factor, 0.06f, maximum);
        height = clamp(height * factor, 0.06f, maximum);
    }

    void cycleOpacity() {
        if (opacity < 0.10f) opacity = 0.14f;
        else if (opacity < 0.20f) opacity = 0.28f;
        else if (opacity < 0.42f) opacity = 0.58f;
        else if (opacity < 0.75f) opacity = 0.90f;
        else opacity = 0.07f;
    }

    /** Colors are host presentation and deliberately not saved; the default layout re-applies them. */
    JSONObject toJson() throws JSONException {
        JSONObject json = new JSONObject();
        json.put("id", id);
        json.put("type", type.name().toLowerCase());
        json.put("action", actionId);
        json.put("label", label);
        json.put("x", x);
        json.put("y", y);
        json.put("width", width);
        json.put("height", height);
        json.put("opacity", opacity);
        return json;
    }

    static RetroTouchControl fromJson(JSONObject json) throws JSONException {
        String typeName = json.getString("type").toUpperCase();
        Type type = Type.valueOf(typeName);
        return new RetroTouchControl(
                json.getString("id"), type, json.optString("action", ""),
                json.optString("label", ""), (float) json.getDouble("x"),
                (float) json.getDouble("y"), (float) json.getDouble("width"),
                (float) json.getDouble("height"), (float) json.optDouble("opacity", 0.58), null);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
