# RetroTouch 1.0.0-beta.9 — integration and usage guide

## 1. What RetroTouch is

RetroTouch is an Android touch-overlay library for games. It is added above the game's existing
`View`, `SurfaceView`, `GLSurfaceView`, SDL surface or JNI-driven renderer. RetroTouch handles
drawing, multitouch, layout editing and persistence. The game keeps ownership of its input logic
and maps RetroTouch's abstract callbacks to its existing buttons, keys, axes or native functions.

The library supports Android 4.1 (API 16) through Android 16 (API 36), has no runtime dependencies
and does not require AndroidX. The implementation is MIT-licensed.

The beta was validated in Breathless with simultaneous movement, looking and firing, latched RUN,
menu navigation and physical-controller detection. Further engine testing starts with Unreal and
Unreal Tournament 99.

## 2. Responsibilities

RetroTouch provides:

- pointer-ID-based multitouch;
- up to 16 buttons, two movement sticks, two look zones and two digital D-pads;
- normalized layouts for different aspect ratios;
- independent `GAMEPLAY` and `NAVIGATION` layouts;
- `OFF` mode with touch pass-through;
- a built-in editor and per-game saved layouts;
- optional host-defined colors;
- an optional second analog stick that reports separately;
- optional FIRE-and-LOOK behavior;
- controller-presence detection.

The host game provides:

- the list of supported actions and their labels;
- optionally the colors of buttons, sticks and D-pads;
- default control positions;
- callback mapping to Java, JNI, SDL or the engine's input queue;
- the current overlay mode;
- any game rule such as RUN double-tap/toggle behavior;
- periodic controller-presence checks if automatic controller suppression is wanted.

## 3. Add the AAR

Copy `RetroTouch-1.0.0-beta.9.aar` to:

```text
app/libs/retrotouch.aar
```

Add the dependency to the app module's `build.gradle`:

```groovy
dependencies {
    implementation files('libs/retrotouch.aar')
}
```

No RetroTouch Java source files should be copied into the game. Keep the game-specific bridge in
the game project. A compatible update then consists of replacing the AAR and rebuilding the game.

## 4. Place RetroTouch above the game view

Use a `FrameLayout`, add the game first and RetroTouch last:

```java
FrameLayout.LayoutParams fill = new FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT,
        FrameLayout.LayoutParams.MATCH_PARENT);

FrameLayout root = new FrameLayout(this);
root.addView(gameView, fill);

RetroTouchView retroTouch = new RetroTouchView(this);
root.addView(retroTouch, fill);
setContentView(root);
```

The last child is drawn above the game. In `RetroTouchMode.OFF`, RetroTouch is not drawn and does
not consume touches, so the game's original menu or tap-to-skip handling continues to work.

## 5. Register actions and create the gameplay layout

Action IDs are the stable contract between the layout and the game. Use lowercase IDs containing
letters, digits and underscores. Do not expose actions the game cannot process.

```java
retroTouch.registerAction("fire", "Fire");
retroTouch.registerAction("use", "Use");
retroTouch.registerAction("run", "Run");
retroTouch.registerAction("weapon_next", "Next\nWeapon");
retroTouch.registerAction("menu", "Menu");

List<RetroTouchControl> gameplay = new ArrayList<RetroTouchControl>();
gameplay.add(RetroTouchControl.lookZone(
        "look", 0.72f, 0.48f, 0.56f, 0.78f));
gameplay.add(RetroTouchControl.moveStick(
        "move", 0.16f, 0.76f, 0.25f));
gameplay.add(RetroTouchControl.button(
        "fire_button", "fire", "Fire", 0.89f, 0.71f, 0.15f));
gameplay.add(RetroTouchControl.button(
        "use_button", "use", "Use", 0.77f, 0.80f, 0.11f));

retroTouch.setGameplayLayout(
        new RetroTouchLayout("unique_game_id", gameplay));
```

Coordinates and sizes are normalized from `0.0` to `1.0`. `x` and `y` identify the control's
center. Use a unique and permanent game ID because it is also part of the saved-layout key.

Button labels use the compact Breathless font style in every game. RetroTouch measures each label,
automatically wraps it to at most two balanced lines when necessary and reduces the font size until
the complete text fits inside the button. A host may force the line break with `\n`; no
game-specific label exceptions are needed.

Labels consisting of exactly one character, such as `A`, `B`, `X`, `Y`, `Z`, `L` or `R`, are drawn
twice as large (text size = radius × 0.68) and without the 16 dp limit. The letter grows and
shrinks with the button, including `SMALL` / `LARGE` in the editor, and sits exactly in the middle
of the circle: RetroTouch centers the glyph's actual ink, not its baseline. Longer labels such as
`FIRE` or `OK` are unchanged.

Since beta.8, RetroTouch chooses a button's shape from its label:

| Label | Shape |
|---|---|
| `START`, `SELECT`, `MENU` | compact rectangle (1.2 × 0.6 of the diameter of a round button of the same size) |
| `L`, `R`, `ZL`, `ZR`, `L1`, `R1`, `L2`, `R2`, `LB`, `RB`, `LT`, `RT` | slightly larger rectangle (1.5 × 0.75) |
| everything else | round, as before |

Rectangles have slightly rounded corners and are touched on their area plus a small margin. Letter
case does not matter. A game can choose the shape per action, for example a rectangular GameCube
`Z` button:

```java
retroTouch.setButtonShape("z", RetroTouchButtonShape.SHOULDER);  // RECTANGLE, ROUND
retroTouch.setButtonShape("z", RetroTouchButtonShape.AUTO);      // automatic again
```

`setDefaultLayout()` remains a compatibility alias for `setGameplayLayout()`.

## 6. Custom colors (optional)

Without colors, RetroTouch draws everything in its familiar grey, pixel for pixel as in beta.4.
Colors come from the host game, exactly like labels. Players cannot change them in the editor;
`ALPHA` still controls opacity only.

`RetroTouchColors` combines four colors:

| Color | Button | D-pad | Move stick |
|---|---|---|---|
| fill | face | cells | center knob |
| pressed | pressed or latched | pressed direction | knob while held |
| border | ring | cell outlines | outer ring |
| text | label | arrows | `MOVE` |

RetroTouch draws the stick's base as a dark tint of the fill color.

```java
// Fill color only: pressed color, border and readable text are derived.
RetroTouchColors green = RetroTouchColors.of(Color.rgb(31, 166, 74));

// Fill, pressed and text color; the border is derived.
RetroTouchColors red = RetroTouchColors.of(
        Color.rgb(217, 43, 43), Color.rgb(255, 130, 130), Color.WHITE);

// All four colors.
RetroTouchColors purple = new RetroTouchColors(
        Color.rgb(106, 79, 193), Color.rgb(170, 150, 235), Color.WHITE, Color.WHITE);
```

`Color` is `android.graphics.Color`. `Color.parseColor("#1FA64A")` or `0x1FA64A` work as well. The
alpha channel of a color is ignored so that opacity stays under the player's control. With a
single fill color, RetroTouch picks dark text on light fills and white text otherwise.

Colors can be given in three places. The most specific one wins:

1. **On the control** – as the last, optional parameter of `button(...)`, `moveStick(...)` or
   `dPad(...)`:

   ```java
   gameplay.add(RetroTouchControl.button(
           "a_button", "a", "A", 0.86f, 0.66f, 0.16f, green));
   gameplay.add(RetroTouchControl.moveStick(
           "move", 0.16f, 0.76f, 0.25f, RetroTouchColors.of(Color.rgb(90, 90, 90))));
   ```

2. **On the action** – applies to every button mapped to that action, including buttons the
   player adds with `ADD` or remaps with `ACTION`:

   ```java
   retroTouch.registerAction("a", "A", green);
   retroTouch.registerAction("b", "B", red);
   ```

3. **As the default** for every button, D-pad and stick without colors of its own:

   ```java
   retroTouch.setDefaultColors(RetroTouchColors.of(Color.rgb(40, 104, 200)));
   retroTouch.setDefaultColors(null); // back to the built-in grey
   ```

Precedence: control → action → default → built-in grey.

For buttons, prefer action colors, the same place the label comes from. A color on the control
stays with the control even when the player remaps it to another action with `ACTION`. Sticks and
D-pads take colors from the control or the default.

Colors are not stored in the player's saved layout. RetroTouch re-applies them from the game on
every load; control colors are matched by control ID from the current default layout. Existing
saved layouts therefore keep working unchanged, and a color change in a game update shows up
immediately, even for players with a customized layout.

Example of a GameCube-like setup:

```java
retroTouch.registerAction("a", "A", RetroTouchColors.of(Color.rgb(31, 166, 74)));
retroTouch.registerAction("b", "B", RetroTouchColors.of(Color.rgb(217, 43, 43)));
retroTouch.registerAction("x", "X", RetroTouchColors.of(Color.rgb(208, 208, 208)));
retroTouch.registerAction("y", "Y", RetroTouchColors.of(Color.rgb(208, 208, 208)));
retroTouch.registerAction("z", "Z", RetroTouchColors.of(Color.rgb(106, 79, 193)));
retroTouch.registerAction("start", "Start"); // no colors: stays grey
```

X and Y automatically get dark text because their fill is light.

To color only the border (ring) and keep the other colors:

```java
retroTouch.registerAction("a", "A",
        RetroTouchColors.of(Color.rgb(31, 166, 74)).withBorderColor(Color.rgb(255, 215, 0)));
```

## 7. Second analog stick (optional)

The move stick keeps reporting through `onMove`. For a second, independent stick, such as a
GameCube C-stick, register a **stick action**:

```java
retroTouch.registerStickAction("c_stick", "C", RetroTouchColors.of(Color.rgb(245, 200, 0)));
```

In its default layout the game adds the stick as a button with that action; RetroTouch turns it
into a stick automatically. Per-control colors stay with it.

```java
gameplay.add(RetroTouchControl.button("c_stick", "c_stick", "C", 0.80f, 0.70f, 0.20f));
```

The stick reports through `RetroTouchStickListener.onStick(actionId, x, y)`: values from `-1.0` to
`1.0`, y down, and `0, 0` on release. The listener implements `RetroTouchStickListener` as well. An
anonymous `new RetroTouchAdapter() { ... }` cannot do that, so use a named class:

```java
final class TouchBridge extends RetroTouchAdapter implements RetroTouchStickListener {
    @Override public void onMove(float x, float y) {
        nativeTouchMove(x, y);
    }

    @Override public void onStick(String actionId, float x, float y) {
        if ("c_stick".equals(actionId)) nativeTouchCStick(x, y);
    }
}

retroTouch.setListener(new TouchBridge());
```

Further rules:

- A stick shows its label; a single letter is drawn large on the knob.
- In the editor, a button becomes a stick when the player selects the stick action with `ACTION`;
  pressing `ACTION` again turns it back into a button.
- A layout holds at most two sticks, including the move stick, and 16 buttons. `ACTION` skips
  anything that would exceed these limits. A button that cannot become a stick because of the limit
  stays inactive.
- Stick actions never arrive through `onAction`. Buttons added with `ADD` get the first ordinary
  action.
- `isStickAction(id)` tells whether an action is a stick action. `registerAction(id, ...)` turns a
  stick action back into an ordinary action. `registerActions(...)` replaces all actions and also
  removes all stick actions.
- `resetInputState()` reports `0, 0` for every stick action.
- Listeners without `RetroTouchStickListener` receive nothing from these sticks.

## 8. Map callbacks to the game

All callbacks run on Android's UI thread:

```java
retroTouch.setListener(new RetroTouchAdapter() {
    @Override public void onAction(String actionId, boolean pressed) {
        nativeTouchAction(actionId, pressed);
    }

    @Override public void onMove(float x, float y) {
        nativeTouchMove(x, y);
    }

    @Override public void onLook(float deltaX, float deltaY) {
        nativeTouchLook(deltaX, deltaY);
    }

    @Override public void onEditorStateChanged(boolean editing) {
        nativeSetTouchEditorOpen(editing);
    }
});
```

- `onAction`: `pressed=true` on finger down and `false` on finger up/cancel.
- `onMove`: normalized axes from `-1.0` to `1.0`; the visible ring edge is full deflection.
- `onLook`: relative motion, not an absolute screen position.
- `onEditorStateChanged`: lets the host pause gameplay or suppress its own input while editing.

JNI games should transfer these values into their existing input state or event queue. Avoid doing
heavy native work synchronously on the UI thread. Always handle both press and release, and clear
held native states when the Activity pauses.

## 9. FIRE while turning

Place the FIRE button's center inside the look zone and enable its action:

```java
retroTouch.setLookWhileHoldingAction("fire", true);
```

The same finger can now press FIRE and continue producing relative look motion without releasing
FIRE. FIRE becomes inactive only when that finger is lifted or cancelled. Other buttons keep their
normal behavior. Movement can simultaneously come from another finger on the left stick.

## 10. RUN double-tap and latched display

RUN double-tap is deliberately a host-game rule, not hard-coded library behavior. In the action
callback, detect two RUN presses within the chosen interval, toggle the run state and update the
visual latch:

```java
retroTouch.setActionLatched("run", alwaysRunEnabled);
```

The latched RUN button is drawn two opacity steps stronger. The host should apply always-run only
while the movement stick is non-zero and reset it at the same points as other held input states
(pause, level transition or shutdown). This keeps RetroTouch usable by games whose RUN semantics
differ from Breathless.

## 11. Optional navigation overlay

Games with their own touch-capable menus can skip this section and use `OFF` in menus. Otherwise:

```java
retroTouch.registerAction("menu_ok", "OK");
retroTouch.registerAction("menu_back", "Back");

List<RetroTouchControl> navigation = new ArrayList<RetroTouchControl>();
navigation.add(RetroTouchControl.dPad(
        "navigation", 0.18f, 0.72f, 0.30f));
navigation.add(RetroTouchControl.button(
        "ok", "menu_ok", "OK", 0.86f, 0.68f, 0.14f));
navigation.add(RetroTouchControl.button(
        "back", "menu_back", "Back", 0.73f, 0.82f, 0.11f));

retroTouch.setNavigationLayout(
        new RetroTouchLayout("unique_game_id_navigation", navigation));
```

The D-pad emits `RetroTouchNavigation.UP`, `.DOWN`, `.LEFT` and `.RIGHT` (string values `nav_up`,
`nav_down`, `nav_left`, `nav_right`). Map these to the game's existing menu input.

Switch modes only when the game's state changes:

```java
retroTouch.setMode(RetroTouchMode.OFF);        // original touch passes to the game
retroTouch.setMode(RetroTouchMode.GAMEPLAY);   // FPS controls
retroTouch.setMode(RetroTouchMode.NAVIGATION); // D-pad and configurable buttons
```

Gameplay and navigation layouts are saved independently. A game is not required to use all modes.
For UT99, the expected first integration is `OFF` in its existing touch menus and `GAMEPLAY` in a
level.

## 12. Physical controllers

To show touch controls only when no controller is available:

```java
RetroTouchMode wantedMode = inLevel
        ? RetroTouchMode.GAMEPLAY
        : RetroTouchMode.OFF;

boolean hasController = RetroTouchControllers.isControllerConnected();
retroTouch.setMode(hasController ? RetroTouchMode.OFF : wantedMode);
```

Repeat the presence check during the host's normal state update (Breathless uses about 200 ms) to
handle hotplug without restarting. Detection uses Android `GAMEPAD` and `JOYSTICK` sources, so it
covers built-in handheld controls and Xbox, PlayStation, USB, Bluetooth and generic controllers
without vendor lists.

`notifyControllerInput()` is a different, optional feature: it temporarily hides RetroTouch for
three seconds after a controller event. If strict presence-based suppression is used, disable this
additional behavior with `setAutoHideOnController(false)` to keep the policy unambiguous.

## 13. Editor and player usage

The settings icon opens the editor. Select a control and use:

- `ADD`: add a button, up to 16;
- `ACTION`: select the next registered game action;
- `SMALL` / `LARGE`: resize the selection;
- `ALPHA`: cycle through five opacity levels;
- `DELETE`: remove the selection;
- `RESET`: restore the host game's default layout;
- `SAVE`: persist the current mode's layout and close the editor.

Controls can be dragged directly. The settings button can also be selected and moved, resized with
`SMALL` / `LARGE`, and adjusted with `ALPHA`. It is the permanent editor entry point, so it cannot
be removed: while settings is selected, `DELETE` is visibly disabled and has no effect.

The white selection frame fits the visible control: a square around round buttons, sticks and
D-pads, and the rectangle around rectangle buttons. Every control can be dragged to each screen
edge, also after `SMALL` / `LARGE`.

A stick's knob runs with its center along the ring; full deflection is reached at the ring.

The strip has a `↕ DRAG` handle above its tools. Drag that handle up or down whenever the strip
covers a touch control. `SAVE` stores the settings-button position, size and opacity plus the
toolbar's vertical position independently for every gameplay or navigation layout. `RESET` also
restores these editor elements to their defaults. Existing saved layouts remain compatible and
use the previous default editor positions until saved again.

The large look area is shown only in edit mode. Saved layouts are private app preferences; they
remain available after restarting the game.

## 14. Activity lifecycle

Recommended host behavior:

- on pause, cancel or release all game-side touch states;
- when leaving a level, switch to the correct mode and clear host-side toggles if appropriate;
- do not recreate the RetroTouch view on every rendered frame;
- perform mode changes and RetroTouch API calls on the UI thread;
- after an action that can quit the game, immediately process the game's quit request. Breathless
  originally waited for another input because its native quit flag was not consumed after a
  RetroTouch callback.

Whenever the engine internally resets its key or axis state, reset RetroTouch immediately after it:

```java
engineResetInput();
retroTouch.resetInputState();
```

Typical call sites are respawn/checkpoint restart, level transitions, savegame loading, focus loss
and the Activity's `onPause()`. The method releases held buttons and D-pad directions, emits
`onMove(0, 0)`, discards movement and look pointers, and clears RetroTouch's visual latches. It does
not change the current overlay mode, layouts or editor configuration. If the game bridge owns a
toggle such as Breathless always-run, clear that game-owned variable at the same point.

`releaseAllInputs()` is an equivalent descriptive alias.

## 15. Updating RetroTouch

For API-compatible updates:

1. replace `app/libs/retrotouch.aar`;
2. keep the game-owned bridge and layouts unchanged;
3. sync Gradle, clean and rebuild the APK/AAB;
4. run the regression checklist below.

The AAR is compiled into the APK/AAB and cannot be replaced inside an already installed app.
Source updates are only needed when the changelog explicitly announces a breaking API migration.

## 16. Test checklist

Test on a real touch device:

1. Enter gameplay without a controller; RetroTouch appears immediately.
2. Move, turn and hold FIRE simultaneously with three fingers.
3. Drag the held FIRE finger inside the look area; turning continues and FIRE remains active.
4. Release FIRE; firing stops immediately while ordinary look still works.
5. Verify full movement at the visible stick edge.
6. Test RUN hold and, if implemented by the host, RUN double-tap.
7. Open, edit, save and reload both layouts.
8. Test `OFF` touch pass-through in the original menus.
9. If used, test D-pad, OK and Back in all relevant menus.
10. Connect and disconnect built-in/USB/Bluetooth controllers during runtime.
11. Pause/resume, rotate if supported, change levels and quit without stuck inputs.
12. Test at least one 4:3, one 16:9 and one wide/Automotive resolution.
13. Trigger respawn or an engine input reset while controls are held; verify that the next touch
    starts a fresh continuous input and no action remains stuck.
14. If colors are used: they appear with an already saved layout too, pressed buttons switch to
    the pressed color and `ALPHA` still changes opacity only.
15. If a second stick is used: operate the move stick and the second stick at the same time; both
    report separately, and releasing reports `0, 0`.

## 17. Troubleshooting

- **Overlay is not visible:** check the current mode, controller detection, `setOverlayEnabled`,
  child order in the `FrameLayout`, and whether a gameplay layout was registered.
- **Original menu no longer receives taps:** use `RetroTouchMode.OFF`, not merely a transparent
  gameplay layout.
- **Input starts only after a delay:** do not call `notifyControllerInput()` for menu events when
  using presence-based controller suppression.
- **A button draws but has no effect:** register its action ID and handle the exact same ID in the
  callback.
- **FIRE stops when turning:** enable `setLookWhileHoldingAction("fire", true)` and ensure the
  button center lies inside the look-zone rectangle.
- **QUIT waits for another input:** consume the host game's quit request directly after the
  RetroTouch action callback.
- **Controls remain held after pause:** clear game-side input on pause/cancel; never depend only on
  a later finger-up event.
- **A color does not appear:** check the precedence (control → action → default). A control color
  applies only to that control ID in the default layout; buttons added with `ADD` use their action's
  color or the default.
- **Old custom layout hides new default controls:** use a new layout game ID during development or
  choose `RESET` in the editor.

## 18. Recommended Unreal/UT99 first pass

Start with the narrowest integration:

1. keep the existing UT99 menu touch implementation and select `OFF` outside gameplay;
2. add one Java bridge above the game's render view;
3. map actions to the existing Unreal input path rather than calling gameplay functions directly;
4. map movement to forward/strafe axes and relative look to yaw/pitch deltas;
5. enable FIRE-and-LOOK only for the primary-fire action;
6. suppress RetroTouch while any hardware controller is present;
7. validate frame pacing and pointer capture on ChromeOS before tuning sensitivity.

This isolates engine-specific problems from the overlay and preserves the AAR-only update path.
